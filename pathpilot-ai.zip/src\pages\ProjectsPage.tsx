import React, { useState } from 'react';
import {
  FolderGit2,
  ExternalLink,
  Clock,
  FileText,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ProjectsPage: React.FC = () => {
  const { projects, updateProjectStatus } = useApp();
  const [complexityFilter, setComplexityFilter] = useState<string>('all');
  const [expandedProjectId, setExpandedProjectId] = useState<string | null>(projects[0]?.id || null);

  const filteredProjects = projects.filter(p => {
    if (complexityFilter === 'all') return true;
    return p.complexity.toLowerCase() === complexityFilter.toLowerCase();
  });

  const toggleExpand = (id: string) => {
    setExpandedProjectId(prev => (prev === id ? null : id));
  };

  return (
    <div className="min-h-screen bg-[#F7F8FC] dark:bg-[#0B0F19] text-[#172033] dark:text-gray-100 py-8 sm:py-12 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-[var(--brand-primary)]/15 text-[var(--brand-primary)] border border-[var(--brand-primary)]/30 mb-2">
              <FolderGit2 className="w-3.5 h-3.5" />
              <span>Industrial Portfolio Architecture</span>
            </div>
            <h1 className="text-3xl font-extrabold text-[#172033] dark:text-white tracking-tight">
              Recommended Portfolio Projects
            </h1>
            <p className="text-xs sm:text-sm text-[#68738A] dark:text-gray-400 mt-1 max-w-2xl leading-relaxed">
              Employers hire proof of competence, not certificates. These production-caliber capstones are reverse-engineered to demonstrate ACID guarantees, clean architecture, and scale.
            </p>
          </div>

          {/* Complexity Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#68738A] dark:text-gray-400">Complexity:</span>
            <div className="flex gap-1 bg-white dark:bg-gray-900 p-1 rounded-xl border border-[#E6E9F1] dark:border-gray-800 shadow-xs">
              {['all', 'intermediate', 'advanced', 'capstone'].map((level) => (
                <button
                  key={level}
                  onClick={() => setComplexityFilter(level)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${
                    complexityFilter === level
                      ? 'bg-[var(--brand-primary)] text-white shadow-2xs'
                      : 'text-[#68738A] dark:text-gray-400 hover:text-[#172033] dark:hover:text-white'
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Project Cards List */}
        <div className="space-y-6">
          {filteredProjects.map((project) => {
            const isExpanded = expandedProjectId === project.id;

            return (
              <div
                key={project.id}
                className={`rounded-3xl bg-white dark:bg-gray-900 border transition-all duration-200 overflow-hidden shadow-xs ${
                  isExpanded
                    ? 'border-[var(--brand-primary)] ring-2 ring-[var(--brand-primary)]/20 shadow-md'
                    : 'border-[#E6E9F1] dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                }`}
              >
                {/* Main Card Header Bar */}
                <div className="p-6 sm:p-7 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        project.complexity === 'Capstone'
                          ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800'
                          : project.complexity === 'Advanced'
                          ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800'
                          : 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                      }`}>
                        {project.complexity}
                      </span>
                      <span className="text-xs font-medium text-[#68738A] dark:text-gray-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {project.estimatedHours} hrs build time
                      </span>
                      <span className="text-xs text-[#68738A] dark:text-gray-600">·</span>
                      <span className="text-xs font-semibold text-[var(--brand-primary)]">
                        {project.roleTarget}
                      </span>
                    </div>

                    <h3 className="text-xl font-bold text-[#172033] dark:text-white">
                      {project.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-[#68738A] dark:text-gray-400">
                      {project.tagline}
                    </p>

                    {/* Tech stack pills */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {project.techStack.map(t => (
                        <span key={t} className="px-2 py-0.5 rounded-md text-[11px] font-mono bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions & Status */}
                  <div className="flex items-center gap-3 shrink-0">
                    {/* Status Toggle */}
                    <div className="flex items-center bg-gray-50 dark:bg-gray-800 p-1 rounded-2xl border border-gray-200 dark:border-gray-700 text-xs">
                      <button
                        onClick={() => updateProjectStatus(project.id, 'not_started')}
                        className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                          project.status === 'not_started' ? 'bg-white dark:bg-gray-700 shadow-2xs text-[#172033] dark:text-white' : 'text-[#68738A] dark:text-gray-400'
                        }`}
                      >
                        Not Started
                      </button>
                      <button
                        onClick={() => updateProjectStatus(project.id, 'in_progress')}
                        className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                          project.status === 'in_progress' ? 'bg-[var(--brand-primary)] text-white shadow-2xs' : 'text-[#68738A] dark:text-gray-400'
                        }`}
                      >
                        In Progress
                      </button>
                      <button
                        onClick={() => updateProjectStatus(project.id, 'completed')}
                        className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                          project.status === 'completed' ? 'bg-emerald-600 text-white shadow-2xs' : 'text-[#68738A] dark:text-gray-400'
                        }`}
                      >
                        Done
                      </button>
                    </div>

                    <button
                      onClick={() => toggleExpand(project.id)}
                      className="p-2.5 rounded-2xl text-[#68738A] dark:text-gray-400 hover:text-[#172033] dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700 transition-colors"
                      title={isExpanded ? 'Collapse' : 'Expand full specs'}
                    >
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Expanded Architectural Specs */}
                {isExpanded && (
                  <div className="border-t border-gray-100 dark:border-gray-800 p-6 sm:p-8 bg-gray-50/50 dark:bg-gray-950/50 space-y-6 animate-in fade-in duration-150">
                    {/* Problem Statement */}
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-[#68738A] dark:text-gray-400 mb-1.5">
                        Production Problem Statement
                      </h4>
                      <p className="text-xs sm:text-sm text-[#172033] dark:text-gray-200 leading-relaxed p-3.5 rounded-2xl bg-white dark:bg-gray-800/80 border border-[#E6E9F1] dark:border-gray-700">
                        {project.problemStatement}
                      </p>
                    </div>

                    {/* Key Architectural Features */}
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-[#68738A] dark:text-gray-400 mb-2">
                        Key Architectural Features & Engineering Standards
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                        {project.keyFeatures.map((f, i) => (
                          <div key={i} className="p-3 rounded-xl bg-white dark:bg-gray-800/80 border border-[#E6E9F1] dark:border-gray-700 text-xs text-[#172033] dark:text-gray-200 flex items-start gap-2">
                            <span className="w-4 h-4 rounded-full bg-[var(--brand-primary)]/15 text-[var(--brand-primary)] flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                              ✓
                            </span>
                            <span>{f}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Resume Bullet Points (Google XYZ Format) */}
                    <div className="p-4 rounded-2xl bg-[var(--brand-primary)]/5 border border-[var(--brand-primary)]/20 space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)] flex items-center gap-1.5">
                          <FileText className="w-4 h-4" />
                          <span>Ready-to-Use Resume Bullet Points (Google XYZ Format)</span>
                        </h4>
                        <span className="text-[10px] text-[#68738A] dark:text-gray-400">Copy directly to your CV</span>
                      </div>
                      <div className="space-y-1.5">
                        {project.resumeBullets.map((b, i) => (
                          <div key={i} className="p-2.5 rounded-xl bg-white dark:bg-gray-800 border border-[var(--brand-primary)]/20 text-xs text-[#172033] dark:text-gray-200 font-mono leading-relaxed select-all">
                            • {b}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Learning Outcomes */}
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-[#68738A] dark:text-gray-400 mb-2">
                        Core Competencies Demonstrated
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {project.learningOutcomes.map((lo, i) => (
                          <span key={i} className="px-3 py-1 rounded-xl text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-[#172033] dark:text-gray-200">
                            {lo}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Template link */}
                    {project.githubTemplateUrl && (
                      <div className="pt-2 flex justify-end">
                        <a
                          href={project.githubTemplateUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-[var(--brand-primary)] bg-white dark:bg-gray-800 border border-[var(--brand-primary)]/40 hover:bg-[var(--brand-primary)] hover:text-white transition-all shadow-2xs"
                        >
                          <span>Explore Repository Blueprint</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
