import React, { useState } from 'react';
import {
  User,
  Save,
  CheckCircle2,
  Plus,
  X,
  Target,
  Clock,
  Sparkles
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserProfile, SkillProficiency, LearningStrategy } from '../types';

export const ProfilePage: React.FC = () => {
  const { profile, setProfile } = useApp();
  const [formData, setFormData] = useState<UserProfile>({ ...profile });
  const [newSkill, setNewSkill] = useState('');
  const [newProficiency, setNewProficiency] = useState<SkillProficiency>('Intermediate');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const updateField = <K extends keyof UserProfile>(field: K, value: UserProfile[K]) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      if (field === 'hoursPerDay' || field === 'studyDaysPerWeek') {
        const h = field === 'hoursPerDay' ? (value as number) : prev.hoursPerDay;
        const d = field === 'studyDaysPerWeek' ? (value as number) : prev.studyDaysPerWeek;
        updated.weeklyStudyHours = h * d;
      }
      return updated;
    });
  };

  const handleAddSkill = () => {
    if (!newSkill.trim()) return;
    if (formData.skills.some(s => s.name.toLowerCase() === newSkill.trim().toLowerCase())) return;
    setFormData(prev => ({
      ...prev,
      skills: [...prev.skills, { name: newSkill.trim(), proficiency: newProficiency }]
    }));
    setNewSkill('');
  };

  const handleRemoveSkill = (name: string) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s.name !== name)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setProfile(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#F7F8FC] dark:bg-[#0B0F19] text-[#172033] dark:text-gray-100 py-8 sm:py-12 transition-colors duration-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-[var(--brand-primary)]/15 text-[var(--brand-primary)] border border-[var(--brand-primary)]/30 mb-2">
              <User className="w-3.5 h-3.5" />
              <span>Student Profile & Preferences</span>
            </div>
            <h1 className="text-3xl font-extrabold text-[#172033] dark:text-white tracking-tight">
              Career Profile
            </h1>
            <p className="text-xs sm:text-sm text-[#68738A] dark:text-gray-400 mt-1">
              Keep your profile updated. Changes automatically recalculate your Career Gap Index and unlocked roadmap tasks.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Section 1: Career Destination */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-[#E6E9F1] dark:border-gray-800 shadow-xs space-y-5">
            <h3 className="text-base font-bold text-[#172033] dark:text-white flex items-center gap-2">
              <Target className="w-5 h-5 text-[var(--brand-primary)]" />
              <span>Career Destination</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                  Dream Job Title
                </label>
                <input
                  type="text"
                  value={formData.dreamJob}
                  onChange={(e) => updateField('dreamJob', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                  Specialization Focus
                </label>
                <input
                  type="text"
                  value={formData.specialization}
                  onChange={(e) => updateField('specialization', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                  Target Industry
                </label>
                <input
                  type="text"
                  value={formData.industry}
                  onChange={(e) => updateField('industry', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                  Target Region / Country
                </label>
                <input
                  type="text"
                  value={formData.targetRegion}
                  onChange={(e) => updateField('targetRegion', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Skills Inventory */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-[#E6E9F1] dark:border-gray-800 shadow-xs space-y-5">
            <h3 className="text-base font-bold text-[#172033] dark:text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[var(--brand-secondary)]" />
              <span>Skills Inventory</span>
            </h3>

            <div className="flex gap-2">
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Add verified skill (e.g. Docker, Python, Spring Boot)..."
                className="flex-1 px-3.5 py-2 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none"
              />
              <select
                value={newProficiency}
                onChange={(e) => setNewProficiency(e.target.value as SkillProficiency)}
                className="px-3 py-2 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white"
              >
                <option value="Beginner">Beginner</option>
                <option value="Basic">Basic</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
              </select>
              <button
                type="button"
                onClick={handleAddSkill}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[var(--brand-primary)] hover:opacity-90 flex items-center gap-1 shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Add</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2 pt-2 p-4 rounded-2xl bg-[#F7F8FC] dark:bg-gray-950/60 border border-[#E6E9F1] dark:border-gray-800">
              {formData.skills.map((s) => (
                <span
                  key={s.name}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-gray-800 border border-[#E6E9F1] dark:border-gray-700 text-[#172033] dark:text-gray-200 shadow-2xs"
                >
                  <span>{s.name}</span>
                  <span className="text-[10px] text-[var(--brand-primary)] font-normal">({s.proficiency})</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveSkill(s.name)}
                    className="text-gray-400 hover:text-red-400"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Section 3: Study Capacity & Preferences */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-[#E6E9F1] dark:border-gray-800 shadow-xs space-y-5">
            <h3 className="text-base font-bold text-[#172033] dark:text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-emerald-500" />
              <span>Study Capacity & Pacing</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                  Hours per Day: {formData.hoursPerDay}h
                </label>
                <input
                  type="range"
                  min={1}
                  max={8}
                  step={0.5}
                  value={formData.hoursPerDay}
                  onChange={(e) => updateField('hoursPerDay', Number(e.target.value))}
                  className="w-full accent-[var(--brand-primary)]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                  Study Days per Week: {formData.studyDaysPerWeek} days
                </label>
                <input
                  type="range"
                  min={1}
                  max={7}
                  value={formData.studyDaysPerWeek}
                  onChange={(e) => updateField('studyDaysPerWeek', Number(e.target.value))}
                  className="w-full accent-[var(--brand-primary)]"
                />
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-between text-xs">
              <span className="font-semibold text-[#172033] dark:text-white">Weekly Commitment:</span>
              <span className="font-bold text-[var(--brand-primary)]">{formData.weeklyStudyHours} Hours / Week</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-2">
                Learning Strategy
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'balanced', label: 'Balanced' },
                  { id: 'foundation_first', label: 'Foundation First' },
                  { id: 'project_first', label: 'Project First' },
                  { id: 'interview_focused', label: 'Interview Focused' }
                ].map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => updateField('learningStrategy', s.id as LearningStrategy)}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                      formData.learningStrategy === s.id
                        ? 'bg-[var(--brand-primary)] text-white border-[var(--brand-primary)]'
                        : 'bg-white dark:bg-gray-800 text-[#68738A] dark:text-gray-400 border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex items-center justify-between pt-2">
            {savedSuccess ? (
              <span className="text-xs font-bold text-emerald-500 flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4" /> Profile saved successfully!
              </span>
            ) : (
              <div />
            )}

            <button
              type="submit"
              className="inline-flex items-center gap-2 px-7 py-3 rounded-2xl text-xs font-bold text-white bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-secondary)] hover:opacity-95 shadow-md shadow-[var(--brand-primary)]/25 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Save Profile Changes</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
