import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Compass,
  Sparkles,
  GitBranch,
  Target,
  BarChart3,
  Sliders,
  CheckCircle2,
  FolderGit2,
  ExternalLink,
  Zap
} from 'lucide-react';
import { HeroRoadmapPreview } from '../components/HeroRoadmapPreview';
import { useApp } from '../context/AppContext';

export const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const { setActiveRoadmapId } = useApp();

  const handleSelectExample = (roadmapId: string) => {
    setActiveRoadmapId(roadmapId);
    navigate(`/roadmap/${roadmapId}`);
  };

  const currentYear = new Date().getFullYear();

  return (
    <div className="min-h-screen bg-[#F7F8FC] dark:bg-[#0B0F19] text-[#172033] dark:text-gray-100 flex flex-col transition-colors duration-200">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
        {/* Glow gradients */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[650px] h-[350px] bg-gradient-to-tr from-[var(--brand-primary)]/20 via-[var(--brand-secondary)]/20 to-transparent blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white dark:bg-gray-800 border border-[#E6E9F1] dark:border-gray-700 shadow-xs text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
                <Sparkles className="w-3.5 h-3.5 text-[var(--brand-primary)]" />
                <span>YOUR FUTURE, REVERSE-ENGINEERED</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#172033] dark:text-white tracking-tight leading-[1.12]">
                Your dream job is the destination.{' '}
                <span className="bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-secondary)] bg-clip-text text-transparent">
                  We build the map.
                </span>
              </h1>

              <p className="text-base sm:text-lg text-[#68738A] dark:text-gray-400 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Turn your most ambitious career goal into a personalized, interactive roadmap. Discover the skills you need, the projects to build, and the milestones that bring your dream role closer.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                <Link
                  to="/onboarding"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-2xl text-base font-bold text-white bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-secondary)] hover:opacity-95 shadow-md shadow-[var(--brand-primary)]/30 hover:shadow-lg hover:shadow-[var(--brand-primary)]/40 transition-all transform active:scale-98"
                >
                  <span>Build My Career Roadmap</span>
                  <ArrowRight className="w-5 h-5" />
                </Link>

                <button
                  onClick={() => handleSelectExample('java-backend-fintech')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl text-base font-semibold text-[#172033] dark:text-white bg-white dark:bg-gray-800 border border-[#E6E9F1] dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 hover:bg-gray-50/80 dark:hover:bg-gray-750 shadow-xs transition-all"
                >
                  <span>Explore an Example</span>
                </button>
              </div>

              {/* Value indicators */}
              <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-left">
                {[
                  'Personalized to your starting point',
                  'Built around your target role',
                  'Adaptable as you progress'
                ].map((val, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs font-medium text-[#68738A] dark:text-gray-400">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>{val}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Interactive Preview */}
            <div className="lg:col-span-5">
              <HeroRoadmapPreview />
            </div>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="py-20 bg-white dark:bg-gray-900 border-y border-[#E6E9F1] dark:border-gray-800 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
              A Rational Engineering Methodology
            </span>
            <h2 className="text-3xl font-extrabold text-[#172033] dark:text-white mt-2">
              How PathPilot AI Works
            </h2>
            <p className="text-[#68738A] dark:text-gray-400 text-sm mt-2">
              Rather than generic tutorial checklists, we systematically work backwards from production expectations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {[
              {
                step: '01',
                title: 'Define Your Destination',
                copy: 'Tell us the exact role, company, industry, and timeline you are targeting.',
                icon: Target
              },
              {
                step: '02',
                title: 'Reverse-Engineer the Journey',
                copy: 'Identify the skills, prerequisites, projects, and milestones that connect your current abilities to your goal.',
                icon: GitBranch
              },
              {
                step: '03',
                title: 'Navigate Your Progress',
                copy: 'Follow your visual roadmap, track completed milestones, and adapt the plan as you improve.',
                icon: Compass
              }
            ].map((st, i) => {
              const Icon = st.icon;
              return (
                <div
                  key={i}
                  className="relative p-8 rounded-3xl bg-[#F7F8FC] dark:bg-gray-800/70 border border-[#E6E9F1] dark:border-gray-700 hover:border-[var(--brand-primary)]/50 hover:shadow-lg transition-all group"
                >
                  <div className="text-4xl font-extrabold text-[var(--brand-primary)]/20 mb-4 font-mono group-hover:text-[var(--brand-primary)]/40 transition-colors">
                    {st.step}
                  </div>
                  <div className="w-12 h-12 rounded-2xl bg-white dark:bg-gray-700 text-[var(--brand-primary)] flex items-center justify-center shadow-xs mb-5 group-hover:scale-105 transition-transform">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-[#172033] dark:text-white mb-2">
                    {st.title}
                  </h3>
                  <p className="text-sm text-[#68738A] dark:text-gray-400 leading-relaxed">
                    {st.copy}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* FEATURE SHOWCASE */}
      <section className="py-20 bg-[#F7F8FC] dark:bg-[#0B0F19] transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
              Architected for Impact
            </span>
            <h2 className="text-3xl font-extrabold text-[#172033] dark:text-white mt-2">
              Everything You Need to Master Your Path
            </h2>
            <p className="text-[#68738A] dark:text-gray-400 text-sm mt-2">
              Purpose-built tools to eliminate ambiguity and build genuine hiring competence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: 'Reverse Career Mapping',
                desc: 'Start with senior hiring expectations and decompose them down to Day 1 fundamentals.',
                icon: GitBranch
              },
              {
                title: 'Skill-Gap Analysis',
                desc: 'Transparent mathematical evaluation comparing your verified skills against role requirements.',
                icon: BarChart3
              },
              {
                title: 'Interactive Roadmap Canvas',
                desc: 'A full XYFlow graph with pan, zoom, custom node states, and prerequisite-locked progression.',
                icon: Compass
              },
              {
                title: 'Project Recommendations',
                desc: 'Production-caliber portfolio capstones complete with architecture blueprints and resume bullet points.',
                icon: FolderGit2
              },
              {
                title: 'What-If Career Planning',
                desc: 'Simulate study schedule changes and timeline trade-offs on an isolated scenario sandbox.',
                icon: Sliders
              },
              {
                title: 'Adaptive Progress Recovery',
                desc: 'Fell behind? The adaptive recovery engine redistributes your workload without deleting progress.',
                icon: Zap
              }
            ].map((f, i) => {
              const Icon = f.icon;
              return (
                <div
                  key={i}
                  className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-[#E6E9F1] dark:border-gray-800 shadow-xs hover:border-[var(--brand-primary)]/40 hover:shadow-md transition-all"
                >
                  <div className="w-11 h-11 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-[var(--brand-primary)] flex items-center justify-center mb-4">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-[#172033] dark:text-white mb-2">
                    {f.title}
                  </h3>
                  <p className="text-xs text-[#68738A] dark:text-gray-400 leading-relaxed">
                    {f.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* EXAMPLE CAREER PATHS */}
      <section className="py-20 bg-white dark:bg-gray-900 border-t border-[#E6E9F1] dark:border-gray-800 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
                Explore Curated Blueprints
              </span>
              <h2 className="text-3xl font-extrabold text-[#172033] dark:text-white mt-2">
                Interactive Example Tracks
              </h2>
              <p className="text-[#68738A] dark:text-gray-400 text-sm mt-1">
                Click any path to load its live graph and inspect curriculum milestones immediately.
              </p>
            </div>
            <Link
              to="/onboarding"
              className="mt-4 md:mt-0 text-xs font-bold text-[var(--brand-primary)] hover:underline flex items-center gap-1"
            >
              Have a custom role? Build your own &rarr;
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                id: 'java-backend-fintech',
                role: 'Java Backend Developer',
                spec: 'Spring Boot & Fintech',
                time: '12 Months · 10h/wk',
                tag: 'Popular'
              },
              {
                id: 'ai-engineer-llm',
                role: 'AI Engineer',
                spec: 'Generative AI & Agentic RAG',
                time: '9 Months · 12h/wk',
                tag: 'High Demand'
              },
              {
                id: 'fullstack-ts-react',
                role: 'Full-Stack Developer',
                spec: 'React, TypeScript & Node.js',
                time: '8 Months · 10h/wk',
                tag: 'Broad Roles'
              },
              {
                id: 'cybersecurity-analyst',
                role: 'Cybersecurity Analyst',
                spec: 'SOC Operations & Forensics',
                time: '10 Months · 8h/wk',
                tag: 'Defense'
              }
            ].map(track => (
              <div
                key={track.id}
                className="p-6 rounded-3xl bg-[#F7F8FC] dark:bg-gray-800/80 border border-[#E6E9F1] dark:border-gray-700 hover:border-[var(--brand-primary)] hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[var(--brand-primary)]/15 text-[var(--brand-primary)]">
                      {track.tag}
                    </span>
                    <span className="text-[11px] text-[#68738A] dark:text-gray-400 font-medium">
                      {track.time}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-[#172033] dark:text-white group-hover:text-[var(--brand-primary)] transition-colors">
                    {track.role}
                  </h4>
                  <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1">
                    {track.spec}
                  </p>
                </div>

                <div className="pt-6">
                  <button
                    onClick={() => handleSelectExample(track.id)}
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-[var(--brand-primary)] bg-white dark:bg-gray-700 border border-[var(--brand-primary)]/30 hover:bg-[var(--brand-primary)] hover:text-white transition-all flex items-center justify-center gap-1.5 shadow-2xs"
                  >
                    <span>View Interactive Map</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ROADMAP PREVIEW SECTION (Fintech Deep-Dive) */}
      <section className="py-20 bg-[#F7F8FC] dark:bg-[#0B0F19] border-t border-[#E6E9F1] dark:border-gray-800 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-8 sm:p-12 rounded-3xl bg-white dark:bg-gray-900 border border-[#E6E9F1] dark:border-gray-800 shadow-xl space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-6">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
                  Exemplary Reverse-Engineering Blueprint
                </span>
                <h3 className="text-2xl font-extrabold text-[#172033] dark:text-white mt-1">
                  Java Backend Developer Specializing in Spring Boot for Fintech
                </h3>
                <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1">
                  12-month sequence targeting entry to mid-level engineering positions at top fintech companies.
                </p>
              </div>

              <button
                onClick={() => handleSelectExample('java-backend-fintech')}
                className="shrink-0 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-[var(--brand-primary)] hover:opacity-90 transition-all shadow-xs"
              >
                <span>Launch Full Canvas</span>
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>

            {/* Stages Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { phase: '1. Foundations', title: 'Java 21 & Memory Model', desc: 'Garbage collection, OOP SOLID principles, and Git audit trails.' },
                { phase: '2. Core Tech', title: 'PostgreSQL & Concurrency', desc: 'ACID transactions, row locking, and algorithmic data structures.' },
                { phase: '3. Frameworks', title: 'Spring Boot 3 & JPA', desc: 'REST APIs, Testcontainers, and Redis cache-aside patterns.' },
                { phase: '4. Capstone', title: 'Double-Entry Ledger API', desc: 'Idempotency keys, JMeter benchmarks, and Docker orchestration.' }
              ].map((p, i) => (
                <div key={i} className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/70 border border-gray-200 dark:border-gray-700">
                  <span className="text-[10px] font-bold text-[var(--brand-primary)] uppercase tracking-wider">
                    {p.phase}
                  </span>
                  <h5 className="text-sm font-bold text-[#172033] dark:text-white mt-1">
                    {p.title}
                  </h5>
                  <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1 leading-relaxed">
                    {p.desc}
                  </p>
                </div>
              ))}
            </div>

            <p className="text-[11px] text-[#68738A] dark:text-gray-500 text-center italic">
              Disclaimer: Roadmaps and timelines are analytical planning estimates and do not constitute a formal guarantee of employment.
            </p>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-20 bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white border-y border-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Stop guessing what to learn next.
          </h2>
          <p className="text-gray-400 text-base sm:text-lg max-w-xl mx-auto leading-relaxed">
            Start with the job you want. We will help map the journey from where you are today.
          </p>
          <div className="pt-2">
            <Link
              to="/onboarding"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl text-base font-bold text-gray-950 bg-white hover:bg-gray-100 shadow-xl transition-all transform hover:scale-102 active:scale-98"
            >
              <span>Create My Roadmap</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="mt-auto bg-white dark:bg-gray-950 border-t border-[#E6E9F1] dark:border-gray-800 py-12 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[var(--brand-primary)] to-[var(--brand-secondary)] flex items-center justify-center text-white">
                  <Compass className="w-5 h-5" />
                </div>
                <span className="text-lg font-bold text-[#172033] dark:text-white">
                  PathPilot <span className="text-[var(--brand-primary)]">AI</span>
                </span>
              </div>
              <p className="text-xs text-[#68738A] dark:text-gray-400 leading-relaxed">
                Reverse-engineering career destinations into personalized, adaptive learning roadmaps.
              </p>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#172033] dark:text-white mb-3">
                Application
              </h4>
              <ul className="space-y-2 text-xs text-[#68738A] dark:text-gray-400">
                <li><Link to="/dashboard" className="hover:text-[var(--brand-primary)]">Dashboard</Link></li>
                <li><Link to="/onboarding" className="hover:text-[var(--brand-primary)]">Onboarding Setup</Link></li>
                <li><Link to="/projects" className="hover:text-[var(--brand-primary)]">Project Portfolio</Link></li>
                <li><Link to="/settings" className="hover:text-[var(--brand-primary)]">Settings & Cloud</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#172033] dark:text-white mb-3">
                Curated Roadmaps
              </h4>
              <ul className="space-y-2 text-xs text-[#68738A] dark:text-gray-400">
                <li><button onClick={() => handleSelectExample('java-backend-fintech')} className="hover:text-[var(--brand-primary)] text-left">Java Backend (Fintech)</button></li>
                <li><button onClick={() => handleSelectExample('ai-engineer-llm')} className="hover:text-[var(--brand-primary)] text-left">AI Engineer (LLMs)</button></li>
                <li><button onClick={() => handleSelectExample('fullstack-ts-react')} className="hover:text-[var(--brand-primary)] text-left">Full-Stack (React/TS)</button></li>
                <li><button onClick={() => handleSelectExample('cybersecurity-analyst')} className="hover:text-[var(--brand-primary)] text-left">Cybersecurity (SOC)</button></li>
              </ul>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#172033] dark:text-white mb-3">
                Compliance & Trust
              </h4>
              <p className="text-xs text-[#68738A] dark:text-gray-400 leading-relaxed">
                Designed for educational roadmapping and structured skills development. Timelines are estimates.
              </p>
            </div>
          </div>

          <div className="pt-8 border-t border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row items-center justify-between text-xs text-[#68738A] dark:text-gray-400 gap-4">
            <p>&copy; {currentYear} PathPilot AI. All rights reserved.</p>
            <div className="flex items-center space-x-6">
              <Link to="/settings" className="hover:text-[var(--brand-primary)]">Cloud Status</Link>
              <Link to="/profile" className="hover:text-[var(--brand-primary)]">Profile</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
