import dotenv from 'dotenv';
dotenv.config();

export interface AiConfig {
  provider: 'gemini' | 'openai' | 'demo';
  geminiApiKey?: string;
  openaiApiKey?: string;
}

export function getAiConfig(): AiConfig {
  const geminiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  const openaiKey = process.env.OPENAI_API_KEY;

  if (geminiKey) {
    return { provider: 'gemini', geminiApiKey: geminiKey };
  }
  if (openaiKey) {
    return { provider: 'openai', openaiApiKey: openaiKey };
  }
  return { provider: 'demo' };
}

/**
 * Calls configured AI provider (Gemini / OpenAI) with structured prompt
 */
export async function generateRoadmapWithAi(userProfile: any, config: AiConfig): Promise<any | null> {
  const systemPrompt = `You are PathPilot AI, a premier career reverse-engineering architect.
Your task is to take a student's career goal, target industry, available study hours, and current skills, and reverse-engineer a comprehensive, realistic learning roadmap.
Organize the curriculum into 5 distinct phases:
Phase 1: Foundations
Phase 2: Core Engineering
Phase 3: Applied Toolchains & Frameworks
Phase 4: Production Capstone Project
Phase 5: Technical Interview & Career Launch

Return ONLY a valid JSON object matching this schema:
{
  "title": string,
  "summary": string,
  "totalEstimatedHours": number,
  "phases": [
    { "id": "p1", "title": string, "order": 1, "description": string, "estimatedWeeks": number }
  ],
  "nodes": [
    {
      "id": "node-1",
      "phaseId": "p1",
      "title": string,
      "description": string,
      "type": "skill" | "module" | "exercise" | "project" | "assessment" | "application",
      "status": "not_started",
      "priority": "critical" | "high" | "medium" | "optional",
      "estimatedHours": number,
      "whyItMatters": string,
      "prerequisites": string[],
      "isMandatoryPrereq": boolean,
      "learningObjectives": string[],
      "subtopics": string[],
      "practicalExercises": string[],
      "suggestedResources": [
        { "title": string, "type": "docs" | "course" | "tutorial" | "repo", "url": string, "isFree": boolean }
      ]
    }
  ],
  "edges": [
    { "id": "e1-2", "source": "node-1", "target": "node-2", "isMandatory": true }
  ]
}`;

  const userPrompt = `Target Career: ${userProfile.dreamJob}
Specialization: ${userProfile.specialization || 'General'}
Target Industry: ${userProfile.industry || 'Technology'}
Target Region: ${userProfile.targetRegion || 'Global'}
Timeline: ${userProfile.timelineMonths} months
Weekly Study Hours: ${userProfile.weeklyStudyHours} hours/week
Current Skills: ${JSON.stringify(userProfile.skills || [])}
Learning Strategy: ${userProfile.learningStrategy || 'balanced'}

Generate the reverse-engineered roadmap JSON now.`;

  try {
    if (config.provider === 'gemini' && config.geminiApiKey) {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${config.geminiApiKey}`;
      const payload = {
        contents: [
          { role: 'user', parts: [{ text: `${systemPrompt}\n\n${userPrompt}` }] }
        ],
        generationConfig: {
          response_mime_type: 'application/json',
          temperature: 0.3
        }
      };

      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!resp.ok) {
        console.error('Gemini API error:', await resp.text());
        return null;
      }

      const result = await resp.json();
      const text = result?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (text) {
        return JSON.parse(text);
      }
    } else if (config.provider === 'openai' && config.openaiApiKey) {
      const resp = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.openaiApiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt }
          ],
          response_format: { type: 'json_object' },
          temperature: 0.3
        })
      });

      if (!resp.ok) {
        console.error('OpenAI API error:', await resp.text());
        return null;
      }

      const result = await resp.json();
      const text = result?.choices?.[0]?.message?.content;
      if (text) {
        return JSON.parse(text);
      }
    }
  } catch (err) {
    console.error('Error invoking AI service:', err);
  }

  return null;
}
