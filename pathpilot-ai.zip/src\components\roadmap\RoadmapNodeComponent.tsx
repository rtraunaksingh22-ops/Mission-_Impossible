import React from 'react';
import { Handle, Position, NodeProps } from '@xyflow/react';
import {
  CheckCircle2,
  Lock,
  PlayCircle,
  Circle,
  AlertCircle,
  Code2,
  FolderGit2,
  BookOpen,
  Award,
  Send,
  Clock,
  Sparkles
} from 'lucide-react';
import { RoadmapNode, NodeStatus, NodeType, NodePriority } from '../../types';

export const RoadmapNodeComponent: React.FC<NodeProps> = ({ data, selected }) => {
  const node = data as unknown as RoadmapNode;

  const getStatusIcon = (status: NodeStatus) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'in_progress':
        return <PlayCircle className="w-4 h-4 text-[var(--brand-primary)] animate-pulse" />;
      case 'locked':
        return <Lock className="w-4 h-4 text-gray-500" />;
      case 'needs_review':
        return <AlertCircle className="w-4 h-4 text-amber-400" />;
      default:
        return <Circle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getTypeIcon = (type: NodeType) => {
    switch (type) {
      case 'project':
        return <FolderGit2 className="w-3.5 h-3.5 text-purple-400" />;
      case 'module':
        return <BookOpen className="w-3.5 h-3.5 text-blue-400" />;
      case 'assessment':
        return <Award className="w-3.5 h-3.5 text-amber-400" />;
      case 'application':
        return <Send className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <Code2 className="w-3.5 h-3.5 text-[var(--brand-primary)]" />;
    }
  };

  const getPriorityBadge = (priority: NodePriority) => {
    switch (priority) {
      case 'critical':
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-950/80 text-red-300 border border-red-800/60">Critical</span>;
      case 'high':
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-950/80 text-amber-300 border border-amber-800/60">High</span>;
      case 'medium':
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-blue-950/80 text-blue-300 border border-blue-800/60">Medium</span>;
      default:
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-gray-800 text-gray-400 border border-gray-700">Optional</span>;
    }
  };

  const isCompleted = node.status === 'completed';
  const isInProgress = node.status === 'in_progress';
  const isLocked = node.status === 'locked';

  return (
    <div
      className={`w-72 rounded-2xl bg-gray-900 border-2 select-none shadow-md transition-all duration-200 ${
        selected
          ? 'border-[var(--brand-primary)] ring-4 ring-[var(--brand-primary)]/20 shadow-xl scale-102'
          : isCompleted
          ? 'border-emerald-600/60 bg-emerald-950/20 hover:border-emerald-500'
          : isInProgress
          ? 'border-[var(--brand-primary)] bg-[var(--brand-primary)]/10 shadow-lg shadow-[var(--brand-glow)]'
          : isLocked
          ? 'border-gray-800 bg-gray-950/70 opacity-75 hover:opacity-90'
          : 'border-gray-800 hover:border-[var(--brand-primary)]/60 hover:shadow-lg'
      }`}
    >
      <Handle
        type="target"
        position={Position.Left}
        className="!w-3 !h-3 !-left-1.5 !bg-[var(--brand-primary)] !border-2 !border-gray-900 transition-transform hover:scale-125"
      />

      <div className="p-3.5">
        {/* Top Meta Row */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-1.5">
            <span className="p-1 rounded-md bg-gray-800/80 border border-gray-700/60">
              {getTypeIcon(node.type)}
            </span>
            <span className="text-[11px] font-semibold capitalize text-gray-400">
              {node.type}
            </span>
          </div>

          <div className="flex items-center space-x-1.5">
            {getPriorityBadge(node.priority)}
            <div className="flex items-center space-x-0.5 text-[11px] font-medium text-gray-400 bg-gray-800 px-1.5 py-0.5 rounded border border-gray-700">
              <Clock className="w-3 h-3" />
              <span>{node.estimatedHours}h</span>
            </div>
          </div>
        </div>

        {/* Title */}
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <h4 className={`text-sm font-bold line-clamp-2 leading-snug ${isLocked ? 'text-gray-500' : 'text-gray-100'}`}>
            {node.title}
          </h4>
          <div className="shrink-0 mt-0.5">
            {getStatusIcon(node.status)}
          </div>
        </div>

        {/* Description preview */}
        <p className="text-xs text-gray-400 line-clamp-2 leading-relaxed">
          {node.description}
        </p>

        {/* Bottom Status pill & click prompt */}
        <div className="mt-3 pt-2.5 border-t border-gray-800 flex items-center justify-between text-[11px]">
          <span className={`font-semibold capitalize flex items-center gap-1 ${
            isCompleted
              ? 'text-emerald-400'
              : isInProgress
              ? 'text-[var(--brand-primary)]'
              : isLocked
              ? 'text-gray-500'
              : 'text-gray-400'
          }`}>
            {node.status === 'in_progress' ? 'In Progress' : node.status.replace('_', ' ')}
            {isInProgress && <Sparkles className="w-2.5 h-2.5 text-[var(--brand-primary)]" />}
          </span>

          <span className="text-[10px] text-[var(--brand-primary)] font-semibold group-hover:underline">
            View Details &rarr;
          </span>
        </div>
      </div>

      <Handle
        type="source"
        position={Position.Right}
        className="!w-3 !h-3 !-right-1.5 !bg-[var(--brand-primary)] !border-2 !border-gray-900 transition-transform hover:scale-125"
      />
    </div>
  );
};
