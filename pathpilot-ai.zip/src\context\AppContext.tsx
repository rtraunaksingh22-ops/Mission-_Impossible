import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  UserProfile,
  Roadmap,
  ProjectRecommendation,
  AppSettings,
  NodeStatus,
  CareerGapAnalysis,
  WhatIfScenario,
  RecoveryPlan,
  LearningStrategy,
  User,
  ThemeSettings,
  ThemeMode,
  AccentColor
} from '../types';
import { sampleRoadmaps, javaBackendRoadmap } from '../data/mockRoadmaps';
import { curatedProjects } from '../data/mockProjects';
import { calculateCareerGap, simulateWhatIf, generateAdaptiveRecoveryPlan } from '../services/analysisEngine';
import { loginApi, registerApi, fetchMeApi, saveUserDataApi } from '../services/api';

const STORAGE_KEYS = {
  PROFILE: 'pathpilot_profile',
  ROADMAPS: 'pathpilot_roadmaps',
  ACTIVE_ROADMAP: 'pathpilot_active_roadmap_id',
  PROJECTS: 'pathpilot_projects',
  SETTINGS: 'pathpilot_settings',
  TOKEN: 'pathpilot_auth_token',
  USER: 'pathpilot_user',
  THEME: 'pathpilot_theme'
};

const defaultProfile: UserProfile = {
  dreamJob: 'Java Backend Developer',
  specialization: 'Spring Boot & Scalable Microservices',
  industry: 'Fintech & Banking Technology',
  targetCompany: 'Razorpay / Stripe / Product MNCs',
  targetRegion: 'India & Global Tech Hubs',
  timelineMonths: 12,
  isExploring: false,
  education: 'Undergraduate',
  degree: 'Computer Science and Engineering',
  yearOfStudy: '3rd Year',
  workExperience: 'Personal & Academic Projects',
  skills: [
    { name: 'Java', proficiency: 'Intermediate' },
    { name: 'Git', proficiency: 'Intermediate' },
    { name: 'SQL', proficiency: 'Basic' },
    { name: 'Data Structures', proficiency: 'Basic' }
  ],
  certifications: ['Oracle Certified Associate (in-progress)'],
  portfolioUrl: 'https://github.com/student-dev',
  confidenceLevel: 6,
  hoursPerDay: 2,
  studyDaysPerWeek: 5,
  weeklyStudyHours: 10,
  budget: 'Budget Friendly',
  learningStyle: 'Balanced Combination',
  learningStrategy: 'balanced',
  targetDate: '2027-03-31'
};

const defaultTheme: ThemeSettings = {
  mode: 'dark', // DEFAULT THEME IS DARK MODE
  accent: 'indigo'
};

const defaultSettings: AppSettings = {
  aiProvider: 'demo',
  geminiApiKey: '',
  openaiApiKey: '',
  model: 'gemini-1.5-pro',
  isDemoMode: true,
  theme: defaultTheme
};

type AppContextType = {
  // User & Auth
  currentUser: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  isSyncing: boolean;
  lastSyncedAt: string | null;
  syncToServer: () => Promise<void>;

  // Theme
  theme: ThemeSettings;
  setThemeMode: (mode: ThemeMode) => void;
  setAccentColor: (accent: AccentColor) => void;

  // Career & Roadmap
  profile: UserProfile;
  setProfile: (profile: UserProfile) => void;
  roadmaps: Record<string, Roadmap>;
  activeRoadmap: Roadmap;
  setActiveRoadmapId: (id: string) => void;
  updateNodeStatus: (roadmapId: string, nodeId: string, status: NodeStatus) => void;
  updateNodeNotes: (roadmapId: string, nodeId: string, notes: string) => void;
  saveNewRoadmap: (roadmap: Roadmap) => void;
  projects: ProjectRecommendation[];
  updateProjectStatus: (projectId: string, status: 'not_started' | 'in_progress' | 'completed') => void;
  settings: AppSettings;
  updateSettings: (settings: Partial<AppSettings>) => void;
  careerGap: CareerGapAnalysis;
  runWhatIf: (weeklyHours: number, timelineMonths: number, strategy: LearningStrategy) => WhatIfScenario;
  applyWhatIf: (scenario: WhatIfScenario) => void;
  runAdaptiveRecovery: (availableWeeklyHours: number) => RecoveryPlan;
  applyAdaptiveRecovery: (plan: RecoveryPlan, targetWeeklyHours?: number) => void;
  resetToDemoDefaults: () => void;
  exportDataJson: () => string;
  importDataJson: (json: string) => boolean;
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Theme State (DARK MODE DEFAULT)
  const [theme, setTheme] = useState<ThemeSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.THEME);
      return saved ? JSON.parse(saved) : defaultTheme;
    } catch {
      return defaultTheme;
    }
  });

  // Apply Theme & Accent to DOM
  useEffect(() => {
    const root = document.documentElement;
    if (theme.mode === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
    }
    root.setAttribute('data-accent', theme.accent);
    localStorage.setItem(STORAGE_KEYS.THEME, JSON.stringify(theme));
  }, [theme]);

  // 2. Auth State
  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem(STORAGE_KEYS.TOKEN);
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USER);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);

  // 3. Profile State
  const [profile, setProfileState] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return saved ? JSON.parse(saved) : defaultProfile;
    } catch {
      return defaultProfile;
    }
  });

  // 4. Roadmaps State
  const [roadmaps, setRoadmaps] = useState<Record<string, Roadmap>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ROADMAPS);
      return saved ? JSON.parse(saved) : sampleRoadmaps;
    } catch {
      return sampleRoadmaps;
    }
  });

  // 5. Active Roadmap ID
  const [activeRoadmapId, setActiveRoadmapId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ACTIVE_ROADMAP);
      return saved || 'java-backend-fintech';
    } catch {
      return 'java-backend-fintech';
    }
  });

  // 6. Projects State
  const [projects, setProjects] = useState<ProjectRecommendation[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROJECTS);
      return saved ? JSON.parse(saved) : curatedProjects;
    } catch {
      return curatedProjects;
    }
  });

  // 7. Settings State
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return saved ? JSON.parse(saved) : defaultSettings;
    } catch {
      return defaultSettings;
    }
  });

  // LocalStorage Persistence
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROADMAPS, JSON.stringify(roadmaps));
  }, [roadmaps]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_ROADMAP, activeRoadmapId);
  }, [activeRoadmapId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  // Synchronize authenticated session on startup
  useEffect(() => {
    if (token) {
      fetchMeApi(token)
        .then(({ user, userData }) => {
          setCurrentUser(user);
          localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
          if (userData) {
            if (userData.profile) setProfileState(userData.profile);
            if (userData.roadmaps) setRoadmaps(userData.roadmaps);
            if (userData.activeRoadmapId) setActiveRoadmapId(userData.activeRoadmapId);
            if (userData.projects) setProjects(userData.projects);
            if (userData.settings) setSettings(userData.settings);
            setLastSyncedAt(new Date().toLocaleTimeString());
          }
        })
        .catch(() => {
          // Token expired
          setToken(null);
          setCurrentUser(null);
          localStorage.removeItem(STORAGE_KEYS.TOKEN);
          localStorage.removeItem(STORAGE_KEYS.USER);
        });
    }
  }, [token]);

  // Auto-sync data to backend when logged in
  const syncToServer = useCallback(async () => {
    if (!token) return;
    setIsSyncing(true);
    try {
      await saveUserDataApi(token, {
        profile,
        roadmaps,
        activeRoadmapId,
        projects,
        settings
      });
      setLastSyncedAt(new Date().toLocaleTimeString());
    } catch (e) {
      console.warn('Backend sync failed:', e);
    } finally {
      setIsSyncing(false);
    }
  }, [token, profile, roadmaps, activeRoadmapId, projects, settings]);

  // Auth Handlers
  const login = async (email: string, password: string) => {
    const res = await loginApi(email, password);
    setToken(res.token);
    setCurrentUser(res.user);
    localStorage.setItem(STORAGE_KEYS.TOKEN, res.token);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(res.user));

    if (res.userData) {
      if (res.userData.profile) setProfileState(res.userData.profile);
      if (res.userData.roadmaps) setRoadmaps(res.userData.roadmaps);
      if (res.userData.activeRoadmapId) setActiveRoadmapId(res.userData.activeRoadmapId);
      if (res.userData.projects) setProjects(res.userData.projects);
      if (res.userData.settings) setSettings(res.userData.settings);
    }
    setLastSyncedAt(new Date().toLocaleTimeString());
  };

  const register = async (name: string, email: string, password: string) => {
    const res = await registerApi(name, email, password);
    setToken(res.token);
    setCurrentUser(res.user);
    localStorage.setItem(STORAGE_KEYS.TOKEN, res.token);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(res.user));

    // Initial sync of local state to newly created account
    await saveUserDataApi(res.token, {
      profile,
      roadmaps,
      activeRoadmapId,
      projects,
      settings
    });
    setLastSyncedAt(new Date().toLocaleTimeString());
  };

  const logout = () => {
    setToken(null);
    setCurrentUser(null);
    localStorage.removeItem(STORAGE_KEYS.TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER);
  };

  // Theme Handlers
  const setThemeMode = (mode: ThemeMode) => {
    setTheme(prev => ({ ...prev, mode }));
  };

  const setAccentColor = (accent: AccentColor) => {
    setTheme(prev => ({ ...prev, accent }));
  };

  const activeRoadmap = roadmaps[activeRoadmapId] || roadmaps['java-backend-fintech'] || javaBackendRoadmap;

  // Real-time career gap recalculation
  const careerGap = calculateCareerGap(activeRoadmap, profile);

  const setProfile = (newProfile: UserProfile) => {
    setProfileState(newProfile);
    if (token) setTimeout(syncToServer, 500);
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
    if (token) setTimeout(syncToServer, 500);
  };

  const updateNodeStatus = (roadmapId: string, nodeId: string, newStatus: NodeStatus) => {
    setRoadmaps(prev => {
      const targetRoadmap = prev[roadmapId];
      if (!targetRoadmap) return prev;

      const updatedNodes = targetRoadmap.nodes.map(node => {
        if (node.id === nodeId) {
          const isCompleting = newStatus === 'completed';
          return {
            ...node,
            status: newStatus,
            completedAt: isCompleting ? new Date().toISOString() : undefined
          };
        }
        return { ...node };
      });

      if (newStatus === 'completed') {
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.8 },
            colors: ['#6366F1', '#8B5CF6', '#10B981']
          });
        } catch {
          // ignore
        }
      }

      // Re-evaluate unlock status of downstream nodes
      const finalNodes = updatedNodes.map(node => {
        if (node.prerequisites && node.prerequisites.length > 0) {
          // Check each prerequisite for mandatory vs recommended
          const isMandatoryPrereq = (prereqId: string) => {
            const edge = targetRoadmap.edges?.find(e => e.source === prereqId && e.target === node.id);
            if (edge && edge.isMandatory !== undefined) {
              return edge.isMandatory;
            }
            const prereqNode = updatedNodes.find(n => n.id === prereqId);
            return prereqNode?.isMandatoryPrereq !== false;
          };

          const mandatoryPrereqIds = node.prerequisites.filter(isMandatoryPrereq);
          const allMandatoryMet = mandatoryPrereqIds.every(prereqId => {
            const prereqNode = updatedNodes.find(n => n.id === prereqId);
            return prereqNode?.status === 'completed';
          });

          if (allMandatoryMet) {
            if (node.status === 'locked') {
              return { ...node, status: 'not_started' as NodeStatus };
            }
          } else {
            if (node.status === 'not_started') {
              return { ...node, status: 'locked' as NodeStatus };
            }
          }
        }
        return node;
      });

      return {
        ...prev,
        [roadmapId]: {
          ...targetRoadmap,
          nodes: finalNodes,
          updatedAt: new Date().toISOString().split('T')[0]
        }
      };
    });

    if (token) setTimeout(syncToServer, 800);
  };

  const updateNodeNotes = (roadmapId: string, nodeId: string, notes: string) => {
    setRoadmaps(prev => {
      const targetRoadmap = prev[roadmapId];
      if (!targetRoadmap) return prev;
      return {
        ...prev,
        [roadmapId]: {
          ...targetRoadmap,
          nodes: targetRoadmap.nodes.map(n => n.id === nodeId ? { ...n, userNotes: notes } : n)
        }
      };
    });
    if (token) setTimeout(syncToServer, 800);
  };

  const saveNewRoadmap = (roadmap: Roadmap) => {
    setRoadmaps(prev => ({
      ...prev,
      [roadmap.id]: roadmap
    }));
    setActiveRoadmapId(roadmap.id);
    if (token) setTimeout(syncToServer, 800);
  };

  const updateProjectStatus = (projectId: string, status: 'not_started' | 'in_progress' | 'completed') => {
    setProjects(prev => prev.map(p => p.id === projectId ? { ...p, status } : p));
    if (token) setTimeout(syncToServer, 800);
  };

  const runWhatIf = (weeklyHours: number, timelineMonths: number, strategy: LearningStrategy) => {
    return simulateWhatIf(activeRoadmap, weeklyHours, timelineMonths, strategy);
  };

  const applyWhatIf = (scenario: WhatIfScenario) => {
    setRoadmaps(prev => {
      const current = prev[activeRoadmapId];
      if (!current) return prev;
      return {
        ...prev,
        [activeRoadmapId]: {
          ...current,
          weeklyHours: scenario.simulated.weeklyHours,
          timelineMonths: scenario.simulated.timelineMonths,
          strategy: scenario.simulated.strategy,
          updatedAt: new Date().toISOString().split('T')[0]
        }
      };
    });
    setProfileState(prev => ({
      ...prev,
      weeklyStudyHours: scenario.simulated.weeklyHours,
      timelineMonths: scenario.simulated.timelineMonths,
      learningStrategy: scenario.simulated.strategy
    }));
    if (token) setTimeout(syncToServer, 800);
  };

  const runAdaptiveRecovery = (availableWeeklyHours: number) => {
    return generateAdaptiveRecoveryPlan(activeRoadmap, availableWeeklyHours);
  };

  const applyAdaptiveRecovery = (plan: RecoveryPlan, targetWeeklyHours?: number) => {
    setRoadmaps(prev => {
      const current = prev[activeRoadmapId];
      if (!current) return prev;

      const deferredNodeIds = new Set(plan.tasksDeferred.map(d => d.nodeId));
      const movedTasksMap = new Map((plan.tasksMoved || []).map(m => [m.nodeId, m]));

      const updatedNodes = current.nodes.map(n => {
        if (deferredNodeIds.has(n.id)) {
          return {
            ...n,
            priority: 'optional' as const,
            description: n.description.includes('(Postponed to Sprint 2)')
              ? n.description
              : `${n.description} (Postponed to Sprint 2)`
          };
        }
        if (movedTasksMap.has(n.id)) {
          const moveInfo = movedTasksMap.get(n.id)!;
          return {
            ...n,
            description: n.description.includes('(Rescheduled')
              ? n.description
              : `${n.description} (Rescheduled to ${moveInfo.toPhase})`
          };
        }
        return n;
      });

      return {
        ...prev,
        [activeRoadmapId]: {
          ...current,
          nodes: updatedNodes,
          timelineMonths: plan.proposedTimelineMonths,
          weeklyHours: targetWeeklyHours ?? current.weeklyHours,
          updatedAt: new Date().toISOString().split('T')[0]
        }
      };
    });
    setProfileState(prev => ({
      ...prev,
      timelineMonths: plan.proposedTimelineMonths,
      weeklyStudyHours: targetWeeklyHours ?? prev.weeklyStudyHours
    }));
    if (token) setTimeout(syncToServer, 800);
  };

  const resetToDemoDefaults = () => {
    localStorage.clear();
    setProfileState(defaultProfile);
    setRoadmaps(sampleRoadmaps);
    setActiveRoadmapId('java-backend-fintech');
    setProjects(curatedProjects);
    setSettings(defaultSettings);
    setTheme(defaultTheme);
    setToken(null);
    setCurrentUser(null);
  };

  const exportDataJson = () => {
    const data = {
      profile,
      roadmaps,
      activeRoadmapId,
      projects,
      settings,
      theme,
      currentUser,
      version: '2.0.0',
      exportedAt: new Date().toISOString()
    };
    return JSON.stringify(data, null, 2);
  };

  const importDataJson = (json: string): boolean => {
    try {
      const data = JSON.parse(json);
      if (data.profile) setProfileState(data.profile);
      if (data.roadmaps) setRoadmaps(data.roadmaps);
      if (data.activeRoadmapId) setActiveRoadmapId(data.activeRoadmapId);
      if (data.projects) setProjects(data.projects);
      if (data.settings) setSettings(data.settings);
      if (data.theme) setTheme(data.theme);
      return true;
    } catch {
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        token,
        login,
        register,
        logout,
        isSyncing,
        lastSyncedAt,
        syncToServer,
        theme,
        setThemeMode,
        setAccentColor,
        profile,
        setProfile,
        roadmaps,
        activeRoadmap,
        setActiveRoadmapId,
        updateNodeStatus,
        updateNodeNotes,
        saveNewRoadmap,
        projects,
        updateProjectStatus,
        settings,
        updateSettings,
        careerGap,
        runWhatIf,
        applyWhatIf,
        runAdaptiveRecovery,
        applyAdaptiveRecovery,
        resetToDemoDefaults,
        exportDataJson,
        importDataJson
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
