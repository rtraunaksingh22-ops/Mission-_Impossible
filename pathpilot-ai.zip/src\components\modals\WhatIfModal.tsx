import React, { useState } from 'react';
import { X, Sliders, CheckCircle2, ArrowRight, Sparkles, RefreshCw } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { LearningStrategy, WhatIfScenario } from '../../types';

type WhatIfModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export const WhatIfModal: React.FC<WhatIfModalProps> = ({ isOpen, onClose }) => {
  const { activeRoadmap, runWhatIf, applyWhatIf } = useApp();

  const [weeklyHours, setWeeklyHours] = useState(activeRoadmap.weeklyHours || 10);
  const [timelineMonths, setTimelineMonths] = useState(activeRoadmap.timelineMonths || 12);
  const [strategy, setStrategy] = useState<LearningStrategy>(activeRoadmap.strategy || 'balanced');
  const [appliedSuccess, setAppliedSuccess] = useState(false);

  if (!isOpen) return null;

  const scenario: WhatIfScenario = runWhatIf(weeklyHours, timelineMonths, strategy);

  const handleApply = () => {
    applyWhatIf(scenario);
    setAppliedSuccess(true);
    setTimeout(() => {
      setAppliedSuccess(false);
      onClose();
    }, 1200);
  };

  const resetToBaseline = () => {
    setWeeklyHours(activeRoadmap.weeklyHours || 10);
    setTimelineMonths(activeRoadmap.timelineMonths || 12);
    setStrategy(activeRoadmap.strategy || 'balanced');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-gray-900 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-[#E6E9F1] dark:border-gray-800 flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-[#E6E9F1] dark:border-gray-800 flex items-center justify-between sticky top-0 bg-white/95 dark:bg-gray-900/95 backdrop-blur z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-[var(--brand-primary)] flex items-center justify-center border border-indigo-100 dark:border-indigo-900/50">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#172033] dark:text-white">
                What-If Career Simulator
              </h3>
              <p className="text-xs text-[#68738A] dark:text-gray-400">
                Test alternative study commitments & strategies without altering your roadmap.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-200 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Controls */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-5 rounded-2xl bg-gray-50 dark:bg-gray-800/60 border border-gray-100 dark:border-gray-700">
            {/* Weekly Hours */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-[#172033] dark:text-gray-300 mb-2">
                <span>Available Study Time:</span>
                <span className="text-[var(--brand-primary)] font-bold">{weeklyHours} hours/week</span>
              </div>
              <input
                type="range"
                min={4}
                max={30}
                step={1}
                value={weeklyHours}
                onChange={(e) => setWeeklyHours(Number(e.target.value))}
                className="w-full accent-[var(--brand-primary)]"
              />
              <div className="flex justify-between text-[10px] text-[#68738A] dark:text-gray-400 mt-1">
                <span>4h (Casual)</span>
                <span>15h (Standard)</span>
                <span>30h (Intensive)</span>
              </div>
            </div>

            {/* Target Timeline */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-[#172033] dark:text-gray-300 mb-2">
                <span>Target Timeline:</span>
                <span className="text-[var(--brand-primary)] font-bold">{timelineMonths} months</span>
              </div>
              <input
                type="range"
                min={3}
                max={24}
                step={1}
                value={timelineMonths}
                onChange={(e) => setTimelineMonths(Number(e.target.value))}
                className="w-full accent-[var(--brand-primary)]"
              />
              <div className="flex justify-between text-[10px] text-[#68738A] dark:text-gray-400 mt-1">
                <span>3 mo (Sprint)</span>
                <span>12 mo (1 Year)</span>
                <span>24 mo (2 Years)</span>
              </div>
            </div>

            {/* Strategy Radio */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-[#172033] dark:text-gray-300 mb-2">
                Curriculum Focus Strategy:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'balanced', label: 'Balanced' },
                  { id: 'foundation_first', label: 'Theory First' },
                  { id: 'project_first', label: 'Project First' },
                  { id: 'interview_focused', label: 'Interview Prep' }
                ].map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setStrategy(s.id as LearningStrategy)}
                    className={`py-2 px-2.5 rounded-xl text-xs font-semibold transition-all border ${
                      strategy === s.id
                        ? 'bg-[var(--brand-primary)] text-white border-[var(--brand-primary)] shadow-xs'
                        : 'bg-white dark:bg-gray-800 text-[#68738A] dark:text-gray-400 border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Comparison Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Baseline Card */}
            <div className="p-4 rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#68738A] dark:text-gray-400">
                Current Active Plan
              </span>
              <div className="mt-2 space-y-1 text-xs">
                <p className="text-[#172033] dark:text-white font-medium">
                  {activeRoadmap.weeklyHours} hours/week · {activeRoadmap.timelineMonths} months target
                </p>
                <p className="text-[#68738A] dark:text-gray-400 capitalize">
                  Strategy: {activeRoadmap.strategy.replace('_', ' ')}
                </p>
              </div>
            </div>

            {/* Simulated Card */}
            <div className={`p-4 rounded-2xl border-2 transition-all ${
              scenario.feasibility === 'feasible'
                ? 'border-emerald-400 dark:border-emerald-600 bg-emerald-50/30 dark:bg-emerald-950/20'
                : scenario.feasibility === 'tight'
                ? 'border-amber-400 dark:border-amber-600 bg-amber-50/30 dark:bg-amber-950/20'
                : 'border-red-400 dark:border-red-600 bg-red-50/30 dark:bg-red-950/20'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--brand-primary)]">
                  Simulated Outcome
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold capitalize ${
                  scenario.feasibility === 'feasible'
                    ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                    : scenario.feasibility === 'tight'
                    ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                    : 'bg-red-100 dark:bg-red-950/60 text-red-800 dark:text-red-300'
                }`}>
                  {scenario.feasibility}
                </span>
              </div>
              <div className="mt-2 space-y-1 text-xs">
                <p className="text-[#172033] dark:text-white font-bold">
                  Predicted Completion: ~{scenario.predictedCompletionMonths} months
                </p>
                <p className="text-[#68738A] dark:text-gray-400">
                  Weekly Delta: {scenario.weeklyHoursDiff > 0 ? `+${scenario.weeklyHoursDiff}` : scenario.weeklyHoursDiff}h/week
                </p>
              </div>
            </div>
          </div>

          {/* Trade-offs & Recommendations */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 space-y-3">
            <h4 className="text-xs font-bold text-[var(--brand-primary)] uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Key Trade-Offs & Architectural Insights</span>
            </h4>
            <ul className="space-y-1.5">
              {scenario.tradeoffs.map((t, i) => (
                <li key={i} className="text-xs text-[#172033] dark:text-gray-200 flex items-start gap-2">
                  <span className="text-[var(--brand-primary)] font-bold">•</span>
                  <span>{t}</span>
                </li>
              ))}
            </ul>

            <div className="pt-2 border-t border-indigo-100/60 dark:border-indigo-900/50 text-xs text-[#172033] dark:text-gray-200">
              <span className="font-bold text-[var(--brand-primary)]">Recommended Action: </span>
              {scenario.recommendedAction}
            </div>
          </div>

          {appliedSuccess && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Roadmap updated successfully! Closing simulator...</span>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-6 border-t border-[#E6E9F1] dark:border-gray-800 bg-gray-50 dark:bg-gray-850 flex items-center justify-between sticky bottom-0">
          <button
            type="button"
            onClick={resetToBaseline}
            className="flex items-center gap-1.5 text-xs font-semibold text-[#68738A] dark:text-gray-400 hover:text-[#172033] dark:hover:text-white transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset to Current</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-[#68738A] dark:text-gray-400 hover:text-[#172033] dark:hover:text-white hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleApply}
              className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold text-white bg-[var(--brand-primary)] hover:opacity-90 shadow-sm shadow-[var(--brand-primary)]/25 transition-all"
            >
              <span>Apply Scenario to Roadmap</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
