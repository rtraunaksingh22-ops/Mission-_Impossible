import React, { useState } from 'react';
import {
  CheckCircle2,
  PlayCircle,
  Sparkles,
  ArrowRight,
  Target,
  Brain,
  Code2,
  Database,
  Cpu
} from 'lucide-react';

type PreviewNode = {
  id: string;
  title: string;
  phase: string;
  status: 'completed' | 'in_progress' | 'target' | 'upcoming';
  icon: React.ElementType;
  x: number;
  y: number;
};

export const HeroRoadmapPreview: React.FC = () => {
  const [activeNodeId, setActiveNodeId] = useState<string>('dest');

  const nodes: PreviewNode[] = [
    { id: 'n1', title: 'Python & Data Handling', phase: 'Phase 1', status: 'completed', icon: Code2, x: 18, y: 18 },
    { id: 'n2', title: 'ML & Vector Math', phase: 'Phase 2', status: 'completed', icon: Database, x: 18, y: 55 },
    { id: 'n3', title: 'Deep Learning & PyTorch', phase: 'Phase 3', status: 'in_progress', icon: Cpu, x: 50, y: 35 },
    { id: 'n4', title: 'RAG & Autonomous Agents', phase: 'Phase 4', status: 'upcoming', icon: Brain, x: 50, y: 75 },
    { id: 'dest', title: 'Destination: AI Engineer', phase: 'Target Role', status: 'target', icon: Target, x: 82, y: 50 }
  ];

  const activeNode = nodes.find(n => n.id === activeNodeId) || nodes[4];

  return (
    <div className="relative w-full rounded-3xl bg-white dark:bg-gray-900 border border-[#E6E9F1] dark:border-gray-800 shadow-xl p-5 overflow-hidden transition-all hover:shadow-2xl">
      {/* Background Subtle Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(var(--brand-primary)_1px,transparent_1px)] [background-size:16px_16px] opacity-15 pointer-events-none" />

      {/* Header Bar */}
      <div className="relative z-10 flex items-center justify-between pb-3 mb-3 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
          <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
          <span className="text-xs font-semibold text-[#172033] dark:text-white ml-2">
            Interactive Reverse-Map Preview
          </span>
        </div>
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[var(--brand-primary)]/15 text-[var(--brand-primary)]">
          <Sparkles className="w-2.5 h-2.5" />
          Live Interactive
        </span>
      </div>

      {/* Interactive Graph Canvas Area */}
      <div className="relative h-64 sm:h-72 w-full rounded-2xl bg-[#F7F8FC] dark:bg-[#0B0F19] border border-[#E6E9F1] dark:border-gray-800 overflow-hidden">
        {/* SVG Connecting Edges */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <defs>
            <linearGradient id="edgeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="50%" stopColor="#6366F1" />
              <stop offset="100%" stopColor="#8B5CF6" />
            </linearGradient>
          </defs>
          {/* n1 -> n3 */}
          <path d="M 100 60 C 160 60, 160 110, 220 110" stroke="url(#edgeGradient)" strokeWidth="2.5" fill="none" strokeDasharray="4 2" />
          {/* n2 -> n3 */}
          <path d="M 100 170 C 160 170, 160 110, 220 110" stroke="url(#edgeGradient)" strokeWidth="2.5" fill="none" />
          {/* n3 -> n4 */}
          <path d="M 270 120 C 270 180, 220 220, 250 220" stroke="#64748B" strokeWidth="2" fill="none" />
          {/* n3 -> dest */}
          <path d="M 320 110 C 370 110, 360 145, 410 145" stroke="url(#edgeGradient)" strokeWidth="2.5" fill="none" />
          {/* n4 -> dest */}
          <path d="M 330 220 C 380 220, 380 160, 410 155" stroke="#64748B" strokeWidth="2" fill="none" strokeDasharray="3 3" />
        </svg>

        {/* Nodes */}
        {nodes.map(n => {
          const Icon = n.icon;
          const isTarget = n.status === 'target';
          const isCompleted = n.status === 'completed';
          const isInProgress = n.status === 'in_progress';
          const isSelected = activeNodeId === n.id;

          return (
            <button
              key={n.id}
              onClick={() => setActiveNodeId(n.id)}
              style={{ left: `${n.x}%`, top: `${n.y}%`, transform: 'translate(-50%, -50%)' }}
              className={`absolute z-20 flex items-center gap-2 px-3 py-2 rounded-xl text-left transition-all duration-200 cursor-pointer shadow-xs ${
                isSelected
                  ? 'ring-2 ring-[var(--brand-primary)] shadow-md scale-105 z-30'
                  : 'hover:scale-102'
              } ${
                isTarget
                  ? 'bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-secondary)] text-white font-bold shadow-md shadow-[var(--brand-primary)]/30'
                  : isCompleted
                  ? 'bg-white dark:bg-gray-800 border border-emerald-400/50 text-[#172033] dark:text-gray-100'
                  : isInProgress
                  ? 'bg-white dark:bg-gray-800 border-2 border-[var(--brand-primary)] text-[#172033] dark:text-gray-100 shadow-xs'
                  : 'bg-white/90 dark:bg-gray-800/90 border border-gray-200 dark:border-gray-700 text-[#68738A] dark:text-gray-400'
              }`}
            >
              <div className={`p-1 rounded-lg ${
                isTarget
                  ? 'bg-white/20'
                  : isCompleted
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-500'
                  : isInProgress
                  ? 'bg-indigo-50 dark:bg-indigo-950/60 text-[var(--brand-primary)]'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400'
              }`}>
                <Icon className="w-3.5 h-3.5" />
              </div>
              <div className="flex flex-col">
                <span className={`text-[9px] uppercase tracking-wider font-semibold ${isTarget ? 'text-white/80' : 'text-[#68738A] dark:text-gray-400'}`}>
                  {n.phase}
                </span>
                <span className="text-[11px] font-bold truncate max-w-[110px] sm:max-w-[130px]">
                  {n.title}
                </span>
              </div>
              <div className="ml-1">
                {isCompleted && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />}
                {isInProgress && <PlayCircle className="w-3.5 h-3.5 text-[var(--brand-primary)] animate-pulse" />}
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Node Mini Insight */}
      <div className="relative z-10 mt-3 p-3 rounded-2xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span className="font-bold text-[#172033] dark:text-white">
            {activeNode.title}
          </span>
          <span className="text-[#68738A] dark:text-gray-500">·</span>
          <span className="text-[11px] text-[#68738A] dark:text-gray-400 capitalize">
            Status: {activeNode.status.replace('_', ' ')}
          </span>
        </div>
        <span className="text-[11px] text-[var(--brand-primary)] font-semibold flex items-center gap-1">
          Explore Roadmaps <ArrowRight className="w-3 h-3" />
        </span>
      </div>
    </div>
  );
};
