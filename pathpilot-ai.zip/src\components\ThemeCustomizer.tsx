import React, { useState, useRef, useEffect } from 'react';
import { Palette, Moon, Sun, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AccentColor } from '../types';

const ACCENTS: Array<{ id: AccentColor; label: string; color: string }> = [
  { id: 'indigo', label: 'Electric Indigo', color: '#6366F1' },
  { id: 'emerald', label: 'Cyber Emerald', color: '#10B981' },
  { id: 'cyan', label: 'Neon Cyan', color: '#06B6D4' },
  { id: 'amber', label: 'Sunset Amber', color: '#F59E0B' },
  { id: 'rose', label: 'Rose Crimson', color: '#F43F5E' },
  { id: 'violet', label: 'Vivid Violet', color: '#A855F7' }
];

export const ThemeCustomizer: React.FC = () => {
  const { theme, setThemeMode, setAccentColor } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-gray-800/80 hover:bg-gray-700/80 border border-gray-700 text-gray-200 transition-all shadow-xs"
        title="Customize Theme & Colors"
      >
        <Palette className="w-3.5 h-3.5 text-[var(--brand-primary)]" />
        <span className="hidden sm:inline capitalize">{theme.accent}</span>
        {theme.mode === 'dark' ? <Moon className="w-3 h-3 text-indigo-300" /> : <Sun className="w-3 h-3 text-amber-400" />}
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-gray-900 border border-gray-800 shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-gray-800">
            <span className="text-xs font-bold text-gray-200 uppercase tracking-wider flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-[var(--brand-primary)]" />
              Theme & Colors
            </span>
            <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-800">
              Live Customizer
            </span>
          </div>

          {/* Mode Switcher (Dark Mode is Default) */}
          <div>
            <label className="block text-[11px] font-semibold text-gray-400 mb-2">
              Appearance Mode
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setThemeMode('dark')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                  theme.mode === 'dark'
                    ? 'bg-gray-800 text-white border-[var(--brand-primary)] shadow-sm'
                    : 'bg-gray-900/60 text-gray-400 border-gray-800 hover:border-gray-700'
                }`}
              >
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
                <span>Dark (Default)</span>
              </button>

              <button
                type="button"
                onClick={() => setThemeMode('light')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                  theme.mode === 'light'
                    ? 'bg-white text-gray-900 border-[var(--brand-primary)] shadow-sm'
                    : 'bg-gray-900/60 text-gray-400 border-gray-800 hover:border-gray-700'
                }`}
              >
                <Sun className="w-3.5 h-3.5 text-amber-500" />
                <span>Light</span>
              </button>
            </div>
          </div>

          {/* Accent Color Presets */}
          <div>
            <label className="block text-[11px] font-semibold text-gray-400 mb-2">
              Brand Accent Palette
            </label>
            <div className="grid grid-cols-3 gap-2">
              {ACCENTS.map((accent) => (
                <button
                  key={accent.id}
                  type="button"
                  onClick={() => setAccentColor(accent.id)}
                  className={`flex flex-col items-center gap-1.5 p-2 rounded-xl text-[10px] font-semibold border transition-all ${
                    theme.accent === accent.id
                      ? 'bg-gray-800 border-gray-600 text-white shadow-xs'
                      : 'bg-gray-900/40 border-gray-800 text-gray-400 hover:border-gray-700'
                  }`}
                >
                  <span
                    className="w-5 h-5 rounded-full flex items-center justify-center shadow-xs"
                    style={{ backgroundColor: accent.color }}
                  >
                    {theme.accent === accent.id && <Check className="w-3 h-3 text-white stroke-[3]" />}
                  </span>
                  <span className="truncate max-w-[65px]">{accent.label.split(' ')[1] || accent.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
