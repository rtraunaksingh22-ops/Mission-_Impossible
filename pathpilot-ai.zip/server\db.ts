import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'store.json');

export interface StoredUser {
  id: string;
  name: string;
  email: string;
  salt: string;
  hash: string;
  avatar?: string;
  createdAt: string;
}

export interface UserStoreData {
  profile?: any;
  roadmaps?: Record<string, any>;
  activeRoadmapId?: string;
  projects?: any[];
  settings?: any;
  updatedAt?: string;
}

interface DatabaseSchema {
  users: StoredUser[];
  userData: Record<string, UserStoreData>;
  sessions: Record<string, { userId: string; expiresAt: number }>;
}

let dbCache: DatabaseSchema | null = null;

function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
}

export function initDb(): DatabaseSchema {
  if (dbCache) return dbCache;

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      dbCache = JSON.parse(content);
      return dbCache!;
    } catch (e) {
      console.warn('Could not read existing db file, creating new one:', e);
    }
  }

  // Initial seed with demo user
  const demoSalt = crypto.randomBytes(16).toString('hex');
  const demoHash = hashPassword('password123', demoSalt);

  dbCache = {
    users: [
      {
        id: 'usr-demo-001',
        name: 'Demo Student',
        email: 'demo@pathpilot.ai',
        salt: demoSalt,
        hash: demoHash,
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        createdAt: new Date().toISOString()
      }
    ],
    userData: {
      'usr-demo-001': {
        activeRoadmapId: 'java-backend-fintech',
        updatedAt: new Date().toISOString()
      }
    },
    sessions: {}
  };

  saveDb();
  return dbCache!;
}

export function saveDb(): void {
  if (!dbCache) return;
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(dbCache, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write db to disk:', err);
  }
}

export function findUserByEmail(email: string): StoredUser | undefined {
  const db = initDb();
  return db.users.find(u => u.email.toLowerCase() === email.toLowerCase().trim());
}

export function findUserById(id: string): StoredUser | undefined {
  const db = initDb();
  return db.users.find(u => u.id === id);
}

export function registerUser(name: string, email: string, password: string): { user: StoredUser; token: string } {
  const db = initDb();
  const existing = findUserByEmail(email);
  if (existing) {
    throw new Error('An account with this email already exists.');
  }

  const salt = crypto.randomBytes(16).toString('hex');
  const hash = hashPassword(password, salt);
  const newUser: StoredUser = {
    id: 'usr-' + Date.now(),
    name: name.trim(),
    email: email.toLowerCase().trim(),
    salt,
    hash,
    createdAt: new Date().toISOString()
  };

  db.users.push(newUser);
  db.userData[newUser.id] = {
    updatedAt: new Date().toISOString()
  };

  const token = generateToken(newUser.id);
  saveDb();
  return { user: newUser, token };
}

export function loginUser(email: string, password: string): { user: StoredUser; token: string } {
  const user = findUserByEmail(email);
  if (!user) {
    throw new Error('Invalid email or password.');
  }

  const testHash = hashPassword(password, user.salt);
  if (testHash !== user.hash) {
    throw new Error('Invalid email or password.');
  }

  const token = generateToken(user.id);
  return { user, token };
}

export function generateToken(userId: string): string {
  const db = initDb();
  const token = 'tok_' + crypto.randomBytes(24).toString('hex');
  // 30 days session expiration
  const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;
  db.sessions[token] = { userId, expiresAt };
  saveDb();
  return token;
}

export function verifyToken(token: string): StoredUser | null {
  if (!token) return null;
  const db = initDb();
  const session = db.sessions[token];
  if (!session) return null;
  if (Date.now() > session.expiresAt) {
    delete db.sessions[token];
    saveDb();
    return null;
  }
  return findUserById(session.userId) || null;
}

export function getUserData(userId: string): UserStoreData {
  const db = initDb();
  return db.userData[userId] || {};
}

export function updateUserData(userId: string, data: Partial<UserStoreData>): UserStoreData {
  const db = initDb();
  const current = db.userData[userId] || {};
  db.userData[userId] = {
    ...current,
    ...data,
    updatedAt: new Date().toISOString()
  };
  saveDb();
  return db.userData[userId];
}
