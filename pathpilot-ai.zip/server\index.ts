import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { getAiConfig, generateRoadmapWithAi } from './aiService.js';
import {
  initDb,
  registerUser,
  loginUser,
  verifyToken,
  getUserData,
  updateUserData
} from './db.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Initialize persistent database
initDb();

// Authentication middleware
interface AuthenticatedRequest extends Request {
  user?: any;
}

function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }

  const token = authHeader.split(' ')[1];
  const user = verifyToken(token);
  if (!user) {
    res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
    return;
  }

  req.user = user;
  next();
}

// -----------------------------------------------------------------------------
// SYSTEM STATUS
// -----------------------------------------------------------------------------
app.get('/api/health', (req, res) => {
  res.json({ status: 'healthy', ok: true });
});

app.get('/api/status', (req, res) => {
  const config = getAiConfig();
  res.json({
    status: 'ok',
    hasAiKey: config.provider !== 'demo',
    provider: config.provider,
    timestamp: new Date().toISOString()
  });
});

// -----------------------------------------------------------------------------
// AUTHENTICATION ROUTES
// -----------------------------------------------------------------------------

// Register
app.post('/api/auth/register', (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    const { user, token } = registerUser(name, email, password);
    const safeUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      avatar: user.avatar,
      createdAt: user.createdAt
    };

    return res.status(201).json({
      message: 'Account created successfully!',
      user: safeUser,
      token
    });
  } catch (err: any) {
    return res.status(400).json({ error: err.message || 'Registration failed.' });
  }
});

// Login
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const { user, token } = loginUser(email, password);
    const safeUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      avatar: user.avatar,
      createdAt: user.createdAt
    };

    const userData = getUserData(user.id);

    return res.json({
      message: 'Signed in successfully!',
      user: safeUser,
      token,
      userData
    });
  } catch (err: any) {
    return res.status(401).json({ error: err.message || 'Invalid credentials.' });
  }
});

// Current User Profile (Me)
app.get('/api/auth/me', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user;
  const safeUser = {
    id: user.id,
    name: user.name,
    email: user.email,
    avatar: user.avatar,
    createdAt: user.createdAt
  };
  const userData = getUserData(user.id);
  res.json({ user: safeUser, userData });
});

// -----------------------------------------------------------------------------
// USER DATA STORAGE (CLOUD PERSISTENCE)
// -----------------------------------------------------------------------------

// Get User's Roadmaps, Profile & Settings
app.get('/api/user/data', authMiddleware, (req: AuthenticatedRequest, res) => {
  const userId = req.user.id;
  const data = getUserData(userId);
  res.json({ data });
});

// Update & Save User's Roadmaps, Profile & Settings to backend
app.put('/api/user/data', authMiddleware, (req: AuthenticatedRequest, res) => {
  const userId = req.user.id;
  const payload = req.body;
  const saved = updateUserData(userId, payload);
  res.json({
    message: 'Data safely synced and saved to server.',
    data: saved
  });
});

// -----------------------------------------------------------------------------
// AI ROADMAP GENERATION
// -----------------------------------------------------------------------------
app.post('/api/generate-roadmap', async (req, res) => {
  const userProfile = req.body;
  const config = getAiConfig();

  if (config.provider !== 'demo') {
    try {
      const aiResult = await generateRoadmapWithAi(userProfile, config);
      if (aiResult) {
        const phaseColumns: Record<string, number> = {
          p1: 60,
          p2: 420,
          p3: 780,
          p4: 1140,
          p5: 1500
        };

        const yCounters: Record<string, number> = {
          p1: 100,
          p2: 100,
          p3: 100,
          p4: 100,
          p5: 100
        };

        const nodesWithPositions = (aiResult.nodes || []).map((node: any, idx: number) => {
          const colX = phaseColumns[node.phaseId] || (60 + (idx % 5) * 360);
          const currentY = yCounters[node.phaseId] || 100;
          yCounters[node.phaseId] = currentY + 160;

          return {
            ...node,
            position: { x: colX, y: currentY }
          };
        });

        const roadmap = {
          ...aiResult,
          id: 'ai-' + Date.now(),
          targetRole: userProfile.dreamJob,
          specialization: userProfile.specialization || '',
          industry: userProfile.industry || '',
          region: userProfile.targetRegion || '',
          timelineMonths: userProfile.timelineMonths || 12,
          weeklyHours: userProfile.weeklyStudyHours || 10,
          strategy: userProfile.learningStrategy || 'balanced',
          nodes: nodesWithPositions,
          createdAt: new Date().toISOString().split('T')[0],
          updatedAt: new Date().toISOString().split('T')[0]
        };

        return res.json({ roadmap, source: 'ai' });
      }
    } catch (e) {
      console.warn('AI generation encountered error, falling back to deterministic response:', e);
    }
  }

  return res.json({
    source: 'demo',
    message: 'Using PathPilot deterministic generation engine.'
  });
});

app.listen(PORT, () => {
  console.log(`PathPilot AI backend running on http://localhost:${PORT}`);
});
