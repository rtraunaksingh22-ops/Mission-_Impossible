import React, { useState, useEffect } from 'react';
import {
  Settings,
  Key,
  RotateCcw,
  Download,
  Upload,
  CheckCircle2,
  Server,
  Cpu
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ResetDemoModal } from '../components/modals/ResetDemoModal';
import { checkServerStatus } from '../services/api';

export const SettingsPage: React.FC = () => {
  const { settings, updateSettings, exportDataJson, importDataJson, currentUser, lastSyncedAt } = useApp();

  const [geminiKey, setGeminiKey] = useState(settings.geminiApiKey || '');
  const [openaiKey, setOpenaiKey] = useState(settings.openaiApiKey || '');
  const [isDemo, setIsDemo] = useState(settings.isDemoMode);
  const [model, setModel] = useState(settings.model || 'gemini-1.5-pro');

  const [isResetOpen, setIsResetOpen] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  const [serverStatus, setServerStatus] = useState<{ status: string; hasAiKey: boolean; provider: string }>({
    status: 'checking...',
    hasAiKey: false,
    provider: 'demo'
  });

  useEffect(() => {
    checkServerStatus().then(setServerStatus);
  }, []);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      geminiApiKey: geminiKey,
      openaiApiKey: openaiKey,
      isDemoMode: isDemo,
      model
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleExport = () => {
    const json = exportDataJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pathpilot-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = importDataJson(content);
      if (success) {
        setImportStatus('Backup restored successfully!');
      } else {
        setImportStatus('Invalid JSON backup file.');
      }
      setTimeout(() => setImportStatus(null), 3000);
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-[#F7F8FC] dark:bg-[#0B0F19] text-[#172033] dark:text-gray-100 py-8 sm:py-12 transition-colors duration-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-[var(--brand-primary)]/15 text-[var(--brand-primary)] border border-[var(--brand-primary)]/30 mb-2">
            <Settings className="w-3.5 h-3.5" />
            <span>Configuration & Cloud Sync</span>
          </div>
          <h1 className="text-3xl font-extrabold text-[#172033] dark:text-white tracking-tight">
            Application Settings
          </h1>
          <p className="text-xs sm:text-sm text-[#68738A] dark:text-gray-400 mt-1">
            Configure backend database sync, AI generation provider connectivity, or export your saved roadmaps.
          </p>
        </div>

        {/* Server & Demo Mode Status Card */}
        <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-[#E6E9F1] dark:border-gray-800 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
              settings.isDemoMode
                ? 'bg-indigo-50 dark:bg-indigo-950/60 text-[var(--brand-primary)]'
                : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-500'
            }`}>
              <Cpu className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-[#172033] dark:text-white">
                  {settings.isDemoMode ? 'Curated Deterministic Engine' : 'Live AI Generation'}
                </h3>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  settings.isDemoMode
                    ? 'bg-[var(--brand-primary)]/15 text-[var(--brand-primary)]'
                    : 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300'
                }`}>
                  {settings.isDemoMode ? 'Demo Active' : 'Live Engine'}
                </span>
              </div>
              <p className="text-xs text-[#68738A] dark:text-gray-400 mt-0.5">
                Backend DB: <span className="font-mono text-[11px] text-emerald-500 font-semibold">{serverStatus.status}</span> · User: <span className="font-semibold text-[#172033] dark:text-gray-200">{currentUser ? currentUser.email : 'Local Guest (Sign in to sync)'}</span>{lastSyncedAt && <span> · Last synced: <span className="text-[var(--brand-primary)] font-mono">{lastSyncedAt}</span></span>}
              </p>
            </div>
          </div>

          <label className="flex items-center gap-3 cursor-pointer p-2.5 rounded-2xl bg-[#F7F8FC] dark:bg-gray-800 border border-[#E6E9F1] dark:border-gray-700">
            <span className="text-xs font-bold text-[#172033] dark:text-gray-300">Deterministic Fallback:</span>
            <input
              type="checkbox"
              checked={isDemo}
              onChange={(e) => setIsDemo(e.target.checked)}
              className="h-4 w-4 rounded border-gray-300 text-[var(--brand-primary)] focus:ring-[var(--brand-primary)]"
            />
          </label>
        </div>

        {/* AI Provider Config Form */}
        <form onSubmit={handleSaveSettings} className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-[#E6E9F1] dark:border-gray-800 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-4">
            <h3 className="text-base font-bold text-[#172033] dark:text-white flex items-center gap-2">
              <Key className="w-5 h-5 text-[var(--brand-primary)]" />
              <span>AI Provider API Configuration</span>
            </h3>
            <span className="text-[11px] text-[#68738A] dark:text-gray-400">Keys securely transmitted server-side</span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                Google Gemini API Key (Optional)
              </label>
              <input
                type="password"
                value={geminiKey}
                onChange={(e) => setGeminiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full px-3.5 py-2.5 rounded-xl text-xs font-mono border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
              />
              <p className="text-[11px] text-[#68738A] dark:text-gray-400 mt-1">
                Leave blank to use our high-fidelity curated career roadmaps.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                OpenAI API Key (Optional Alternative)
              </label>
              <input
                type="password"
                value={openaiKey}
                onChange={(e) => setOpenaiKey(e.target.value)}
                placeholder="sk-..."
                className="w-full px-3.5 py-2.5 rounded-xl text-xs font-mono border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                Preferred AI Generation Model
              </label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none"
              >
                <option value="gemini-1.5-pro">Google Gemini 1.5 Pro</option>
                <option value="gemini-1.5-flash">Google Gemini 1.5 Flash (Fast)</option>
                <option value="gpt-4o-mini">OpenAI GPT-4o Mini</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            {saveSuccess ? (
              <span className="text-xs font-bold text-emerald-500 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Settings updated!
              </span>
            ) : (
              <div />
            )}

            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-[var(--brand-primary)] hover:opacity-90 transition-all shadow-xs"
            >
              Save Configuration
            </button>
          </div>
        </form>

        {/* Data Persistence, Backup & Reset Section */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-[#E6E9F1] dark:border-gray-800 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-4">
            <h3 className="text-base font-bold text-[#172033] dark:text-white flex items-center gap-2">
              <Server className="w-5 h-5 text-[var(--brand-secondary)]" />
              <span>Data Management & Backup</span>
            </h3>
            <span className="text-[11px] text-[#68738A] dark:text-gray-400">
              {currentUser ? 'Cloud Backend + Local Cache' : 'Local Storage'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Export JSON */}
            <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex flex-col justify-between space-y-3">
              <div>
                <span className="text-xs font-bold text-[#172033] dark:text-white block">
                  Export Backup
                </span>
                <p className="text-[11px] text-[#68738A] dark:text-gray-400 mt-0.5">
                  Save all roadmaps and completion progress to a local JSON file.
                </p>
              </div>
              <button
                type="button"
                onClick={handleExport}
                className="w-full py-2 px-3 rounded-xl text-xs font-semibold text-[#172033] dark:text-white bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500 flex items-center justify-center gap-1.5 shadow-2xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export JSON</span>
              </button>
            </div>

            {/* Import JSON */}
            <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex flex-col justify-between space-y-3">
              <div>
                <span className="text-xs font-bold text-[#172033] dark:text-white block">
                  Restore Backup
                </span>
                <p className="text-[11px] text-[#68738A] dark:text-gray-400 mt-0.5">
                  Import a previous PathPilot roadmap backup file.
                </p>
              </div>
              <label className="w-full py-2 px-3 rounded-xl text-xs font-semibold text-[#172033] dark:text-white bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500 flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                <span>Import JSON</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImport}
                  className="hidden"
                />
              </label>
            </div>

            {/* Reset Defaults */}
            <div className="p-4 rounded-2xl bg-red-50/40 dark:bg-red-950/20 border border-red-100 dark:border-red-900/30 flex flex-col justify-between space-y-3">
              <div>
                <span className="text-xs font-bold text-red-600 dark:text-red-400 block">
                  Reset Demo Defaults
                </span>
                <p className="text-[11px] text-red-600/80 dark:text-red-400/80 mt-0.5">
                  Reset all progress and restore original curated tracks.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsResetOpen(true)}
                className="w-full py-2 px-3 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-700 flex items-center justify-center gap-1.5 shadow-2xs"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Demo</span>
              </button>
            </div>
          </div>

          {importStatus && (
            <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-100 dark:border-indigo-900/50 text-xs text-[var(--brand-primary)]">
              {importStatus}
            </div>
          )}
        </div>

        {/* Reset Confirmation Modal */}
        <ResetDemoModal isOpen={isResetOpen} onClose={() => setIsResetOpen(false)} />
      </div>
    </div>
  );
};
