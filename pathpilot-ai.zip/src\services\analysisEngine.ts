import {
  Roadmap,
  UserProfile,
  CareerGapAnalysis,
  WhatIfScenario,
  RecoveryPlan,
  LearningStrategy
} from '../types';

/**
 * Calculates a transparent, mathematically grounded career readiness score and gap analysis.
 */
export function calculateCareerGap(roadmap: Roadmap, profile: UserProfile): CareerGapAnalysis {
  const nodes = roadmap.nodes;
  if (!nodes || nodes.length === 0) {
    return {
      readinessScore: 0,
      demonstratedSkills: [],
      inProgressSkills: [],
      missingFoundationalSkills: [],
      highPriorityNextActions: [],
      scoreBreakdown: {
        foundationsScore: 0,
        coreTechScore: 0,
        projectsScore: 0,
        careerLaunchScore: 0,
        calculationFormula: 'No roadmap nodes available.'
      }
    };
  }

  // Group nodes by phase
  const p1Nodes = nodes.filter(n => n.phaseId === 'p1' || n.phaseId === 'cp1');
  const p2p3Nodes = nodes.filter(n => n.phaseId === 'p2' || n.phaseId === 'p3' || n.phaseId === 'cp2' || n.phaseId === 'cp3');
  const projectNodes = nodes.filter(n => n.type === 'project' || n.phaseId === 'p4' || n.phaseId === 'cp4');
  const launchNodes = nodes.filter(n => n.phaseId === 'p5' || n.phaseId === 'p6' || n.phaseId === 'cp5');

  const calcGroupCompletion = (group: typeof nodes) => {
    if (group.length === 0) return 0;
    const completedCount = group.filter(n => n.status === 'completed').length;
    const inProgressCount = group.filter(n => n.status === 'in_progress').length;
    return (completedCount * 1.0 + inProgressCount * 0.4) / group.length;
  };

  // Weighted phase scores (Foundations 40%, Core Tech 30%, Projects 20%, Launch 10%)
  const foundationsRatio = calcGroupCompletion(p1Nodes);
  const coreTechRatio = calcGroupCompletion(p2p3Nodes);
  const projectsRatio = calcGroupCompletion(projectNodes);
  const launchRatio = calcGroupCompletion(launchNodes);

  const foundationsScore = Math.round(foundationsRatio * 40);
  const coreTechScore = Math.round(coreTechRatio * 30);
  const projectsScore = Math.round(projectsRatio * 20);
  const careerLaunchScore = Math.round(launchRatio * 10);

  const readinessScore = Math.min(100, foundationsScore + coreTechScore + projectsScore + careerLaunchScore);

  // Demonstrated Skills: User's profile skills + completed roadmap skills
  const demonstratedSkills = profile.skills.map(s => {
    const matched = nodes
      .filter(n => n.title.toLowerCase().includes(s.name.toLowerCase()) || n.subtopics.some(sub => sub.toLowerCase().includes(s.name.toLowerCase())))
      .map(n => n.title);
    return {
      name: s.name,
      proficiency: s.proficiency,
      matchedNodes: matched
    };
  });

  // Also include completed nodes that might not be in profile explicitly
  nodes.filter(n => n.status === 'completed').forEach(n => {
    if (!demonstratedSkills.some(d => d.name.toLowerCase() === n.title.toLowerCase())) {
      demonstratedSkills.push({
        name: n.title,
        proficiency: 'Intermediate',
        matchedNodes: [n.title]
      });
    }
  });

  // In-Progress Skills
  const inProgressSkills = nodes
    .filter(n => n.status === 'in_progress')
    .map(n => ({
      name: n.title,
      progressPercent: 50 // Standard in-progress baseline
    }));

  // Missing Foundational Skills (Phase 1/2 nodes not yet completed)
  const missingFoundationalSkills = nodes
    .filter(n => (n.phaseId === 'p1' || n.phaseId === 'p2' || n.phaseId === 'cp1') && n.status !== 'completed')
    .map(n => ({
      name: n.title,
      priority: n.priority,
      reason: n.priority === 'critical' 
        ? 'Mandatory prerequisite for advanced framework & project modules'
        : 'Essential for technical interview rounds'
    }));

  // Next Recommended Actions (unlocked nodes with critical or high priority that are not started or in progress)
  const highPriorityNextActions = nodes
    .filter(n => (n.status === 'not_started' || n.status === 'in_progress'))
    .sort((a, b) => {
      // Prioritize in-progress, then critical, then lowest estimated hours (quick wins)
      if (a.status === 'in_progress' && b.status !== 'in_progress') return -1;
      if (b.status === 'in_progress' && a.status !== 'in_progress') return 1;
      if (a.priority === 'critical' && b.priority !== 'critical') return -1;
      if (b.priority === 'critical' && a.priority !== 'critical') return 1;
      return a.estimatedHours - b.estimatedHours;
    })
    .slice(0, 4)
    .map(n => ({
      nodeId: n.id,
      title: n.title,
      type: n.type,
      estimatedHours: n.estimatedHours,
      reason: n.status === 'in_progress'
        ? 'Currently active task — finish to unlock dependent nodes'
        : `High-impact milestone (${n.estimatedHours}h effort) to advance readiness`
    }));

  return {
    readinessScore,
    demonstratedSkills,
    inProgressSkills,
    missingFoundationalSkills,
    highPriorityNextActions,
    scoreBreakdown: {
      foundationsScore,
      coreTechScore,
      projectsScore,
      careerLaunchScore,
      calculationFormula: 'Readiness = Foundations (40%) + Core Tech (30%) + Practical Projects (20%) + Career Launch (10%)'
    }
  };
}

/**
 * Simulates a "What-If" career scenario without mutating the current roadmap.
 */
export function simulateWhatIf(
  roadmap: Roadmap,
  simulatedWeeklyHours: number,
  simulatedTimelineMonths: number,
  simulatedStrategy: LearningStrategy
): WhatIfScenario {
  const remainingHours = roadmap.nodes
    .filter(n => n.status !== 'completed')
    .reduce((acc, curr) => {
      if (curr.status === 'in_progress') return acc + curr.estimatedHours * 0.5;
      return acc + curr.estimatedHours;
    }, 0);

  // Weeks needed at simulated weekly study pace (including 15% consolidation factor)
  const weeksNeeded = Math.ceil((remainingHours * 1.15) / Math.max(1, simulatedWeeklyHours));
  const monthsNeeded = Number((weeksNeeded / 4.33).toFixed(1));

  const hoursDiff = simulatedWeeklyHours - roadmap.weeklyHours;
  const timelineDiff = simulatedTimelineMonths - roadmap.timelineMonths;

  let feasibility: 'feasible' | 'tight' | 'unrealistic' = 'feasible';
  const tradeoffs: string[] = [];

  if (monthsNeeded <= simulatedTimelineMonths * 0.85) {
    feasibility = 'feasible';
    tradeoffs.push(`Comfortable pace with a ${Math.round((simulatedTimelineMonths - monthsNeeded) * 4.33)} week buffer for revision and interview prep.`);
  } else if (monthsNeeded <= simulatedTimelineMonths * 1.1) {
    feasibility = 'tight';
    tradeoffs.push(`Achievable but demanding; requires consistent adherence with minimal margin for study breaks.`);
    tradeoffs.push('Consider postponing optional project modules to guarantee core interview readiness.');
  } else {
    feasibility = 'unrealistic';
    tradeoffs.push(`At ${simulatedWeeklyHours}h/week, completing the ${Math.round(remainingHours)} remaining curriculum hours will realistically require ~${monthsNeeded} months, exceeding your target of ${simulatedTimelineMonths} months.`);
    tradeoffs.push('Recommended: Extend your target timeline or increase available study hours to avoid burnout.');
  }

  if (simulatedStrategy === 'project_first') {
    tradeoffs.push('Project-First emphasis: Prioritizes hands-on coding milestones early, accelerating portfolio artifacts.');
  } else if (simulatedStrategy === 'foundation_first') {
    tradeoffs.push('Foundation-First emphasis: Deep dives into CS primitives and algorithms before tackling frameworks.');
  } else if (simulatedStrategy === 'interview_focused') {
    tradeoffs.push('Interview-Focused emphasis: Fast-tracks DSA patterns and system design, deferring non-essential tooling.');
  }

  let recommendedAction = '';
  if (feasibility === 'feasible') {
    recommendedAction = `Target is well within reach! You can safely adopt this ${simulatedWeeklyHours}h/week schedule.`;
  } else if (feasibility === 'tight') {
    recommendedAction = `Set a strict schedule of ${Math.round(simulatedWeeklyHours / 5)}h per weekday and reserve weekends for project milestones.`;
  } else {
    const recommendedHours = Math.ceil((remainingHours * 1.15) / (simulatedTimelineMonths * 4.33));
    recommendedAction = `To meet your ${simulatedTimelineMonths}-month goal, increase your capacity to ~${recommendedHours} hours/week, or extend timeline to ${Math.ceil(monthsNeeded)} months.`;
  }

  return {
    baseline: {
      weeklyHours: roadmap.weeklyHours,
      timelineMonths: roadmap.timelineMonths,
      strategy: roadmap.strategy
    },
    simulated: {
      weeklyHours: simulatedWeeklyHours,
      timelineMonths: simulatedTimelineMonths,
      strategy: simulatedStrategy
    },
    predictedCompletionMonths: monthsNeeded,
    feasibility,
    weeklyHoursDiff: hoursDiff,
    timelineDiffMonths: timelineDiff,
    tradeoffs,
    recommendedAction,
    affectedNodesCount: roadmap.nodes.filter(n => n.status !== 'completed').length
  };
}

/**
 * Generates an Adaptive Recovery Plan ("Get Back on Track") when deadlines are tight or behind.
 */
export function generateAdaptiveRecoveryPlan(roadmap: Roadmap, availableWeeklyHours: number): RecoveryPlan {
  const incompleteNodes = roadmap.nodes.filter(n => n.status !== 'completed');
  const overdueCount = incompleteNodes.filter(n => n.status === 'needs_review' || n.priority === 'critical').length;

  // Split into essential vs deferrable vs movable
  const criticalNodes = incompleteNodes.filter(n => n.priority === 'critical' || n.isMandatoryPrereq);
  const optionalNodes = incompleteNodes.filter(n => n.priority === 'optional');
  const mediumNodes = incompleteNodes.filter(n => n.priority === 'medium');

  const essentialHours = criticalNodes.reduce((acc, curr) => acc + curr.estimatedHours, 0);
  const revisedWeeks = Math.ceil((essentialHours * 1.1) / Math.max(1, availableWeeklyHours));
  const proposedMonths = Math.max(roadmap.timelineMonths, Math.ceil(revisedWeeks / 4.33));

  // Helper to get phase title
  const getPhaseTitle = (phaseId: string) => {
    return roadmap.phases.find(p => p.id === phaseId)?.title || phaseId;
  };

  // 1. Tasks Deferred: Optional modules that can safely wait for post-placement/bonus learning
  const deferredPool = optionalNodes.length > 0 ? optionalNodes : incompleteNodes.filter(n => n.priority !== 'critical').slice(-2);
  const tasksDeferred = deferredPool.slice(0, 3).map(n => ({
    nodeId: n.id,
    title: n.title,
    reason: `Deprioritized to secondary post-launch sprint (${getPhaseTitle(n.phaseId)}) to protect core interview & capstone milestones.`
  }));

  // 2. Tasks Moved / Rescheduled: Intermediate tasks that are shifted to later phases or flexible buffer
  const deferredIds = new Set(tasksDeferred.map(d => d.nodeId));
  const movedCandidates = (mediumNodes.length > 0 ? mediumNodes : incompleteNodes.filter(n => !deferredIds.has(n.id) && n.priority !== 'critical')).slice(0, 3);

  const tasksMoved = movedCandidates.map((n) => {
    const currentPhase = getPhaseTitle(n.phaseId);
    const currentPhaseIdx = roadmap.phases.findIndex(p => p.id === n.phaseId);
    const targetPhaseIndex = Math.min(roadmap.phases.length - 1, currentPhaseIdx >= 0 ? currentPhaseIdx + 1 : 1);
    const targetPhase = roadmap.phases[targetPhaseIndex]?.title || 'Buffer Sprint';
    return {
      nodeId: n.id,
      title: n.title,
      fromPhase: currentPhase,
      toPhase: targetPhase !== currentPhase ? targetPhase : `Later in ${currentPhase}`,
      reason: `Rescheduled to relieve immediate weekly workload by ${Math.round(n.estimatedHours / 2)} hrs and maintain consistent study velocity.`
    };
  });

  // 3. Tasks Retained: Core foundational milestones preserved in their active sequence
  const movedIds = new Set(tasksMoved.map(m => m.nodeId));
  const tasksRetained = criticalNodes
    .filter(n => !deferredIds.has(n.id) && !movedIds.has(n.id))
    .slice(0, 5)
    .map(n => ({
      nodeId: n.id,
      title: n.title,
      priority: n.priority,
      reason: 'Essential prerequisite for technical interview readiness and capstone development.'
    }));

  if (tasksRetained.length === 0 && incompleteNodes.length > 0) {
    tasksRetained.push({
      nodeId: incompleteNodes[0].id,
      title: incompleteNodes[0].title,
      priority: incompleteNodes[0].priority,
      reason: 'Essential prerequisite for technical interview readiness and capstone development.'
    });
  }

  const completedCount = roadmap.nodes.filter(n => n.status === 'completed').length;
  const scheduleChanges = [
    `Condensed ${incompleteNodes.length} pending tasks into a high-impact sequence focusing on ${tasksRetained.length} retained core milestones.`,
    `Rescheduled ${tasksMoved.length} intermediate modules to buffer sprints to prevent burnout.`,
    `Deferred ${tasksDeferred.length} non-essential topics to post-placement learning.`,
    `Adjusted pacing to ${availableWeeklyHours} hours/week, extending realistic completion window to ${proposedMonths} months.`,
    `Preserved 100% of your ${completedCount} completed milestones and earned competencies.`
  ];

  return {
    overdueCount,
    previousTimelineMonths: roadmap.timelineMonths,
    proposedTimelineMonths: proposedMonths,
    tasksDeferred,
    tasksMoved,
    tasksRetained,
    scheduleChanges,
    explanation: `This recovery plan removes bottlenecks by deferring optional secondary modules and rescheduling buffer tasks, while strictly protecting all core prerequisites and the final capstone project. By committing to ${availableWeeklyHours} focused hours per week, you stay on a mathematically sound track to career readiness.`
  };
}
