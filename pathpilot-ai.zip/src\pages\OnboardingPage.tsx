import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Compass,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Plus,
  X,
  AlertCircle,
  RotateCcw
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserProfile, SkillProficiency, LearningStrategy } from '../types';
import { generateRoadmapApi } from '../services/api';

const POPULAR_ROLES = [
  'Java Backend Developer',
  'AI Engineer',
  'Full-Stack Developer',
  'Cybersecurity Analyst',
  'Machine Learning Engineer',
  'Cloud / DevOps Engineer',
  'Data Analyst',
  'Mobile App Developer (Flutter/React Native)'
];

const COMMON_SKILLS = [
  'Java', 'Python', 'JavaScript', 'TypeScript', 'SQL', 'React', 'Node.js',
  'Git', 'HTML/CSS', 'Docker', 'Linux', 'Data Structures', 'Spring Boot'
];

export const OnboardingPage: React.FC = () => {
  const navigate = useNavigate();
  const { profile, setProfile, saveNewRoadmap, settings } = useApp();

  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<UserProfile>({ ...profile });
  const [newSkillName, setNewSkillName] = useState('');
  const [newSkillProficiency, setNewSkillProficiency] = useState<SkillProficiency>('Beginner');
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationPhase, setGenerationPhase] = useState(0);
  const [generationError, setGenerationError] = useState<string | null>(null);

  const generationPhases = [
    'Interpreting your career destination and industry benchmarks...',
    'Decomposing prerequisite skills and engineering foundations...',
    'Connecting skills to practical, high-impact projects...',
    'Organizing your milestone progression and timeline constraints...',
    'Synthesizing your interactive reverse-engineered career map...'
  ];

  // Helper to update form fields
  const updateField = <K extends keyof UserProfile>(field: K, value: UserProfile[K]) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      if (field === 'hoursPerDay' || field === 'studyDaysPerWeek') {
        const h = field === 'hoursPerDay' ? (value as number) : prev.hoursPerDay;
        const d = field === 'studyDaysPerWeek' ? (value as number) : prev.studyDaysPerWeek;
        updated.weeklyStudyHours = h * d;
      }
      return updated;
    });

    if (errors[field]) {
      setErrors(prev => {
        const copy = { ...prev };
        delete copy[field];
        return copy;
      });
    }
  };

  // Skill management
  const addSkill = (name: string, proficiency: SkillProficiency) => {
    if (!name.trim()) return;
    if (formData.skills.some(s => s.name.toLowerCase() === name.trim().toLowerCase())) return;

    setFormData(prev => ({
      ...prev,
      skills: [...prev.skills, { name: name.trim(), proficiency }]
    }));
    setNewSkillName('');
  };

  const removeSkill = (name: string) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s.name !== name)
    }));
  };

  const clearSkillsForZero = () => {
    setFormData(prev => ({ ...prev, skills: [] }));
  };

  // Step Validation
  const validateStep = (currentStep: number): boolean => {
    const errs: Record<string, string> = {};

    if (currentStep === 1) {
      if (!formData.dreamJob.trim()) {
        errs.dreamJob = 'Please specify a career destination or choose a suggested role.';
      }
      if (!formData.timelineMonths || formData.timelineMonths < 1) {
        errs.timelineMonths = 'Please select a valid timeline.';
      }
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(prev => Math.min(5, prev + 1));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleBack = () => {
    setStep(prev => Math.max(1, prev - 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Final Submission
  const handleGenerate = async (forceDemo: boolean = false) => {
    setIsGenerating(true);
    setGenerationError(null);
    setProfile(formData);

    // Multi-phase progress ticker
    const interval = setInterval(() => {
      setGenerationPhase(prev => (prev < generationPhases.length - 1 ? prev + 1 : prev));
    }, 700);

    try {
      const mode = forceDemo ? true : settings.isDemoMode;
      const result = await generateRoadmapApi(formData, mode);
      clearInterval(interval);
      saveNewRoadmap(result.roadmap);
      navigate(`/roadmap/${result.roadmap.id}`);
    } catch (err: any) {
      clearInterval(interval);
      console.error('Failed to generate roadmap:', err);
      setIsGenerating(false);
      setGenerationError(err?.message || 'Failed to synthesize roadmap. Please retry or generate with our deterministic engine.');
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F8FC] dark:bg-[#0B0F19] text-[#172033] dark:text-gray-100 py-8 sm:py-12 transition-colors duration-200">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        {/* Top Header & Step Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[var(--brand-primary)] to-[var(--brand-secondary)] flex items-center justify-center text-white">
                <Compass className="w-5 h-5" />
              </div>
              <span className="text-base font-bold text-[#172033] dark:text-white">
                PathPilot Career Setup
              </span>
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#68738A] dark:text-gray-400">
              Step {step} of 5
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2 rounded-full bg-gray-200 dark:bg-gray-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-secondary)] transition-all duration-300"
              style={{ width: `${(step / 5) * 100}%` }}
            />
          </div>
        </div>

        {/* Multi-step Form Card */}
        <div className="bg-white dark:bg-gray-900 rounded-3xl border border-[#E6E9F1] dark:border-gray-800 shadow-xl p-6 sm:p-10 relative overflow-hidden">
          {/* STEP 1: DESTINATION */}
          {step === 1 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
                  Step 1
                </span>
                <h2 className="text-2xl font-extrabold text-[#172033] dark:text-white mt-1">
                  Define Your Destination
                </h2>
                <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1">
                  Where do you want to arrive? The more specific your destination, the more accurate the reverse-engineered map.
                </p>
              </div>

              {/* Target Role input + quick buttons */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300">
                  Target Career / Dream Job Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.dreamJob}
                  onChange={(e) => updateField('dreamJob', e.target.value)}
                  placeholder="e.g. Java Backend Developer, AI Engineer, Cloud Architect..."
                  className={`w-full px-4 py-3 rounded-2xl text-sm border bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30 transition-all ${
                    errors.dreamJob ? 'border-red-400' : 'border-[#E6E9F1] dark:border-gray-700'
                  }`}
                />
                {errors.dreamJob && (
                  <p className="text-xs text-red-500 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" /> {errors.dreamJob}
                  </p>
                )}

                {/* Popular pills */}
                <div className="pt-2">
                  <span className="text-[11px] font-semibold text-[#68738A] dark:text-gray-400 mr-2">
                    Quick Picks:
                  </span>
                  <div className="flex flex-wrap gap-1.5 mt-1.5">
                    {POPULAR_ROLES.map(role => (
                      <button
                        key={role}
                        type="button"
                        onClick={() => updateField('dreamJob', role)}
                        className={`text-xs px-2.5 py-1 rounded-xl border transition-all ${
                          formData.dreamJob === role
                            ? 'bg-[var(--brand-primary)] text-white border-[var(--brand-primary)]'
                            : 'bg-gray-50 dark:bg-gray-800 text-[#68738A] dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-gray-300'
                        }`}
                      >
                        {role}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Specialization & Industry */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                    Specialization Focus (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.specialization}
                    onChange={(e) => updateField('specialization', e.target.value)}
                    placeholder="e.g. Spring Boot Microservices, Agentic RAG"
                    className="w-full px-4 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                    Target Industry / Sector
                  </label>
                  <input
                    type="text"
                    value={formData.industry}
                    onChange={(e) => updateField('industry', e.target.value)}
                    placeholder="e.g. Fintech, Healthcare, E-Commerce, SaaS"
                    className="w-full px-4 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                  />
                </div>
              </div>

              {/* Target Company & Region */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                    Dream Companies or Company Type
                  </label>
                  <input
                    type="text"
                    value={formData.targetCompany}
                    onChange={(e) => updateField('targetCompany', e.target.value)}
                    placeholder="e.g. Stripe, Razorpay, Series-A Startups"
                    className="w-full px-4 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                    Target Country or Region
                  </label>
                  <input
                    type="text"
                    value={formData.targetRegion}
                    onChange={(e) => updateField('targetRegion', e.target.value)}
                    placeholder="e.g. India, United States, Remote Global"
                    className="w-full px-4 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                  />
                </div>
              </div>

              {/* Timeline selector */}
              <div>
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-2">
                  Target Timeline to Job Readiness
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  {[3, 6, 12, 18, 24].map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => updateField('timelineMonths', m)}
                      className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                        formData.timelineMonths === m
                          ? 'bg-[var(--brand-primary)] text-white border-[var(--brand-primary)] shadow-xs'
                          : 'bg-gray-50 dark:bg-gray-800 text-[#68738A] dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {m} Months
                    </button>
                  ))}
                </div>
              </div>

              {/* Exploring Toggle */}
              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isExploring}
                    onChange={(e) => updateField('isExploring', e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300 text-[var(--brand-primary)] focus:ring-[var(--brand-primary)]"
                  />
                  <span className="text-xs text-[#68738A] dark:text-gray-400">
                    I am still exploring options (generates broader, exploratory foundational tracks)
                  </span>
                </label>
              </div>
            </div>
          )}

          {/* STEP 2: STARTING POINT */}
          {step === 2 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
                  Step 2
                </span>
                <h2 className="text-2xl font-extrabold text-[#172033] dark:text-white mt-1">
                  Understand Your Starting Point
                </h2>
                <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1">
                  What skills and experience do you already bring? We never assume knowledge you haven't explicitly verified.
                </p>
              </div>

              {/* Education Level */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                    Current Education / Status
                  </label>
                  <select
                    value={formData.education}
                    onChange={(e) => updateField('education', e.target.value as any)}
                    className="w-full px-3 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                  >
                    <option value="Undergraduate">Undergraduate Student</option>
                    <option value="Postgraduate">Postgraduate Student</option>
                    <option value="School">School Student</option>
                    <option value="Working Professional">Working Professional</option>
                    <option value="Career Changer">Career Changer</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                    Degree or Current Field
                  </label>
                  <input
                    type="text"
                    value={formData.degree}
                    onChange={(e) => updateField('degree', e.target.value)}
                    placeholder="e.g. B.Tech Computer Science, Mechanical..."
                    className="w-full px-3 py-2.5 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-[var(--brand-primary)]/30"
                  />
                </div>
              </div>

              {/* Skills Tag Management */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-[#172033] dark:text-gray-300">
                    Existing Technical Skills & Proficiencies
                  </label>
                  <button
                    type="button"
                    onClick={clearSkillsForZero}
                    className="text-[11px] font-semibold text-[var(--brand-primary)] hover:underline"
                  >
                    Start from Zero (No prior skills)
                  </button>
                </div>

                {/* Input row */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newSkillName}
                    onChange={(e) => setNewSkillName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addSkill(newSkillName, newSkillProficiency);
                      }
                    }}
                    placeholder="Add a skill (e.g. Java, Git, React)..."
                    className="flex-1 px-3 py-2 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white focus:bg-white dark:focus:bg-gray-800 focus:outline-none"
                  />
                  <select
                    value={newSkillProficiency}
                    onChange={(e) => setNewSkillProficiency(e.target.value as SkillProficiency)}
                    className="px-3 py-2 rounded-xl text-xs border border-[#E6E9F1] dark:border-gray-700 bg-[#F7F8FC] dark:bg-gray-800 text-[#172033] dark:text-white"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Basic">Basic</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                  <button
                    type="button"
                    onClick={() => addSkill(newSkillName, newSkillProficiency)}
                    className="px-3 py-2 rounded-xl text-xs font-bold text-white bg-[var(--brand-primary)] hover:opacity-90 flex items-center gap-1 shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>

                {/* Added tags */}
                <div className="flex flex-wrap gap-2 pt-1 min-h-[40px] p-3 rounded-2xl bg-gray-50 dark:bg-gray-800/60 border border-gray-100 dark:border-gray-700">
                  {formData.skills.length === 0 ? (
                    <span className="text-xs text-gray-400 dark:text-gray-500 italic">
                      No skills added yet. Click suggestions below or type custom skills above.
                    </span>
                  ) : (
                    formData.skills.map((s) => (
                      <span
                        key={s.name}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-semibold bg-white dark:bg-gray-800 border border-[#E6E9F1] dark:border-gray-700 text-[#172033] dark:text-gray-200 shadow-2xs"
                      >
                        <span>{s.name}</span>
                        <span className="text-[10px] text-[var(--brand-primary)] font-normal">
                          ({s.proficiency})
                        </span>
                        <button
                          type="button"
                          onClick={() => removeSkill(s.name)}
                          className="text-gray-400 hover:text-red-400"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))
                  )}
                </div>

                {/* Quick suggestions */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <span className="text-[11px] text-[#68738A] dark:text-gray-400 mr-1 self-center">
                    Suggestions:
                  </span>
                  {COMMON_SKILLS.map(cs => (
                    <button
                      key={cs}
                      type="button"
                      onClick={() => addSkill(cs, 'Basic')}
                      className="text-[11px] px-2 py-0.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-[#68738A] dark:text-gray-300 hover:border-[var(--brand-primary)] hover:text-[var(--brand-primary)] transition-colors"
                    >
                      + {cs}
                    </button>
                  ))}
                </div>
              </div>

              {/* Confidence Level Slider */}
              <div className="pt-2">
                <div className="flex justify-between text-xs font-semibold text-[#172033] dark:text-gray-300 mb-1">
                  <span>Current Confidence in Target Field:</span>
                  <span className="text-[var(--brand-primary)] font-bold">{formData.confidenceLevel} / 10</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={10}
                  value={formData.confidenceLevel}
                  onChange={(e) => updateField('confidenceLevel', Number(e.target.value))}
                  className="w-full accent-[var(--brand-primary)]"
                />
              </div>
            </div>
          )}

          {/* STEP 3: CONSTRAINTS & PREFERENCES */}
          {step === 3 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
                  Step 3
                </span>
                <h2 className="text-2xl font-extrabold text-[#172033] dark:text-white mt-1">
                  Set Constraints & Preferences
                </h2>
                <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1">
                  Sustainable schedules prevent burnout. We align milestone pacing with your actual capacity.
                </p>
              </div>

              {/* Study Time Capacity */}
              <div className="p-5 rounded-2xl bg-[#F7F8FC] dark:bg-gray-800/60 border border-[#E6E9F1] dark:border-gray-700 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                      Available Hours per Day: {formData.hoursPerDay} hrs
                    </label>
                    <input
                      type="range"
                      min={1}
                      max={8}
                      step={0.5}
                      value={formData.hoursPerDay}
                      onChange={(e) => updateField('hoursPerDay', Number(e.target.value))}
                      className="w-full accent-[var(--brand-primary)]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-1">
                      Study Days per Week: {formData.studyDaysPerWeek} days
                    </label>
                    <input
                      type="range"
                      min={1}
                      max={7}
                      value={formData.studyDaysPerWeek}
                      onChange={(e) => updateField('studyDaysPerWeek', Number(e.target.value))}
                      className="w-full accent-[var(--brand-primary)]"
                    />
                  </div>
                </div>

                <div className="pt-2 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#172033] dark:text-gray-300">
                    Derived Weekly Study Capacity:
                  </span>
                  <span className="px-3 py-1 rounded-xl bg-[var(--brand-primary)] text-white font-bold">
                    {formData.weeklyStudyHours} Hours / Week
                  </span>
                </div>
              </div>

              {/* Course Budget */}
              <div>
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-2">
                  Learning Resource Budget
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: 'Free Only', label: '100% Free Resources' },
                    { id: 'Budget Friendly', label: 'Budget Friendly (Books/Cheap Courses)' },
                    { id: 'Flexible', label: 'Flexible' }
                  ].map((b) => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => updateField('budget', b.id as any)}
                      className={`p-3 rounded-2xl text-xs font-semibold border transition-all text-center ${
                        formData.budget === b.id
                          ? 'bg-[var(--brand-primary)] text-white border-[var(--brand-primary)] shadow-xs'
                          : 'bg-gray-50 dark:bg-gray-800 text-[#68738A] dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Learning Style */}
              <div>
                <label className="block text-xs font-bold text-[#172033] dark:text-gray-300 mb-2">
                  Preferred Learning Style
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {[
                    'Hands-on Projects',
                    'Structured Courses',
                    'Documentation & Reading',
                    'Coding Challenges',
                    'Video-based',
                    'Balanced Combination'
                  ].map((style) => (
                    <button
                      key={style}
                      type="button"
                      onClick={() => updateField('learningStyle', style as any)}
                      className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all text-center ${
                        formData.learningStyle === style
                          ? 'bg-[var(--brand-primary)] text-white border-[var(--brand-primary)]'
                          : 'bg-gray-50 dark:bg-gray-800 text-[#68738A] dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: STRATEGY SELECTION */}
          {step === 4 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
                  Step 4
                </span>
                <h2 className="text-2xl font-extrabold text-[#172033] dark:text-white mt-1">
                  Select Roadmap Strategy
                </h2>
                <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1">
                  Which educational trajectory best suits your timeline and learning style?
                </p>
              </div>

              <div className="space-y-3">
                {[
                  {
                    id: 'foundation_first',
                    title: 'Foundation First',
                    desc: 'Build deep computer science fundamentals, data structures, and theory before advancing to frameworks.',
                    badge: 'Best for Beginners'
                  },
                  {
                    id: 'project_first',
                    title: 'Project First',
                    desc: 'Learn concepts just-in-time while building tangible production portfolio artifacts from day one.',
                    badge: 'Best for Builders'
                  },
                  {
                    id: 'balanced',
                    title: 'Balanced Journey (Recommended)',
                    desc: 'Combines structured theoretical fundamentals with practical capstones and automated test suites.',
                    badge: 'Recommended'
                  },
                  {
                    id: 'interview_focused',
                    title: 'Interview Focused',
                    desc: 'Prioritizes role-specific interview requirements, system design drills, and high-frequency LeetCode patterns.',
                    badge: 'Tight Deadlines'
                  }
                ].map((strat) => (
                  <div
                    key={strat.id}
                    onClick={() => updateField('learningStrategy', strat.id as LearningStrategy)}
                    className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-start justify-between gap-4 ${
                      formData.learningStrategy === strat.id
                        ? 'border-[var(--brand-primary)] bg-[var(--brand-primary)]/10 shadow-xs'
                        : 'border-[#E6E9F1] dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700 bg-white dark:bg-gray-800/80'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-[#172033] dark:text-white">
                          {strat.title}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          strat.badge === 'Recommended'
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                            : 'bg-gray-100 dark:bg-gray-750 text-gray-700 dark:text-gray-300'
                        }`}>
                          {strat.badge}
                        </span>
                      </div>
                      <p className="text-xs text-[#68738A] dark:text-gray-400 leading-relaxed">
                        {strat.desc}
                      </p>
                    </div>

                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                      formData.learningStrategy === strat.id
                        ? 'border-[var(--brand-primary)] bg-[var(--brand-primary)]'
                        : 'border-gray-300 dark:border-gray-600'
                    }`}>
                      {formData.learningStrategy === strat.id && (
                        <div className="w-2 h-2 rounded-full bg-white" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 5: REVIEW & GENERATE */}
          {step === 5 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
                  Step 5
                </span>
                <h2 className="text-2xl font-extrabold text-[#172033] dark:text-white mt-1">
                  Review & Reverse-Engineer
                </h2>
                <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1">
                  Verify your career specifications before generating your adaptive career roadmap.
                </p>
              </div>

              {/* Polished Summary Card */}
              <div className="p-6 rounded-3xl bg-[#F7F8FC] dark:bg-gray-800/60 border border-[#E6E9F1] dark:border-gray-700 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-gray-200 dark:border-gray-700">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-[var(--brand-primary)] tracking-wider">
                      Destination
                    </span>
                    <h3 className="text-lg font-bold text-[#172033] dark:text-white">
                      {formData.dreamJob || 'Exploratory Tech Path'}
                    </h3>
                  </div>
                  <button
                    onClick={() => setStep(1)}
                    className="text-xs font-bold text-[var(--brand-primary)] hover:underline"
                  >
                    Edit
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
                  <div className="p-2.5 rounded-xl bg-white dark:bg-gray-800/80 border border-gray-100 dark:border-gray-750 flex items-start justify-between">
                    <div>
                      <span className="text-[#68738A] dark:text-gray-400 block text-[11px]">Timeline</span>
                      <span className="font-bold text-[#172033] dark:text-white">{formData.timelineMonths} Months</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="text-[10px] text-[var(--brand-primary)] font-semibold hover:underline"
                    >
                      Edit
                    </button>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white dark:bg-gray-800/80 border border-gray-100 dark:border-gray-750 flex items-start justify-between">
                    <div>
                      <span className="text-[#68738A] dark:text-gray-400 block text-[11px]">Weekly Study</span>
                      <span className="font-bold text-[#172033] dark:text-white">{formData.weeklyStudyHours} hrs/wk</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setStep(3)}
                      className="text-[10px] text-[var(--brand-primary)] font-semibold hover:underline"
                    >
                      Edit
                    </button>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white dark:bg-gray-800/80 border border-gray-100 dark:border-gray-750 flex items-start justify-between">
                    <div>
                      <span className="text-[#68738A] dark:text-gray-400 block text-[11px]">Strategy</span>
                      <span className="font-bold text-[#172033] dark:text-white capitalize">{formData.learningStrategy.replace('_', ' ')}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setStep(4)}
                      className="text-[10px] text-[var(--brand-primary)] font-semibold hover:underline"
                    >
                      Edit
                    </button>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white dark:bg-gray-800/80 border border-gray-100 dark:border-gray-750 flex items-start justify-between">
                    <div>
                      <span className="text-[#68738A] dark:text-gray-400 block text-[11px]">Industry</span>
                      <span className="font-bold text-[#172033] dark:text-white">{formData.industry || 'Tech'}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="text-[10px] text-[var(--brand-primary)] font-semibold hover:underline"
                    >
                      Edit
                    </button>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white dark:bg-gray-800/80 border border-gray-100 dark:border-gray-750 flex items-start justify-between">
                    <div>
                      <span className="text-[#68738A] dark:text-gray-400 block text-[11px]">Budget</span>
                      <span className="font-bold text-[#172033] dark:text-white">{formData.budget}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setStep(3)}
                      className="text-[10px] text-[var(--brand-primary)] font-semibold hover:underline"
                    >
                      Edit
                    </button>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white dark:bg-gray-800/80 border border-gray-100 dark:border-gray-750 flex items-start justify-between">
                    <div>
                      <span className="text-[#68738A] dark:text-gray-400 block text-[11px]">Starting Skills</span>
                      <span className="font-bold text-[#172033] dark:text-white">{formData.skills.length} Registered</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="text-[10px] text-[var(--brand-primary)] font-semibold hover:underline"
                    >
                      Edit
                    </button>
                  </div>
                </div>
              </div>

              {/* Error and Retry State */}
              {generationError && (
                <div className="p-4 rounded-2xl bg-red-950/40 border border-red-800/80 text-xs space-y-3 animate-in fade-in">
                  <div className="flex items-start gap-2.5 text-red-300">
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-red-200">Roadmap Generation Interrupted</p>
                      <p className="text-red-300/80 mt-0.5">{generationError}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-1 flex-wrap">
                    <button
                      type="button"
                      onClick={() => handleGenerate(false)}
                      className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Retry Generation</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleGenerate(true)}
                      className="px-3.5 py-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-200 font-semibold text-xs border border-gray-700 transition-colors"
                    >
                      <span>Generate with Curated Engine</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Mode indicator reminder */}
              <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40 flex items-center justify-between text-xs text-[#172033] dark:text-gray-200">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[var(--brand-primary)]" />
                  <span>
                    Engine Mode: {settings.isDemoMode ? 'Curated Deterministic Generation' : 'Active AI Engine'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => navigate('/settings')}
                  className="text-xs font-bold text-[var(--brand-primary)] hover:underline"
                >
                  Configure Key
                </button>
              </div>
            </div>
          )}

          {/* Bottom Navigation Buttons */}
          <div className="mt-8 pt-6 border-t border-[#E6E9F1] dark:border-gray-800 flex items-center justify-between">
            {step > 1 ? (
              <button
                type="button"
                onClick={handleBack}
                disabled={isGenerating}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold text-[#68738A] dark:text-gray-400 hover:text-[#172033] dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            ) : (
              <div />
            )}

            {step < 5 ? (
              <button
                type="button"
                onClick={handleNext}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-[var(--brand-primary)] hover:opacity-90 shadow-sm shadow-[var(--brand-primary)]/25 transition-all"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleGenerate()}
                disabled={isGenerating}
                className="inline-flex items-center gap-2 px-7 py-3 rounded-2xl text-sm font-bold text-white bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-secondary)] hover:opacity-95 shadow-md shadow-[var(--brand-primary)]/30 transition-all transform active:scale-98"
              >
                <Sparkles className="w-4 h-4" />
                <span>Reverse-Engineer My Career</span>
              </button>
            )}
          </div>

          {/* Loading Overlay when generating */}
          {isGenerating && (
            <div className="absolute inset-0 bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm z-50 flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-200">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-[var(--brand-primary)] to-[var(--brand-secondary)] text-white flex items-center justify-center shadow-xl shadow-[var(--brand-primary)]/30 animate-pulse mb-6">
                <Compass className="w-8 h-8 animate-spin" />
              </div>
              <h3 className="text-xl font-bold text-[#172033] dark:text-white mb-2">
                Reverse-Engineering Your Career Map...
              </h3>
              <p className="text-xs text-[var(--brand-primary)] font-semibold max-w-sm transition-all duration-300">
                {generationPhases[generationPhase]}
              </p>

              <div className="w-48 h-1.5 bg-gray-200 dark:bg-gray-800 rounded-full mt-6 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-secondary)] transition-all duration-300"
                  style={{ width: `${((generationPhase + 1) / generationPhases.length) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
