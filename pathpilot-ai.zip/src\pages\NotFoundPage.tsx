import React from 'react';
import { Link } from 'react-router-dom';
import { Compass, ArrowLeft, Home } from 'lucide-react';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-[80vh] flex items-center justify-center p-6 bg-[#F7F8FC] dark:bg-[#0B0F19] transition-colors duration-200">
      <div className="max-w-md w-full bg-white dark:bg-gray-900 rounded-3xl border border-[#E6E9F1] dark:border-gray-800 shadow-xl p-8 text-center space-y-5">
        <div className="w-16 h-16 rounded-3xl bg-[var(--brand-primary)]/15 text-[var(--brand-primary)] flex items-center justify-center mx-auto">
          <Compass className="w-8 h-8" />
        </div>
        <div>
          <span className="text-4xl font-extrabold text-[#172033] dark:text-white font-mono">404</span>
          <h2 className="text-xl font-bold text-[#172033] dark:text-white mt-2">Destination Off-Track</h2>
          <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1.5 leading-relaxed">
            The career coordinates you requested do not exist. Let's redirect you back to your roadmap dashboard.
          </p>
        </div>
        <div className="pt-2 flex justify-center gap-3">
          <Link
            to="/dashboard"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-[var(--brand-primary)] hover:opacity-90 transition-all shadow-xs"
          >
            <Home className="w-4 h-4" />
            <span>Go to Dashboard</span>
          </Link>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-[#68738A] dark:text-gray-400 hover:text-[#172033] dark:hover:text-white bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Home</span>
          </Link>
        </div>
      </div>
    </div>
  );
};
