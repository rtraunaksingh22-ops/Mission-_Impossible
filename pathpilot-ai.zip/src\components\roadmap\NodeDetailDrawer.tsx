import React, { useState, useEffect } from 'react';
import {
  X,
  CheckCircle2,
  PlayCircle,
  RotateCcw,
  Clock,
  BookOpen,
  Code2,
  ExternalLink,
  Target,
  Sparkles,
  Link2,
  FileEdit,
  ShieldCheck,
  AlertTriangle,
  ChevronRight
} from 'lucide-react';
import { RoadmapNode, Roadmap, NodeStatus } from '../../types';
import { useApp } from '../../context/AppContext';

type NodeDetailDrawerProps = {
  node: RoadmapNode | null;
  roadmap: Roadmap;
  onClose: () => void;
  onSelectNode?: (node: RoadmapNode) => void;
};

export const NodeDetailDrawer: React.FC<NodeDetailDrawerProps> = ({
  node,
  roadmap,
  onClose,
  onSelectNode
}) => {
  const { updateNodeStatus, updateNodeNotes } = useApp();
  const [localNotes, setLocalNotes] = useState('');
  const [checkedObjectives, setCheckedObjectives] = useState<Record<number, boolean>>({});
  const [showReopenConfirm, setShowReopenConfirm] = useState(false);

  useEffect(() => {
    if (node) {
      setLocalNotes(node.userNotes || '');
      setCheckedObjectives({});
      setShowReopenConfirm(false);
    }
  }, [node?.id, node?.userNotes]);

  if (!node) return null;

  const handleStatusChange = (newStatus: NodeStatus) => {
    if (newStatus === 'not_started' && node.status === 'completed' && downstreamNodes.length > 0 && !showReopenConfirm) {
      setShowReopenConfirm(true);
      return;
    }
    setShowReopenConfirm(false);
    updateNodeStatus(roadmap.id, node.id, newStatus);
  };

  const confirmReopen = () => {
    setShowReopenConfirm(false);
    updateNodeStatus(roadmap.id, node.id, 'not_started');
  };

  const handleNotesBlur = () => {
    updateNodeNotes(roadmap.id, node.id, localNotes);
  };

  const toggleObjective = (idx: number) => {
    setCheckedObjectives(prev => ({
      ...prev,
      [idx]: !prev[idx]
    }));
  };

  // Find prerequisite nodes
  const prereqNodes = (node.prerequisites || []).map(pid =>
    roadmap.nodes.find(n => n.id === pid)
  ).filter(Boolean) as RoadmapNode[];

  // Find downstream nodes that depend on this node
  const downstreamNodes = roadmap.nodes.filter(n =>
    n.prerequisites && n.prerequisites.includes(node.id)
  );

  const isPrereqMandatory = (prereqId: string) => {
    const edge = roadmap.edges.find(e => e.source === prereqId && e.target === node.id);
    if (edge && edge.isMandatory === false) return false;
    const prereqNode = roadmap.nodes.find(n => n.id === prereqId);
    return prereqNode?.isMandatoryPrereq !== false;
  };

  const allMandatoryMet = prereqNodes
    .filter(p => isPrereqMandatory(p.id))
    .every(p => p.status === 'completed');

  return (
    <aside className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] lg:w-[540px] bg-gray-900 text-gray-100 shadow-2xl border-l border-gray-800 flex flex-col animate-in slide-in-from-right duration-250 ease-out">
      {/* Top Header */}
      <div className="p-6 border-b border-gray-800 bg-gray-900/90 backdrop-blur sticky top-0 z-10 flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[var(--brand-primary)]/20 text-[var(--brand-primary)] border border-[var(--brand-primary)]/30 capitalize">
              {node.type}
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-800 text-gray-300 border border-gray-700 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {node.estimatedHours} hrs effort
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold capitalize ${
              node.status === 'completed'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                : node.status === 'in_progress'
                ? 'bg-[var(--brand-primary)]/20 text-[var(--brand-primary)] border border-[var(--brand-primary)]/40'
                : node.status === 'locked'
                ? 'bg-gray-800 text-gray-400 border border-gray-700'
                : 'bg-blue-950 text-blue-300 border border-blue-800'
            }`}>
              {node.status.replace('_', ' ')}
            </span>
          </div>

          <h2 className="text-xl font-bold text-white leading-snug">
            {node.title}
          </h2>
        </div>

        <button
          onClick={onClose}
          className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
          aria-label="Close drawer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Scrollable Body Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 divide-y divide-gray-800">
        {/* Status Actions Bar */}
        <div className="pb-4">
          <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
            Update Progress State
          </label>
          <div className="grid grid-cols-3 gap-2.5">
            <button
              onClick={() => handleStatusChange('completed')}
              disabled={node.status === 'completed'}
              className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
                node.status === 'completed'
                  ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-500/30'
                  : 'bg-emerald-950/60 text-emerald-300 hover:bg-emerald-900/60 border border-emerald-800'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Complete</span>
            </button>

            <button
              onClick={() => handleStatusChange('in_progress')}
              disabled={node.status === 'in_progress'}
              className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
                node.status === 'in_progress'
                  ? 'bg-[var(--brand-primary)] text-white shadow-sm ring-2 ring-[var(--brand-primary)]/30'
                  : 'bg-gray-800 text-[var(--brand-primary)] hover:bg-gray-750 border border-gray-700'
              }`}
            >
              <PlayCircle className="w-4 h-4" />
              <span>In Progress</span>
            </button>

            <button
              onClick={() => handleStatusChange('not_started')}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-medium bg-gray-800 text-gray-300 hover:bg-gray-700 hover:text-white border border-gray-700 transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reopen</span>
            </button>
          </div>

          {/* Reopen Impact Confirmation */}
          {showReopenConfirm && (
            <div className="mt-3 p-3.5 rounded-xl bg-amber-950/70 border border-amber-800 text-xs text-amber-200 space-y-2 animate-in fade-in">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-amber-100">Downstream Reopen Impact</p>
                  <p className="text-amber-300/90 mt-0.5">
                    Reopening this completed milestone will re-lock {downstreamNodes.length} dependent task{downstreamNodes.length > 1 ? 's' : ''}:
                  </p>
                  <ul className="list-disc list-inside mt-1 space-y-0.5 text-[11px] text-amber-200/80">
                    {downstreamNodes.map(d => (
                      <li key={d.id} className="truncate">{d.title}</li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowReopenConfirm(false)}
                  className="px-3 py-1 rounded-lg bg-gray-800 text-gray-300 text-xs hover:bg-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={confirmReopen}
                  className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs"
                >
                  Confirm Reopen
                </button>
              </div>
            </div>
          )}

          {!allMandatoryMet && node.status !== 'completed' && (
            <div className="mt-3 p-3 rounded-xl bg-amber-950/50 border border-amber-800/80 flex items-start gap-2.5 text-xs text-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Prerequisite Attention</p>
                <p className="text-amber-300/80 mt-0.5">
                  Some mandatory prerequisites are still pending. Completing prerequisites first guarantees a smoother learning curve.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Why this node matters */}
        <div className="pt-5 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[var(--brand-primary)]">
            <Sparkles className="w-4 h-4" />
            <span>Why This Node Matters for {roadmap.targetRole}</span>
          </div>
          <div className="p-4 rounded-xl bg-gray-950/70 border border-gray-800 text-xs sm:text-sm text-gray-200 leading-relaxed">
            {node.whyItMatters}
          </div>
        </div>

        {/* Description & Overview */}
        <div className="pt-5 space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400">
            Overview
          </h3>
          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
            {node.description}
          </p>
        </div>

        {/* Learning Objectives with Interactive Checkboxes */}
        {node.learningObjectives && node.learningObjectives.length > 0 && (
          <div className="pt-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1.5">
                <Target className="w-4 h-4 text-[var(--brand-primary)]" />
                <span>Assessable Learning Objectives</span>
              </h3>
              <span className="text-[11px] text-gray-400">
                Check off as you master
              </span>
            </div>
            <div className="space-y-2">
              {node.learningObjectives.map((obj, i) => (
                <label
                  key={i}
                  className="flex items-start gap-3 p-2.5 rounded-xl border border-gray-800 hover:border-gray-700 bg-gray-950/40 hover:bg-gray-800/40 cursor-pointer transition-colors text-xs text-gray-200"
                >
                  <input
                    type="checkbox"
                    checked={!!checkedObjectives[i]}
                    onChange={() => toggleObjective(i)}
                    className="mt-0.5 h-4 w-4 rounded border-gray-700 bg-gray-900 text-[var(--brand-primary)] focus:ring-[var(--brand-primary)]"
                  />
                  <span className={checkedObjectives[i] ? 'line-through text-gray-500' : ''}>
                    {obj}
                  </span>
                </label>
              ))}
            </div>
          </div>
        )}

        {/* Recommended Subtopics */}
        {node.subtopics && node.subtopics.length > 0 && (
          <div className="pt-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-purple-400" />
              <span>Recommended Subtopics</span>
            </h3>
            <div className="flex flex-wrap gap-2">
              {node.subtopics.map((topic, i) => (
                <span
                  key={i}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium bg-gray-800 text-gray-200 border border-gray-700"
                >
                  {topic}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Practical Exercises */}
        {node.practicalExercises && node.practicalExercises.length > 0 && (
          <div className="pt-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1.5">
              <Code2 className="w-4 h-4 text-emerald-400" />
              <span>Hands-on Exercises</span>
            </h3>
            <ul className="space-y-2">
              {node.practicalExercises.map((ex, i) => (
                <li
                  key={i}
                  className="p-3 rounded-xl bg-gray-950/60 border border-gray-800 text-xs text-gray-200 leading-relaxed flex items-start gap-2.5"
                >
                  <span className="w-5 h-5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <span>{ex}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Curated Resources */}
        {node.suggestedResources && node.suggestedResources.length > 0 && (
          <div className="pt-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1.5">
              <Link2 className="w-4 h-4 text-blue-400" />
              <span>Curated Learning Resources</span>
            </h3>
            <div className="space-y-2">
              {node.suggestedResources.map((res, i) => (
                <a
                  key={i}
                  href={res.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3 rounded-xl border border-gray-800 hover:border-[var(--brand-primary)] bg-gray-950/50 hover:bg-gray-800/40 group transition-all"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-gray-200 group-hover:text-white transition-colors">
                      {res.title}
                    </span>
                    {res.isFree && (
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                        FREE
                      </span>
                    )}
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-gray-500 group-hover:text-[var(--brand-primary)] transition-colors" />
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Prerequisites Breakdown */}
        {prereqNodes.length > 0 && (
          <div className="pt-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[var(--brand-primary)]" />
              <span>Prerequisites</span>
            </h3>
            <div className="space-y-2">
              {prereqNodes.map(prereq => {
                const mandatory = isPrereqMandatory(prereq.id);
                return (
                  <button
                    key={prereq.id}
                    type="button"
                    onClick={() => onSelectNode && onSelectNode(prereq)}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl border border-gray-800 hover:border-[var(--brand-primary)]/50 bg-gray-950 text-xs text-left transition-colors group cursor-pointer"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-gray-200 group-hover:text-white">{prereq.title}</span>
                        <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider ${
                          mandatory
                            ? 'bg-red-950/70 text-red-300 border border-red-800/60'
                            : 'bg-blue-950/70 text-blue-300 border border-blue-800/60'
                        }`}>
                          {mandatory ? 'Mandatory' : 'Recommended'}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        prereq.status === 'completed'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}>
                        {prereq.status.replace('_', ' ')}
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 text-gray-500 group-hover:text-[var(--brand-primary)]" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Downstream Unlocks */}
        {downstreamNodes.length > 0 && (
          <div className="pt-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400">
              Next Unlocked Milestones ({downstreamNodes.length})
            </h3>
            <div className="space-y-1.5">
              {downstreamNodes.map(down => (
                <button
                  key={down.id}
                  type="button"
                  onClick={() => onSelectNode && onSelectNode(down)}
                  className="w-full flex items-center justify-between p-2.5 rounded-lg bg-gray-950 hover:bg-gray-800/70 text-xs text-gray-300 border border-gray-800 text-left transition-colors group cursor-pointer"
                >
                  <span className="group-hover:text-white truncate max-w-[320px]">{down.title}</span>
                  <div className="flex items-center gap-1.5 text-gray-400">
                    <span className="text-[10px]">{down.estimatedHours}h</span>
                    <ChevronRight className="w-3.5 h-3.5 group-hover:text-[var(--brand-primary)]" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Personal Student Notes */}
        <div className="pt-5 space-y-2 pb-6">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1.5">
            <FileEdit className="w-4 h-4 text-[var(--brand-primary)]" />
            <span>Personal Notes & Reflections</span>
          </h3>
          <textarea
            value={localNotes}
            onChange={(e) => setLocalNotes(e.target.value)}
            onBlur={handleNotesBlur}
            placeholder="Record insights, questions, code links, or key takeaways..."
            rows={3}
            className="w-full text-xs p-3 rounded-xl border border-gray-800 bg-gray-950 text-white focus:ring-1 focus:ring-[var(--brand-primary)] focus:border-[var(--brand-primary)] outline-none transition-all placeholder:text-gray-500"
          />
          <p className="text-[10px] text-gray-400">
            Auto-saves to browser storage & cloud backend when you click away.
          </p>
        </div>
      </div>
    </aside>
  );
};
