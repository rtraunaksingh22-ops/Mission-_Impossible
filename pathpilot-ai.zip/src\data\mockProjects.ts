import { ProjectRecommendation } from '../types';

export const curatedProjects: ProjectRecommendation[] = [
  {
    id: 'proj-ledger',
    title: 'Idempotent Double-Entry Financial Ledger API',
    tagline: 'High-throughput transactional ledger with ACID guarantees and Redis idempotency keys.',
    roleTarget: 'Java Backend Developer',
    complexity: 'Capstone',
    estimatedHours: 65,
    techStack: ['Java 21', 'Spring Boot 3', 'PostgreSQL', 'Redis', 'Docker', 'Testcontainers'],
    problemStatement: 'Financial platforms cannot tolerate split-brain states, double deductions, or lost ledger entries during network partitions.',
    keyFeatures: [
      'Strict double-entry bookkeeping (sum of debits equals sum of credits in atomic transaction)',
      'Distributed idempotency middleware preventing duplicate payment execution upon client retry',
      'Pessimistic row locking with isolation level tuning to guarantee balance integrity under concurrent spikes',
      'Comprehensive integration tests run via Testcontainers in CI/CD pipeline'
    ],
    resumeBullets: [
      'Engineered an ACID-compliant double-entry ledger REST API in Java 21/Spring Boot handling 2,500 requests/sec with zero balance discrepancies.',
      'Designed distributed Redis idempotency middleware eliminating duplicate transaction risks across concurrent mobile clients.',
      'Automated integration test harness with Testcontainers and Docker, achieving 92% code coverage.'
    ],
    learningOutcomes: [
      'Master transaction management (@Transactional) and database isolation levels.',
      'Implement cache-aside patterns and distributed lock semantics with Redis.',
      'Structure clean domain-driven architecture with clean DTO mapping.'
    ],
    githubTemplateUrl: 'https://github.com/example/fintech-ledger-starter',
    status: 'in_progress',
    roadmapNodeId: 'node-j8'
  },
  {
    id: 'proj-rag',
    title: 'Enterprise Document RAG Pipeline & Multi-Agent Assistant',
    tagline: 'Hybrid search QA engine with semantic chunking, Cohere re-ranking, and LangGraph tool execution.',
    roleTarget: 'AI Engineer',
    complexity: 'Advanced',
    estimatedHours: 55,
    techStack: ['Python 3.11', 'FastAPI', 'LangGraph', 'ChromaDB', 'OpenAI/Gemini API', 'Docker'],
    problemStatement: 'Raw LLM context windows suffer from hallucination and "Lost in the Middle" syndrome when querying 1,000+ page enterprise compliance documents.',
    keyFeatures: [
      'Hybrid retrieval combining dense vector embeddings (BGE-large) with BM25 keyword search',
      'Cross-encoder re-ranking step boosting relevant chunk precision from 64% to 91%',
      'LangGraph cyclical supervisor agent that writes SQL queries, verifies syntax, and retrieves structured reports',
      'Automated Ragas evaluation pipeline measuring Faithfulness and Context Recall'
    ],
    resumeBullets: [
      'Built production RAG pipeline ingesting 10k+ compliance documents with hybrid BM25/Vector retrieval and Cohere re-ranking.',
      'Developed LangGraph agent workflow with automated SQL tool-calling and self-correcting validation loops.',
      'Achieved 0.89 Faithfulness score on Ragas evaluation benchmark across 150 ground-truth questions.'
    ],
    learningOutcomes: [
      'Understand vector space indexing, chunking trade-offs, and embedding fine-tuning.',
      'Architect cyclical agentic state machines with tool validation.',
      'Measure quantitative LLM performance beyond anecdotal vibe-checks.'
    ],
    githubTemplateUrl: 'https://github.com/example/rag-enterprise-engine',
    status: 'not_started',
    roadmapNodeId: 'node-ai4'
  },
  {
    id: 'proj-saas',
    title: 'Real-Time Collaborative Markdown & Workspace Engine',
    tagline: 'Multi-tenant collaboration platform with CRDT synchronization, role-based access, and Stripe billing.',
    roleTarget: 'Full-Stack Developer',
    complexity: 'Advanced',
    estimatedHours: 50,
    techStack: ['TypeScript', 'React 19', 'Node.js', 'PostgreSQL', 'Prisma', 'Socket.io', 'Tailwind CSS'],
    problemStatement: 'Distributed teams require instant, conflict-free collaborative editing with granular workspace permission controls.',
    keyFeatures: [
      'Real-time conflict-free document sync utilizing Yjs CRDTs and WebSockets',
      'Role-based access control (Admin, Editor, Viewer) enforced at database query level with Prisma middleware',
      'Stripe subscription lifecycle integration with webhook verification and seat-based billing',
      'Responsive, accessible UI with dark/light mode toggle and optimistic UI updates'
    ],
    resumeBullets: [
      'Architected full-stack collaborative workspace in React/Node.js supporting 100+ concurrent active edits per document.',
      'Implemented CRDT synchronization pipeline with Yjs and WebSockets, cutting latency by 60% compared to REST polling.',
      'Configured multi-tenant Stripe billing with automated subscription lifecycle event handling.'
    ],
    learningOutcomes: [
      'Master WebSocket protocols and real-time state synchronization.',
      'Implement robust multi-tenant authorization paradigms.',
      'Design accessible, high-performance UI systems in React.'
    ],
    githubTemplateUrl: 'https://github.com/example/collab-workspace-ts',
    status: 'not_started',
    roadmapNodeId: 'node-fs4'
  },
  {
    id: 'proj-soc',
    title: 'Automated SOC Incident Response & Threat Hunting Lab',
    tagline: 'End-to-end security monitoring suite with Sysmon ingestion, Splunk alerting, and automated containment.',
    roleTarget: 'Cybersecurity Analyst',
    complexity: 'Capstone',
    estimatedHours: 45,
    techStack: ['Splunk', 'Linux/Ubuntu', 'Python', 'Sysmon', 'Suricata IDS', 'Wireshark'],
    problemStatement: 'Security operations centers are overwhelmed by alert fatigue and lack automated triage workflows for rapid attack containment.',
    keyFeatures: [
      'Configured Sysmon event logging on test network to capture process hollowing and credential dumping',
      'Developed 12 custom Splunk correlation searches mapped directly to MITRE ATT&CK techniques',
      'Wrote Python incident response script that automatically isolates compromised host IP via firewall rules upon high-severity alert',
      'Authored 4 formal technical post-incident debrief reports following NIST SP 800-61 guidelines'
    ],
    resumeBullets: [
      'Deploys full SOC detection lab ingesting Windows Sysmon and Suricata alerts into Splunk enterprise.',
      'Mapped 12 threat scenarios to MITRE ATT&CK framework with sub-5-minute mean time to alert.',
      'Automated IP containment workflow using Python socket integration, slashing triage response time.'
    ],
    learningOutcomes: [
      'Master Splunk Search Processing Language (SPL) and alert correlation.',
      'Deepen forensic knowledge of Windows process hierarchies and malware behavior.',
      'Author industry-compliant technical incident documentation.'
    ],
    githubTemplateUrl: 'https://github.com/example/soc-threat-lab',
    status: 'not_started',
    roadmapNodeId: 'node-sec4'
  }
];
