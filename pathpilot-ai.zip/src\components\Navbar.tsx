import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Compass,
  Map,
  LayoutDashboard,
  FolderGit2,
  User,
  Settings,
  Sparkles,
  Menu,
  X,
  ArrowRight,
  LogIn,
  LogOut,
  RefreshCw
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ThemeCustomizer } from './ThemeCustomizer';
import { AuthModal } from './modals/AuthModal';

export const Navbar: React.FC = () => {
  const location = useLocation();
  const {
    activeRoadmap,
    settings,
    currentUser,
    logout,
    syncToServer,
    isSyncing,
    lastSyncedAt
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setUserDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navLinks = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Roadmap', path: `/roadmap/${activeRoadmap?.id || 'java-backend-fintech'}`, icon: Map },
    { name: 'Projects', path: '/projects', icon: FolderGit2 },
    { name: 'Profile', path: '/profile', icon: User },
    { name: 'Settings', path: '/settings', icon: Settings },
  ];

  const isActive = (path: string) => {
    if (path.startsWith('/roadmap')) {
      return location.pathname.startsWith('/roadmap');
    }
    return location.pathname === path;
  };

  return (
    <header className="sticky top-0 z-40 bg-gray-900/90 dark:bg-[#0B0F19]/90 backdrop-blur-md border-b border-gray-800 transition-all text-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center space-x-3">
          <Link to="/" className="flex items-center space-x-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-[var(--brand-gradient)] flex items-center justify-center text-white shadow-md shadow-[var(--brand-glow)] group-hover:scale-105 transition-transform">
              <Compass className="w-6 h-6 stroke-[2.2]" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                PathPilot <span className="text-[var(--brand-primary)]">AI</span>
              </span>
              <span className="text-[10px] uppercase tracking-wider font-semibold text-gray-400 -mt-1 hidden sm:inline">
                Career Roadmapper
              </span>
            </div>
          </Link>

          {/* Demo Mode / AI Live badge */}
          <Link
            to="/settings"
            className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-[var(--brand-primary)]/15 text-[var(--brand-primary)] border border-[var(--brand-primary)]/30 hover:bg-[var(--brand-primary)]/20 transition-colors"
            title="Click to view AI Configuration & Settings"
          >
            <Sparkles className="w-3 h-3" />
            {settings.isDemoMode ? 'Demo Mode' : 'AI Live Mode'}
          </Link>

          {/* Backend Cloud Sync Badge */}
          {currentUser && (
            <button
              onClick={syncToServer}
              disabled={isSyncing}
              className="hidden lg:inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 hover:bg-emerald-900/50 transition-colors"
              title={lastSyncedAt ? `Last saved to backend database at ${lastSyncedAt}` : 'Saved to backend'}
            >
              <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin text-emerald-400' : 'text-emerald-500'}`} />
              <span>{isSyncing ? 'Saving to Cloud...' : 'Cloud Synced'}</span>
            </button>
          )}
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-1">
          {navLinks.map(link => {
            const Icon = link.icon;
            const active = isActive(link.path);
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                  active
                    ? 'text-white bg-[var(--brand-primary)]/20 shadow-xs border border-[var(--brand-primary)]/30'
                    : 'text-gray-300 hover:text-white hover:bg-gray-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${active ? 'text-[var(--brand-primary)]' : 'text-gray-400'}`} />
                <span>{link.name}</span>
              </Link>
            );
          })}
        </nav>

        {/* Right CTA & Controls */}
        <div className="hidden sm:flex items-center space-x-2.5">
          {/* Theme & Accent Color Customizer */}
          <ThemeCustomizer />

          {/* User Auth: Login Button OR User Profile Menu */}
          {currentUser ? (
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-2xl bg-gray-800/80 hover:bg-gray-750 border border-gray-700 text-xs font-semibold text-white transition-all shadow-xs"
              >
                <div className="w-6 h-6 rounded-full bg-[var(--brand-primary)] text-white flex items-center justify-center font-bold text-[10px]">
                  {currentUser.name.charAt(0).toUpperCase()}
                </div>
                <span className="truncate max-w-[100px]">{currentUser.name}</span>
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-gray-900 border border-gray-800 shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-1">
                  <div className="px-3 py-2 border-b border-gray-800">
                    <p className="text-xs font-bold text-white truncate">{currentUser.name}</p>
                    <p className="text-[10px] text-gray-400 truncate">{currentUser.email}</p>
                  </div>

                  <Link
                    to={`/roadmap/${activeRoadmap?.id}`}
                    onClick={() => setUserDropdownOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white hover:bg-gray-800"
                  >
                    <Map className="w-3.5 h-3.5 text-[var(--brand-primary)]" />
                    <span>My Career Roadmap</span>
                  </Link>

                  <Link
                    to="/profile"
                    onClick={() => setUserDropdownOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white hover:bg-gray-800"
                  >
                    <User className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Career Profile</span>
                  </Link>

                  <button
                    onClick={() => { syncToServer(); setUserDropdownOpen(false); }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-emerald-400 hover:bg-gray-800 text-left"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Save to Backend Cloud</span>
                  </button>

                  <div className="border-t border-gray-800 pt-1">
                    <button
                      onClick={() => { logout(); setUserDropdownOpen(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-red-400 hover:bg-red-950/40 text-left"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => setAuthModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-gray-200 bg-gray-800/80 hover:bg-gray-700/80 border border-gray-700 hover:text-white transition-all shadow-xs"
            >
              <LogIn className="w-3.5 h-3.5 text-[var(--brand-primary)]" />
              <span>Sign In</span>
            </button>
          )}

          {/* Primary CTA */}
          <Link
            to="/onboarding"
            className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-[var(--brand-gradient)] hover:opacity-95 shadow-sm shadow-[var(--brand-glow)] hover:shadow-md transition-all transform active:scale-98"
          >
            <span>Build Roadmap</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* Mobile menu button */}
        <div className="flex lg:hidden items-center space-x-2">
          <ThemeCustomizer />
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-gray-800"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-gray-800 bg-gray-900 px-4 pt-3 pb-5 space-y-2 animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-gray-800">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-[var(--brand-primary)]/15 text-[var(--brand-primary)]">
              <Sparkles className="w-3 h-3" />
              {settings.isDemoMode ? 'Demo Mode' : 'AI Live Mode'}
            </span>

            {currentUser ? (
              <span className="text-xs font-semibold text-white">
                Hi, {currentUser.name}
              </span>
            ) : (
              <button
                onClick={() => { setMobileMenuOpen(false); setAuthModalOpen(true); }}
                className="text-xs font-bold text-[var(--brand-primary)]"
              >
                Sign In
              </button>
            )}
          </div>

          {navLinks.map(link => {
            const Icon = link.icon;
            const active = isActive(link.path);
            return (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center space-x-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                  active ? 'text-white bg-[var(--brand-primary)]/20 border border-[var(--brand-primary)]/30' : 'text-gray-300 hover:bg-gray-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{link.name}</span>
              </Link>
            );
          })}

          <div className="pt-2">
            <Link
              to="/onboarding"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-center gap-2 w-full px-4 py-2.5 rounded-xl text-sm font-bold text-white bg-[var(--brand-gradient)]"
            >
              <span>Build Roadmap</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      )}

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />
    </header>
  );
};
