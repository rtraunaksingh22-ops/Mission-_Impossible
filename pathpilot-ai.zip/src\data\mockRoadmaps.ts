import { Roadmap, RoadmapPhase, RoadmapNode, RoadmapEdge, UserProfile } from '../types';

// Curated 1: Java Backend Developer (Fintech Focus)
export const javaBackendRoadmap: Roadmap = {
  id: 'java-backend-fintech',
  title: 'Java Backend Developer — Fintech Engineering',
  targetRole: 'Java Backend Developer',
  specialization: 'Spring Boot & Scalable Microservices',
  industry: 'Fintech & Banking Technology',
  region: 'India & Global Tech Hubs',
  createdAt: '2026-03-01',
  updatedAt: '2026-03-15',
  timelineMonths: 12,
  weeklyHours: 10,
  totalEstimatedHours: 420,
  strategy: 'balanced',
  summary: 'A reverse-engineered mastery track designed to build industrial-grade Java backend systems, Spring Boot microservices, high-throughput caching, and fintech-compliant transaction safety.',
  phases: [
    { id: 'p1', title: 'Phase 1: Foundations', order: 1, description: 'Core Java, Object-Oriented principles, memory architecture, and modern version control.', estimatedWeeks: 8 },
    { id: 'p2', title: 'Phase 2: Core Engineering', order: 2, description: 'Data structures, algorithms, relational database design, and ACID transaction mechanics.', estimatedWeeks: 10 },
    { id: 'p3', title: 'Phase 3: Frameworks & Tools', order: 3, description: 'Spring Boot ecosystem, Spring Data JPA, Redis caching, and robust automated test suites.', estimatedWeeks: 12 },
    { id: 'p4', title: 'Phase 4: Practical Projects', order: 4, description: 'Production-ready financial ledger microservice and event-driven payment orchestrator.', estimatedWeeks: 10 },
    { id: 'p5', title: 'Phase 5: Scale & Interview', order: 5, description: 'Low-latency system design, concurrency optimization, and fintech technical interview drills.', estimatedWeeks: 6 },
    { id: 'p6', title: 'Phase 6: Career Launch', order: 6, description: 'Targeted tech applications, high-impact resume crafting, and fintech code walkthroughs.', estimatedWeeks: 6 }
  ],
  nodes: [
    // Phase 1
    {
      id: 'node-j1',
      phaseId: 'p1',
      title: 'Java 21 Fundamentals & OOP',
      description: 'Master classes, interfaces, polymorphism, Java memory model (Heap/Stack), and records.',
      type: 'skill',
      status: 'completed',
      priority: 'critical',
      estimatedHours: 35,
      whyItMatters: 'Every fintech product company demands deep proficiency in Java core semantics and memory safety to prevent production outages.',
      prerequisites: [],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Understand garbage collection basics and heap memory allocation.',
        'Apply SOLID principles cleanly in domain modeling.',
        'Use modern Java features including Pattern Matching and Sealed Classes.'
      ],
      subtopics: ['JVM Architecture', 'Object Oriented Programming', 'Generics & Type Safety', 'Java Collections Framework', 'Exception Hierarchy'],
      practicalExercises: [
        'Build an in-memory bank account balance tracker using Collections and custom Exceptions.',
        'Refactor inheritance hierarchy to follow Liskov Substitution Principle.'
      ],
      suggestedResources: [
        { title: 'Official Java SE 21 Docs', type: 'docs', url: 'https://docs.oracle.com/en/java/javase/21/', isFree: true },
        { title: 'Effective Java by Joshua Bloch', type: 'course', url: 'https://www.oreilly.com', isFree: false }
      ],
      position: { x: 50, y: 100 }
    },
    {
      id: 'node-j2',
      phaseId: 'p1',
      title: 'Git & Production Collaboration',
      description: 'Master trunk-based development, interactive rebasing, merge conflict resolution, and PR reviews.',
      type: 'skill',
      status: 'completed',
      priority: 'high',
      estimatedHours: 15,
      whyItMatters: 'Fintech engineering teams enforce rigorous Git branch protection and auditing for compliant code delivery.',
      prerequisites: [],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Execute interactive rebasing and squash messy commit histories.',
        'Write descriptive, conventional commit messages for audit trails.',
        'Configure GitHub actions for branch checks and linters.'
      ],
      subtopics: ['Git branching models', 'Git Rebase vs Merge', 'Cherry-pick and Bisect', 'GitHub Pull Request workflows'],
      practicalExercises: [
        'Set up a repository with protected main branch requiring signed commits and CI passing.'
      ],
      suggestedResources: [
        { title: 'Pro Git Book (Official)', type: 'docs', url: 'https://git-scm.com/book/en/v2', isFree: true }
      ],
      position: { x: 50, y: 280 }
    },

    // Phase 2
    {
      id: 'node-j3',
      phaseId: 'p2',
      title: 'Data Structures & Algorithmic Patterns',
      description: 'Hash tables, binary trees, heaps, graphs, time/space complexity analysis (Big-O).',
      type: 'skill',
      status: 'in_progress',
      priority: 'critical',
      estimatedHours: 45,
      whyItMatters: 'Top product companies test data structures heavily to ensure engineers can write performant queries and algorithms under high load.',
      prerequisites: ['node-j1'],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Analyze asymptotic time and space bounds accurately.',
        'Implement sliding window, two-pointer, and BFS/DFS traversal algorithms.',
        'Design LRU cache using LinkedHashMap or Doubly-Linked List + Hash Table.'
      ],
      subtopics: ['Arrays & HashMaps', 'Two Pointers & Sliding Window', 'Trees & Graphs', 'Dynamic Programming Fundamentals'],
      practicalExercises: [
        'Solve 40 targeted LeetCode Medium problems focusing on hash tables and graphs.',
        'Implement custom LRU Cache from scratch with O(1) operations.'
      ],
      suggestedResources: [
        { title: 'NeetCode 150 Algorithms', type: 'tutorial', url: 'https://neetcode.io', isFree: true }
      ],
      position: { x: 380, y: 80 }
    },
    {
      id: 'node-j4',
      phaseId: 'p2',
      title: 'PostgreSQL & ACID Transactions',
      description: 'Relational schema modeling, index optimization (B-Tree), foreign keys, locks, and isolation levels.',
      type: 'skill',
      status: 'in_progress',
      priority: 'critical',
      estimatedHours: 35,
      whyItMatters: 'Double-spending and ledger inconsistencies in financial applications are prevented entirely by database isolation guarantees.',
      prerequisites: ['node-j1'],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Design 3NF normalized financial schema with strict audit timestamps.',
        'Differentiate between Read Committed, Repeatable Read, and Serializable.',
        'Identify slow queries using EXPLAIN ANALYZE and create covering indexes.'
      ],
      subtopics: ['DDL/DML & Constraints', 'ACID properties & Row Locks', 'Database Indexing strategies', 'Transaction Isolation Levels'],
      practicalExercises: [
        'Model a double-entry ledger database with accounts, entries, and transaction journals.',
        'Simulate concurrent transfer operations in psql to test pessimistic row locking.'
      ],
      suggestedResources: [
        { title: 'Use The Index, Luke!', type: 'docs', url: 'https://use-the-index-luke.com', isFree: true }
      ],
      position: { x: 380, y: 260 }
    },

    // Phase 3
    {
      id: 'node-j5',
      phaseId: 'p3',
      title: 'Spring Boot 3 Core & REST APIs',
      description: 'Inversion of Control (IoC), Dependency Injection, Spring Web, validation, and standardized error handling.',
      type: 'module',
      status: 'not_started',
      priority: 'critical',
      estimatedHours: 40,
      whyItMatters: 'Spring Boot is the industry backbone of global enterprise backend systems, powering over 70% of financial microservices.',
      prerequisites: ['node-j3', 'node-j4'],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Configure Spring Beans and life cycle listeners without XML.',
        'Expose idempotent REST endpoints with clean HTTP status codes and RFC 7807 Problem Details.',
        'Apply Jakarta Validation annotations on DTOs with automated error responses.'
      ],
      subtopics: ['Spring Context & Auto-configuration', 'Spring MVC & REST Controllers', 'Global Exception Handling (@ControllerAdvice)', 'Configuration Properties & Profiles'],
      practicalExercises: [
        'Build an API for account registration with input validation and custom business exceptions.',
        'Write curl or Postman collection verifying edge cases.'
      ],
      suggestedResources: [
        { title: 'Official Spring Boot Reference', type: 'docs', url: 'https://spring.io/projects/spring-boot', isFree: true }
      ],
      position: { x: 720, y: 80 }
    },
    {
      id: 'node-j6',
      phaseId: 'p3',
      title: 'Spring Data JPA & Hibernate Optimizations',
      description: 'Repositories, entity relationships, lazy vs eager loading, N+1 query problem, and audit listeners.',
      type: 'skill',
      status: 'not_started',
      priority: 'critical',
      estimatedHours: 35,
      whyItMatters: 'Poor ORM mapping leads to catastrophic N+1 query spikes in high-volume payment processing.',
      prerequisites: ['node-j4', 'node-j5'],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Resolve N+1 problems using JOIN FETCH and EntityGraphs.',
        'Implement declarative transactions with @Transactional and rollback configurations.',
        'Use Spring Data Auditing for automatic createdAt / createdBy tracking.'
      ],
      subtopics: ['Entity Mapping (@Entity, @Table, @Id)', 'Relationships (@OneToMany, @ManyToOne)', 'JPQL & Specification API', 'HikariCP Connection Pool Tuning'],
      practicalExercises: [
        'Configure HikariCP and write an integration test verifying query count with Hypersistence optimizer.'
      ],
      suggestedResources: [
        { title: 'Vlad Mihalcea Hibernate Tips', type: 'tutorial', url: 'https://vladmihalcea.com', isFree: true }
      ],
      position: { x: 720, y: 260 }
    },
    {
      id: 'node-j7',
      phaseId: 'p3',
      title: 'Automated Testing (JUnit 5 & Mockito)',
      description: 'Unit testing, mocking service dependencies, and slice testing with @WebMvcTest & @DataJpaTest.',
      type: 'skill',
      status: 'not_started',
      priority: 'high',
      estimatedHours: 25,
      whyItMatters: 'Fintech employers require 85%+ test coverage with robust regression tests before any pull request is merged.',
      prerequisites: ['node-j5'],
      isMandatoryPrereq: false,
      learningObjectives: [
        'Write parameterized unit tests in JUnit 5 with AssertJ assertions.',
        'Mock external dependencies cleanly using Mockito.',
        'Use Testcontainers for spinning up disposable PostgreSQL instances in CI.'
      ],
      subtopics: ['JUnit 5 Lifecycle', 'Mockito stubbing & verification', 'Spring Boot Test Slices', 'Testcontainers with Docker'],
      practicalExercises: [
        'Write full suite testing money transfer with zero false positives under mock failures.'
      ],
      suggestedResources: [
        { title: 'Testcontainers Java Guide', type: 'docs', url: 'https://testcontainers.com', isFree: true }
      ],
      position: { x: 720, y: 440 }
    },

    // Phase 4
    {
      id: 'node-j8',
      phaseId: 'p4',
      title: 'Capstone: Double-Entry Financial Ledger API',
      description: 'Design and deploy a production-grade double-entry accounting ledger with idempotent transfer endpoints and Redis idempotency keys.',
      type: 'project',
      status: 'locked',
      priority: 'critical',
      estimatedHours: 65,
      whyItMatters: 'This capstone directly proves to hiring managers that you understand ACID guarantees, idempotency keys, and zero-loss financial accounting.',
      prerequisites: ['node-j5', 'node-j6', 'node-j7'],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Guarantee mathematical balance across debit and credit journal entries.',
        'Implement Redis-backed idempotency key middleware preventing duplicate payment submissions.',
        'Deploy via Docker Compose with healthchecks, Swagger UI, and Prometheus metrics.'
      ],
      subtopics: ['Double-Entry Accounting Architecture', 'Distributed Idempotency Keys', 'Pessimistic Locking & Deadlock Handling', 'Dockerization & OpenAPI 3.0 Specs'],
      practicalExercises: [
        'Run Apache Bench or JMeter with 1,000 concurrent requests to verify zero overdrafts or race conditions.',
        'Publish clean GitHub repo with architecture diagrams and API docs.'
      ],
      suggestedResources: [
        { title: 'Designing Data-Intensive Applications', type: 'course', url: 'https://dataintensive.net', isFree: false }
      ],
      position: { x: 1080, y: 150 }
    },
    {
      id: 'node-j9',
      phaseId: 'p4',
      title: 'Distributed Caching & Redis Integration',
      description: 'Cache-aside pattern, cache invalidation, Redis cluster basics, and rate limiting with token bucket.',
      type: 'module',
      status: 'locked',
      priority: 'high',
      estimatedHours: 25,
      whyItMatters: 'Critical for high-volume banking traffic to keep database latency under 15 milliseconds.',
      prerequisites: ['node-j6'],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Implement Cache-Aside and Write-Through caching patterns using Spring Cache annotations.',
        'Protect APIs with IP and User-level rate limiting using Bucket4j and Redis.'
      ],
      subtopics: ['Redis Data Types', 'Spring Cache Abstraction', 'Rate Limiting Algorithms', 'Cache Stampede Prevention'],
      practicalExercises: [
        'Add Redis rate limiting to payment endpoints permitting max 10 requests per minute.'
      ],
      suggestedResources: [
        { title: 'Redis Developer University', type: 'tutorial', url: 'https://university.redis.com', isFree: true }
      ],
      position: { x: 1080, y: 350 }
    },

    // Phase 5
    {
      id: 'node-j10',
      phaseId: 'p5',
      title: 'Low-Latency System Design & Concurrency',
      description: 'Thread pools, Virtual Threads (Java 21), message queues (Apache Kafka basics), and horizontal scaling.',
      type: 'skill',
      status: 'locked',
      priority: 'high',
      estimatedHours: 35,
      whyItMatters: 'System design rounds at product companies evaluate whether you can scale an API from 1,000 to 100,000 transactions per second.',
      prerequisites: ['node-j8', 'node-j9'],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Compare Virtual Threads vs Platform Thread pools in Java 21.',
        'Design an event-driven payment webhook system using Kafka topics and consumer groups.',
        'Model database sharding and read replicas.'
      ],
      subtopics: ['Virtual Threads (Project Loom)', 'Kafka Producer/Consumer Mechanics', 'Microservice Communication Patterns', 'Circuit Breakers (Resilience4j)'],
      practicalExercises: [
        'Produce a system design diagram for a split-bill payment app handling 50k peak QPS.'
      ],
      suggestedResources: [
        { title: 'System Design Primer', type: 'repo', url: 'https://github.com/donnemartin/system-design-primer', isFree: true }
      ],
      position: { x: 1440, y: 150 }
    },
    {
      id: 'node-j11',
      phaseId: 'p5',
      title: 'Backend Coding & Tech Interview Sprint',
      description: 'Timed live-coding drills, mock system design discussions, and debugging whiteboard scenarios.',
      type: 'assessment',
      status: 'locked',
      priority: 'critical',
      estimatedHours: 30,
      whyItMatters: 'Translates technical capability into rapid, confident communication during pressure-filled interview loops.',
      prerequisites: ['node-j8', 'node-j10'],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Explain trade-offs verbally while writing clean, modular Java code.',
        'Solve concurrency synchronization questions (e.g., Producer-Consumer, Deadlock detection).'
      ],
      subtopics: ['Behavioral STAR Method', 'Live Coding Communication', 'Concurrency Interview Questions', 'Database Tuning Questions'],
      practicalExercises: [
        'Conduct 3 peer mock interviews focusing on Spring Boot and transactional isolation.'
      ],
      suggestedResources: [
        { title: 'Pramp Mock Interviews', type: 'tutorial', url: 'https://www.pramp.com', isFree: true }
      ],
      position: { x: 1440, y: 350 }
    },

    // Phase 6
    {
      id: 'node-j12',
      phaseId: 'p6',
      title: 'Fintech Portfolio & Resume Optimization',
      description: 'Format GitHub repos with architecture diagrams, write quantitative bullet points, and build recruiter outreach deck.',
      type: 'application',
      status: 'locked',
      priority: 'high',
      estimatedHours: 15,
      whyItMatters: 'Differentiates you from 95% of candidates who only provide bare code without deployment proofs or benchmarks.',
      prerequisites: ['node-j8', 'node-j11'],
      isMandatoryPrereq: true,
      learningObjectives: [
        'Write impactful resume bullets using the Google XYZ formula: "Accomplished [X], measured by [Y], by doing [Z]".',
        'Record a 3-minute Loom video demo walking through ledger architecture and JMeter load tests.'
      ],
      subtopics: ['Technical Resume Architecture', 'GitHub README Polish', 'Video Code Walkthroughs', 'Target Company Networking'],
      practicalExercises: [
        'Audit your resume with 5 senior engineers or automated ATS checkers.'
      ],
      suggestedResources: [
        { title: 'Tech Interview Handbook', type: 'docs', url: 'https://www.techinterviewhandbook.org', isFree: true }
      ],
      position: { x: 1780, y: 240 }
    }
  ],
  edges: [
    { id: 'e-j1-j3', source: 'node-j1', target: 'node-j3', isMandatory: true },
    { id: 'e-j1-j4', source: 'node-j1', target: 'node-j4', isMandatory: true },
    { id: 'e-j3-j5', source: 'node-j3', target: 'node-j5', isMandatory: true },
    { id: 'e-j4-j5', source: 'node-j4', target: 'node-j5', isMandatory: true },
    { id: 'e-j4-j6', source: 'node-j4', target: 'node-j6', isMandatory: true },
    { id: 'e-j5-j6', source: 'node-j5', target: 'node-j6', isMandatory: true },
    { id: 'e-j5-j7', source: 'node-j5', target: 'node-j7', isMandatory: false },
    { id: 'e-j6-j8', source: 'node-j6', target: 'node-j8', isMandatory: true },
    { id: 'e-j7-j8', source: 'node-j7', target: 'node-j8', isMandatory: true },
    { id: 'e-j6-j9', source: 'node-j6', target: 'node-j9', isMandatory: true },
    { id: 'e-j8-j10', source: 'node-j8', target: 'node-j10', isMandatory: true },
    { id: 'e-j9-j10', source: 'node-j9', target: 'node-j10', isMandatory: false },
    { id: 'e-j8-j11', source: 'node-j8', target: 'node-j11', isMandatory: true },
    { id: 'e-j10-j11', source: 'node-j10', target: 'node-j11', isMandatory: true },
    { id: 'e-j8-j12', source: 'node-j8', target: 'node-j12', isMandatory: true },
    { id: 'e-j11-j12', source: 'node-j11', target: 'node-j12', isMandatory: true }
  ]
};

// Curated 2: AI Engineer
export const aiEngineerRoadmap: Roadmap = {
  id: 'ai-engineer-llm',
  title: 'AI Engineer — Generative AI & LLM Systems',
  targetRole: 'AI Engineer',
  specialization: 'Generative AI, RAG & Autonomous Agents',
  industry: 'Enterprise Software & Applied AI',
  region: 'Global Remote & Tech Hubs',
  createdAt: '2026-03-05',
  updatedAt: '2026-03-18',
  timelineMonths: 9,
  weeklyHours: 12,
  totalEstimatedHours: 380,
  strategy: 'project_first',
  summary: 'A fast-track journey into building production-ready AI applications: from neural fundamentals and embedding pipelines to agentic loops and scalable inference APIs.',
  phases: [
    { id: 'p1', title: 'Phase 1: Foundations', order: 1, description: 'Python data engineering, linear algebra, vector spaces, and API fundamentals.', estimatedWeeks: 6 },
    { id: 'p2', title: 'Phase 2: Deep Learning & NLP', order: 2, description: 'PyTorch essentials, Transformer attention mechanisms, and tokenization.', estimatedWeeks: 8 },
    { id: 'p3', title: 'Phase 3: LLM Engineering', order: 3, description: 'Prompt orchestration, embeddings, vector databases, and hybrid search.', estimatedWeeks: 8 },
    { id: 'p4', title: 'Phase 4: Agentic Systems', order: 4, description: 'Tool-calling agents, state machines (LangGraph), multi-agent loops, and evals.', estimatedWeeks: 8 },
    { id: 'p5', title: 'Phase 5: Production & Evals', order: 5, description: 'RAG Triad evaluation, latency optimization, caching, and guardrails.', estimatedWeeks: 6 }
  ],
  nodes: [
    {
      id: 'node-ai1',
      phaseId: 'p1',
      title: 'Python for AI & Vector Mathematics',
      description: 'NumPy array mechanics, vectorized operations, matrix dot products, and cosine similarity.',
      type: 'skill',
      status: 'completed',
      priority: 'critical',
      estimatedHours: 30,
      whyItMatters: 'All semantic search, embeddings, and neural operations fundamentally rely on vector operations and linear algebra.',
      prerequisites: [],
      isMandatoryPrereq: true,
      learningObjectives: ['Implement cosine similarity from scratch in NumPy', 'Handle multidimensional tensors and matrix multiplications'],
      subtopics: ['NumPy vectorization', 'Tensors & Dimensions', 'Vector spaces & Distance metrics', 'Python typing and async IO'],
      practicalExercises: ['Build a bare-metal semantic similarity search script using pure NumPy without libraries.'],
      suggestedResources: [{ title: '3Blue1Brown Linear Algebra', type: 'tutorial', url: 'https://3blue1brown.com', isFree: true }],
      position: { x: 50, y: 150 }
    },
    {
      id: 'node-ai2',
      phaseId: 'p2',
      title: 'Transformers & Attention Mechanisms',
      description: 'Self-attention, multi-head attention, positional embeddings, encoder vs decoder architectures.',
      type: 'skill',
      status: 'in_progress',
      priority: 'critical',
      estimatedHours: 40,
      whyItMatters: 'Understanding self-attention enables you to debug hallucination patterns, context window constraints, and token limits.',
      prerequisites: ['node-ai1'],
      isMandatoryPrereq: true,
      learningObjectives: ['Step through Q, K, V matrix calculations', 'Explain why quadratic attention complexity matters for long context'],
      subtopics: ['Self-Attention Equation', 'Transformer Blocks', 'Hugging Face Transformers library', 'Tokenizers (BPE & WordPiece)'],
      practicalExercises: ['Load and inspect internal attention weights of a small transformer model in PyTorch.'],
      suggestedResources: [{ title: 'The Illustrated Transformer (Jay Alammar)', type: 'docs', url: 'https://jalammar.github.io', isFree: true }],
      position: { x: 420, y: 150 }
    },
    {
      id: 'node-ai3',
      phaseId: 'p3',
      title: 'Advanced RAG & Vector Databases',
      description: 'Chunking strategies, embedding models, Pinecone/Chroma integration, hybrid BM25 search, and re-ranking.',
      type: 'module',
      status: 'not_started',
      priority: 'critical',
      estimatedHours: 45,
      whyItMatters: 'RAG is the dominant architecture used by companies today to ground LLMs in proprietary enterprise data.',
      prerequisites: ['node-ai2'],
      isMandatoryPrereq: true,
      learningObjectives: ['Implement semantic chunking vs sliding window chunking', 'Deploy a hybrid search pipeline combining dense vector embeddings with BM25 keywords'],
      subtopics: ['Vector Indexing (HNSW)', 'Cross-Encoder Re-ranking (Cohere)', 'Metadata Filtering', 'Lost in the Middle problem'],
      practicalExercises: ['Build a document QA system that answers questions over 500 pages of PDF technical specs with source citations.'],
      suggestedResources: [{ title: 'Pinecone Vector Search Handbook', type: 'docs', url: 'https://pinecone.io/learn', isFree: true }],
      position: { x: 800, y: 150 }
    },
    {
      id: 'node-ai4',
      phaseId: 'p4',
      title: 'Autonomous Agents & Tool Calling',
      description: 'Function calling schemas, ReAct loop pattern, memory persistence, and multi-agent coordination.',
      type: 'project',
      status: 'locked',
      priority: 'critical',
      estimatedHours: 60,
      whyItMatters: 'Next-generation AI jobs require building agents that not only converse, but execute API commands and self-correct when code breaks.',
      prerequisites: ['node-ai3'],
      isMandatoryPrereq: true,
      learningObjectives: ['Design strict JSON schemas for tool calling', 'Implement cyclic state machines with error recovery', 'Build an autonomous research agent that synthesizes web data'],
      subtopics: ['ReAct Prompting Pattern', 'Structured Outputs & Pydantic', 'Human-in-the-Loop approval patterns', 'LangGraph state transitions'],
      practicalExercises: ['Develop an AI SQL Assistant that writes, verifies, runs, and auto-corrects SQL queries on test databases.'],
      suggestedResources: [{ title: 'LangGraph Documentation', type: 'docs', url: 'https://langchain-ai.github.io/langgraph/', isFree: true }],
      position: { x: 1180, y: 150 }
    },
    {
      id: 'node-ai5',
      phaseId: 'p5',
      title: 'Production LLMOps & Guardrails',
      description: 'Ragas evaluation framework, prompt injection security, streaming responses, latency benchmarking, and rate limiting.',
      type: 'assessment',
      status: 'locked',
      priority: 'high',
      estimatedHours: 35,
      whyItMatters: 'Anyone can build a quick prototype, but companies hire engineers who can guarantee deterministic outputs, speed, and safety in production.',
      prerequisites: ['node-ai4'],
      isMandatoryPrereq: true,
      learningObjectives: ['Evaluate RAG pipelines using Faithfulness and Answer Relevance metrics', 'Prevent system prompt leakage and jailbreaking attempts'],
      subtopics: ['Ragas Framework', 'Semantic Caching (Redis/GPTCache)', 'Llama Guard & Content Moderation', 'OpenTelemetry Tracing'],
      practicalExercises: ['Run an automated test suite benchmarking RAG answer accuracy over 100 benchmark queries.'],
      suggestedResources: [{ title: 'Applied LLMOps Guide', type: 'docs', url: 'https://github.com', isFree: true }],
      position: { x: 1540, y: 150 }
    }
  ],
  edges: [
    { id: 'e-ai1-ai2', source: 'node-ai1', target: 'node-ai2', isMandatory: true },
    { id: 'e-ai2-ai3', source: 'node-ai2', target: 'node-ai3', isMandatory: true },
    { id: 'e-ai3-ai4', source: 'node-ai3', target: 'node-ai4', isMandatory: true },
    { id: 'e-ai4-ai5', source: 'node-ai4', target: 'node-ai5', isMandatory: true }
  ]
};

// Curated 3: Full-Stack Developer
export const fullStackRoadmap: Roadmap = {
  id: 'fullstack-ts-react',
  title: 'Full-Stack Developer — TypeScript, React & Node.js',
  targetRole: 'Full-Stack Developer',
  specialization: 'Modern Web Apps & Cloud Services',
  industry: 'SaaS & Modern Product Companies',
  region: 'Global',
  createdAt: '2026-03-02',
  updatedAt: '2026-03-12',
  timelineMonths: 8,
  weeklyHours: 10,
  totalEstimatedHours: 320,
  strategy: 'balanced',
  summary: 'End-to-end full-stack development mastering TypeScript, component-driven UI, server-side APIs, database management, and scalable cloud deployments.',
  phases: [
    { id: 'p1', title: 'Phase 1: Web Foundations & TypeScript', order: 1, description: 'Modern JavaScript (ES6+), strict TypeScript, DOM mechanics, and CSS layout.', estimatedWeeks: 6 },
    { id: 'p2', title: 'Phase 2: React Architecture', order: 2, description: 'Hooks, state management, routing, component lifecycles, and performance tuning.', estimatedWeeks: 8 },
    { id: 'p3', title: 'Phase 3: Backend APIs & Data', order: 3, description: 'Node.js, Express/Fastify, PostgreSQL, Prisma ORM, and authentication.', estimatedWeeks: 8 },
    { id: 'p4', title: 'Phase 4: Capstone SaaS Platform', order: 4, description: 'Multi-tenant collaboration app with real-time WebSockets and Stripe payments.', estimatedWeeks: 6 },
    { id: 'p5', title: 'Phase 5: DevOps & Career Launch', order: 5, description: 'Docker containerization, CI/CD pipelines, portfolio polish, and technical interviews.', estimatedWeeks: 4 }
  ],
  nodes: [
    {
      id: 'node-fs1',
      phaseId: 'p1',
      title: 'Advanced TypeScript & Modern JavaScript',
      description: 'Generics, union types, utility types, async/await event loop, and modular design.',
      type: 'skill',
      status: 'completed',
      priority: 'critical',
      estimatedHours: 30,
      whyItMatters: 'Modern engineering teams write 100% type-safe codebases to eliminate runtime errors across front and back ends.',
      prerequisites: [],
      isMandatoryPrereq: true,
      learningObjectives: ['Utilize mapped and conditional types', 'Structure maintainable monorepos with shared schema types'],
      subtopics: ['TypeScript Generics', 'Zod schema validation', 'Promises & Async Loop', 'ES Modules'],
      practicalExercises: ['Build a type-safe API client with request/response type validation.'],
      suggestedResources: [{ title: 'Total TypeScript by Matt Pocock', type: 'tutorial', url: 'https://totaltypescript.com', isFree: false }],
      position: { x: 50, y: 150 }
    },
    {
      id: 'node-fs2',
      phaseId: 'p2',
      title: 'Modern React & State Management',
      description: 'Custom hooks, Context API, state machines, memoization, and server state (TanStack Query).',
      type: 'skill',
      status: 'in_progress',
      priority: 'critical',
      estimatedHours: 40,
      whyItMatters: 'React remains the most requested frontend library in tech job postings globally.',
      prerequisites: ['node-fs1'],
      isMandatoryPrereq: true,
      learningObjectives: ['Build complex accessible forms with validation', 'Optimize re-renders using useMemo, useCallback, and Zustand'],
      subtopics: ['React 19 features', 'Zustand / Redux Toolkit', 'TanStack Query caching', 'Component accessibility (WAI-ARIA)'],
      practicalExercises: ['Build an interactive dashboard with optimistic updates and client-side filtering.'],
      suggestedResources: [{ title: 'React Documentation (Official)', type: 'docs', url: 'https://react.dev', isFree: true }],
      position: { x: 420, y: 150 }
    },
    {
      id: 'node-fs3',
      phaseId: 'p3',
      title: 'Node.js Backend & PostgreSQL (Prisma)',
      description: 'RESTful API design, JWT/OAuth2 authentication, relational modeling, and migrations.',
      type: 'module',
      status: 'not_started',
      priority: 'critical',
      estimatedHours: 45,
      whyItMatters: 'Being able to design both the frontend UX and the relational schema makes you a self-sufficient developer.',
      prerequisites: ['node-fs1'],
      isMandatoryPrereq: true,
      learningObjectives: ['Implement secure authentication with refresh tokens and HTTP-only cookies', 'Perform complex database queries and migrations via Prisma'],
      subtopics: ['Express/Fastify setup', 'Prisma Schema & Relations', 'JWT & Session Security', 'Input Sanitization'],
      practicalExercises: ['Create a multi-user workspace backend with role-based permissions.'],
      suggestedResources: [{ title: 'Prisma Getting Started', type: 'docs', url: 'https://prisma.io', isFree: true }],
      position: { x: 800, y: 150 }
    },
    {
      id: 'node-fs4',
      phaseId: 'p4',
      title: 'Production SaaS Capstone Project',
      description: 'Collaborative real-time application with WebSockets, payment integration, and dark/light UI.',
      type: 'project',
      status: 'locked',
      priority: 'critical',
      estimatedHours: 65,
      whyItMatters: 'Proves to employers you can deliver a complete, monetizeable software product from scratch.',
      prerequisites: ['node-fs2', 'node-fs3'],
      isMandatoryPrereq: true,
      learningObjectives: ['Implement bidirectional real-time communication with Socket.io', 'Handle Stripe webhook events securely'],
      subtopics: ['Real-time WebSockets', 'Stripe Billing API', 'Responsive UI & Tailwind', 'Docker Compose deployment'],
      practicalExercises: ['Deploy to Vercel/Render with automated continuous integration and error logging.'],
      suggestedResources: [{ title: 'Full-Stack Open', type: 'course', url: 'https://fullstackopen.com', isFree: true }],
      position: { x: 1180, y: 150 }
    },
    {
      id: 'node-fs5',
      phaseId: 'p5',
      title: 'CI/CD, Cloud Deployment & Interview Loops',
      description: 'Docker, GitHub Actions, AWS/Vercel deployment, full-stack live-coding preparation.',
      type: 'application',
      status: 'locked',
      priority: 'high',
      estimatedHours: 25,
      whyItMatters: 'Takes you across the finish line into successful job placement.',
      prerequisites: ['node-fs4'],
      isMandatoryPrereq: true,
      learningObjectives: ['Write production Dockerfiles', 'Confidently answer front-end and back-end architecture interview questions'],
      subtopics: ['Containerization', 'GitHub Actions CI', 'System Design for Web', 'Live Coding'],
      practicalExercises: ['Set up zero-downtime deployment pipeline.'],
      suggestedResources: [{ title: 'GitHub Actions Documentation', type: 'docs', url: 'https://docs.github.com/actions', isFree: true }],
      position: { x: 1540, y: 150 }
    }
  ],
  edges: [
    { id: 'e-fs1-fs2', source: 'node-fs1', target: 'node-fs2', isMandatory: true },
    { id: 'e-fs1-fs3', source: 'node-fs1', target: 'node-fs3', isMandatory: true },
    { id: 'e-fs2-fs4', source: 'node-fs2', target: 'node-fs4', isMandatory: true },
    { id: 'e-fs3-fs4', source: 'node-fs3', target: 'node-fs4', isMandatory: true },
    { id: 'e-fs4-fs5', source: 'node-fs4', target: 'node-fs5', isMandatory: true }
  ]
};

// Curated 4: Cybersecurity Analyst
export const cybersecurityRoadmap: Roadmap = {
  id: 'cybersecurity-analyst',
  title: 'Cybersecurity Analyst — Defense & Incident Response',
  targetRole: 'Cybersecurity Analyst',
  specialization: 'Security Operations (SOC) & Threat Analysis',
  industry: 'Enterprise Security & Defense',
  region: 'Global',
  createdAt: '2026-03-04',
  updatedAt: '2026-03-14',
  timelineMonths: 10,
  weeklyHours: 8,
  totalEstimatedHours: 320,
  strategy: 'foundation_first',
  summary: 'Systematic pathway to building SOC analyst capabilities: network forensics, threat hunting, SIEM log analysis, and incident containment.',
  phases: [
    { id: 'p1', title: 'Phase 1: Networking & OS Foundations', order: 1, description: 'TCP/IP stack, DNS, subnetting, Linux internals, and PowerShell scripting.', estimatedWeeks: 8 },
    { id: 'p2', title: 'Phase 2: Security Principles & Threat Landscapes', order: 2, description: 'CIA Triad, MITRE ATT&CK framework, and common attack vectors.', estimatedWeeks: 8 },
    { id: 'p3', title: 'Phase 3: Threat Hunting & SIEM Tools', order: 3, description: 'Log parsing with Splunk/Elasticsearch, Wireshark packet analysis, and IDS/IPS alerts.', estimatedWeeks: 8 },
    { id: 'p4', title: 'Phase 4: Incident Response & Defense Capstone', order: 4, description: 'Simulate live malware triage, write incident response reports, and configure firewalls.', estimatedWeeks: 8 },
    { id: 'p5', title: 'Phase 5: Certifications & Job Search', order: 5, description: 'Security+ / CySA+ preparation and SOC interview practice.', estimatedWeeks: 6 }
  ],
  nodes: [
    {
      id: 'node-sec1',
      phaseId: 'p1',
      title: 'Networking Protocols & Packet Analysis',
      description: 'Deep dive into TCP, UDP, ICMP, DNS, TLS handshakes, and packet capture with Wireshark.',
      type: 'skill',
      status: 'completed',
      priority: 'critical',
      estimatedHours: 35,
      whyItMatters: 'You cannot defend what you cannot see: packet inspection is the primary tool for catching data exfiltration.',
      prerequisites: [],
      isMandatoryPrereq: true,
      learningObjectives: ['Analyze Wireshark PCAPs to spot suspicious beaconing', 'Explain TCP 3-way handshake and SYN flood attacks'],
      subtopics: ['OSI Model vs TCP/IP', 'Wireshark Filtering syntax', 'Subnetting & Routing', 'DNS queries & DNS tunneling'],
      practicalExercises: ['Inspect sample PCAPs from malware-traffic-analysis.net and identify C2 server IPs.'],
      suggestedResources: [{ title: 'Professor Messer Network+ Course', type: 'course', url: 'https://professormesser.com', isFree: true }],
      position: { x: 50, y: 150 }
    },
    {
      id: 'node-sec2',
      phaseId: 'p2',
      title: 'Linux Administration & Security Hardening',
      description: 'Permissions, cron jobs, file integrity monitoring, bash scripting, and auditd.',
      type: 'skill',
      status: 'in_progress',
      priority: 'critical',
      estimatedHours: 30,
      whyItMatters: 'Most enterprise servers and security appliances run on Linux; mastering CLI forensics is indispensable.',
      prerequisites: ['node-sec1'],
      isMandatoryPrereq: true,
      learningObjectives: ['Audit sudoers and file permissions', 'Inspect systemd services for persistence mechanisms'],
      subtopics: ['Linux CLI navigation', 'User & Group Permissions', 'Log files in /var/log', 'SSH hardening'],
      practicalExercises: ['Harden an Ubuntu server following CIS benchmark guidelines.'],
      suggestedResources: [{ title: 'OverTheWire Bandit WarGame', type: 'tutorial', url: 'https://overthewire.org', isFree: true }],
      position: { x: 420, y: 150 }
    },
    {
      id: 'node-sec3',
      phaseId: 'p3',
      title: 'SIEM Operations & Log Analysis (Splunk/ELK)',
      description: 'Querying event logs, writing detection rules, correlating alerts, and creating SOC dashboards.',
      type: 'module',
      status: 'not_started',
      priority: 'critical',
      estimatedHours: 45,
      whyItMatters: 'Entry-level SOC analysts spend 80% of their workday triaging alerts and querying SIEM dashboards.',
      prerequisites: ['node-sec1', 'node-sec2'],
      isMandatoryPrereq: true,
      learningObjectives: ['Write Splunk SPL queries to detect brute force attempts', 'Map detected events to MITRE ATT&CK techniques'],
      subtopics: ['Splunk Search Processing Language', 'Windows Event Logs (Sysmon)', 'Correlation Rules', 'MITRE ATT&CK Mapping'],
      practicalExercises: ['Set up a free Splunk instance and ingest Windows Sysmon logs to build a failed login alert.'],
      suggestedResources: [{ title: 'TryHackMe SOC Level 1 Path', type: 'tutorial', url: 'https://tryhackme.com', isFree: false }],
      position: { x: 800, y: 150 }
    },
    {
      id: 'node-sec4',
      phaseId: 'p4',
      title: 'Incident Response & Malware Triage Lab',
      description: 'Execute NIST incident handling lifecycle: containment, eradication, and post-incident reporting.',
      type: 'project',
      status: 'locked',
      priority: 'critical',
      estimatedHours: 50,
      whyItMatters: 'Demonstrates to employers that you can author comprehensive technical incident reports that satisfy executive scrutiny.',
      prerequisites: ['node-sec3'],
      isMandatoryPrereq: true,
      learningObjectives: ['Conduct memory analysis with Volatility', 'Document chain of custody and root cause analysis in a mock incident report'],
      subtopics: ['NIST SP 800-61 Lifecycle', 'Static Malware Analysis Basics', 'Memory & Disk Forensics', 'Incident Report Writing'],
      practicalExercises: ['Investigate a simulated ransomware breach scenario and deliver a 5-page executive post-mortem.'],
      suggestedResources: [{ title: 'SANS Reading Room', type: 'docs', url: 'https://sans.org', isFree: true }],
      position: { x: 1180, y: 150 }
    },
    {
      id: 'node-sec5',
      phaseId: 'p5',
      title: 'CompTIA Security+ Prep & Technical Interviews',
      description: 'Domain review, practice exams, threat scenario Q&A, and resume alignment.',
      type: 'assessment',
      status: 'locked',
      priority: 'high',
      estimatedHours: 30,
      whyItMatters: 'Industry-standard baseline credential required for HR filters and government/enterprise contracts.',
      prerequisites: ['node-sec4'],
      isMandatoryPrereq: true,
      learningObjectives: ['Score 85%+ consistently on Security+ simulation questions', 'Articulate security trade-offs clearly to hiring managers'],
      subtopics: ['Threats, Attacks & Vulnerabilities', 'Architecture & Design', 'Implementation & Operations', 'Governance, Risk & Compliance'],
      practicalExercises: ['Complete 5 full-length timed mock exams.'],
      suggestedResources: [{ title: 'CompTIA Security+ Exam Objectives', type: 'docs', url: 'https://comptia.org', isFree: true }],
      position: { x: 1540, y: 150 }
    }
  ],
  edges: [
    { id: 'e-sec1-sec2', source: 'node-sec1', target: 'node-sec2', isMandatory: true },
    { id: 'e-sec1-sec3', source: 'node-sec1', target: 'node-sec3', isMandatory: true },
    { id: 'e-sec2-sec3', source: 'node-sec2', target: 'node-sec3', isMandatory: true },
    { id: 'e-sec3-sec4', source: 'node-sec3', target: 'node-sec4', isMandatory: true },
    { id: 'e-sec4-sec5', source: 'node-sec4', target: 'node-sec5', isMandatory: true }
  ]
};

export const sampleRoadmaps: Record<string, Roadmap> = {
  'java-backend-fintech': javaBackendRoadmap,
  'ai-engineer-llm': aiEngineerRoadmap,
  'fullstack-ts-react': fullStackRoadmap,
  'cybersecurity-analyst': cybersecurityRoadmap
};

/**
 * Deterministic Generator: generates a rich, realistic, custom roadmap for ANY career goal!
 */
export function generateDeterministicRoadmap(profile: UserProfile): Roadmap {
  const roleLower = profile.dreamJob.toLowerCase();
  
  if (roleLower.includes('java') || roleLower.includes('spring') || roleLower.includes('fintech')) {
    return {
      ...javaBackendRoadmap,
      id: 'custom-' + Date.now(),
      targetRole: profile.dreamJob,
      specialization: profile.specialization || javaBackendRoadmap.specialization,
      industry: profile.industry || javaBackendRoadmap.industry,
      region: profile.targetRegion || javaBackendRoadmap.region,
      timelineMonths: profile.timelineMonths || 12,
      weeklyHours: profile.weeklyStudyHours || 10,
      strategy: profile.learningStrategy || 'balanced'
    };
  }

  if (roleLower.includes('ai') || roleLower.includes('machine learning') || roleLower.includes('data science') || roleLower.includes('llm')) {
    return {
      ...aiEngineerRoadmap,
      id: 'custom-' + Date.now(),
      targetRole: profile.dreamJob,
      specialization: profile.specialization || aiEngineerRoadmap.specialization,
      industry: profile.industry || aiEngineerRoadmap.industry,
      region: profile.targetRegion || aiEngineerRoadmap.region,
      timelineMonths: profile.timelineMonths || 9,
      weeklyHours: profile.weeklyStudyHours || 12,
      strategy: profile.learningStrategy || 'project_first'
    };
  }

  if (roleLower.includes('security') || roleLower.includes('cyber') || roleLower.includes('soc')) {
    return {
      ...cybersecurityRoadmap,
      id: 'custom-' + Date.now(),
      targetRole: profile.dreamJob,
      specialization: profile.specialization || cybersecurityRoadmap.specialization,
      industry: profile.industry || cybersecurityRoadmap.industry,
      region: profile.targetRegion || cybersecurityRoadmap.region,
      timelineMonths: profile.timelineMonths || 10,
      weeklyHours: profile.weeklyStudyHours || 8,
      strategy: profile.learningStrategy || 'foundation_first'
    };
  }

  if (roleLower.includes('full') || roleLower.includes('web') || roleLower.includes('front') || roleLower.includes('react')) {
    return {
      ...fullStackRoadmap,
      id: 'custom-' + Date.now(),
      targetRole: profile.dreamJob,
      specialization: profile.specialization || fullStackRoadmap.specialization,
      industry: profile.industry || fullStackRoadmap.industry,
      region: profile.targetRegion || fullStackRoadmap.region,
      timelineMonths: profile.timelineMonths || 8,
      weeklyHours: profile.weeklyStudyHours || 10,
      strategy: profile.learningStrategy || 'balanced'
    };
  }

  // Dynamic Custom Blueprint for any customized or unique role
  const targetRole = profile.dreamJob || 'Software Systems Specialist';
  const specialization = profile.specialization || 'Production Engineering';
  const industry = profile.industry || 'Technology & Innovation';
  const region = profile.targetRegion || 'Global';
  const timeline = profile.timelineMonths || 12;
  const weeklyHours = profile.weeklyStudyHours || 10;
  const totalHours = Math.round(timeline * 4 * weeklyHours * 0.85);

  const customPhases: RoadmapPhase[] = [
    { id: 'cp1', title: 'Phase 1: Domain Foundations', order: 1, description: `Core primitives, paradigms, and syntax necessary for ${targetRole}.`, estimatedWeeks: Math.max(4, Math.round(timeline * 0.2 * 4)) },
    { id: 'cp2', title: 'Phase 2: Core Engineering & Architecture', order: 2, description: `Architectural standards, data models, and protocols used in ${industry}.`, estimatedWeeks: Math.max(5, Math.round(timeline * 0.25 * 4)) },
    { id: 'cp3', title: 'Phase 3: Applied Toolchains & Frameworks', order: 3, description: `Professional tooling, libraries, and automated testing in ${specialization}.`, estimatedWeeks: Math.max(5, Math.round(timeline * 0.25 * 4)) },
    { id: 'cp4', title: 'Phase 4: Production Capstone Project', order: 4, description: `A high-impact, real-world portfolio system tailored for employers in ${industry}.`, estimatedWeeks: Math.max(4, Math.round(timeline * 0.2 * 4)) },
    { id: 'cp5', title: 'Phase 5: Technical Launch & Industry Readiness', order: 5, description: `System reviews, portfolio verification, and high-stakes interview preparation.`, estimatedWeeks: Math.max(2, Math.round(timeline * 0.1 * 4)) }
  ];

  const customNodes: RoadmapNode[] = [
    {
      id: 'cn-1',
      phaseId: 'cp1',
      title: `${targetRole} Primitives & Core Syntax`,
      description: `Foundational concepts, idiomatic conventions, and mental models of ${targetRole}.`,
      type: 'skill',
      status: 'completed',
      priority: 'critical',
      estimatedHours: 30,
      whyItMatters: `Establishes the non-negotiable fundamental vocabulary required by any team hiring for ${targetRole}.`,
      prerequisites: [],
      isMandatoryPrereq: true,
      learningObjectives: ['Master fundamental syntax and mental models', 'Avoid common anti-patterns in early implementations'],
      subtopics: ['Core Syntax & Primitives', 'Memory & Resource Management', 'Error Handling Paradigms', 'Development Environment Setup'],
      practicalExercises: ['Implement foundational utilities and verify behavior through automated tests.'],
      suggestedResources: [{ title: 'Official Documentation & Standards', type: 'docs', url: 'https://docs.github.com', isFree: true }],
      position: { x: 60, y: 150 }
    },
    {
      id: 'cn-2',
      phaseId: 'cp2',
      title: `System Architecture & Data Structures`,
      description: `Structured data flow, algorithmic complexity, and scalable architecture design.`,
      type: 'skill',
      status: 'in_progress',
      priority: 'critical',
      estimatedHours: 40,
      whyItMatters: `High-value roles in ${industry} demand deep understanding of how systems handle load, state, and edge cases.`,
      prerequisites: ['cn-1'],
      isMandatoryPrereq: true,
      learningObjectives: ['Design modular components with loose coupling', 'Analyze performance bottlenecks and storage efficiency'],
      subtopics: ['Algorithmic Efficiency', 'State & Data Consistency', 'Component Boundaries', 'Defensive Engineering'],
      practicalExercises: ['Build an in-memory cache and state manager with concurrent write protection.'],
      suggestedResources: [{ title: 'Architecture Patterns Guide', type: 'course', url: 'https://martinfowler.com', isFree: true }],
      position: { x: 420, y: 150 }
    },
    {
      id: 'cn-3',
      phaseId: 'cp3',
      title: `${specialization} Tooling & Automated Pipelines`,
      description: `Industry-standard toolchain integration, test runners, and continuous validation.`,
      type: 'module',
      status: 'not_started',
      priority: 'high',
      estimatedHours: 35,
      whyItMatters: `Professional teams require production velocity with automated safeguards against regression.`,
      prerequisites: ['cn-2'],
      isMandatoryPrereq: true,
      learningObjectives: ['Configure end-to-end testing harnesses', 'Automate static analysis, formatting, and linting checks'],
      subtopics: ['Framework Integration', 'Automated Test Suites', 'Performance Benchmarking', 'Environment Configuration'],
      practicalExercises: ['Set up a complete repository with CI automation verifying 80%+ test coverage on every pull request.'],
      suggestedResources: [{ title: 'Production Engineering Practices', type: 'docs', url: 'https://github.com', isFree: true }],
      position: { x: 780, y: 150 }
    },
    {
      id: 'cn-4',
      phaseId: 'cp4',
      title: `Production Capstone: ${targetRole} Showcase`,
      description: `An end-to-end, production-grade project demonstrating mastery of ${specialization} under realistic constraints.`,
      type: 'project',
      status: 'locked',
      priority: 'critical',
      estimatedHours: 60,
      whyItMatters: `Direct proof of competence that distinguishes your application from candidates who only have tutorial projects.`,
      prerequisites: ['cn-2', 'cn-3'],
      isMandatoryPrereq: true,
      learningObjectives: ['Build and deploy a scalable, multi-component application', 'Document technical tradeoffs and operational metrics'],
      subtopics: ['Domain Requirements Specification', 'Component Implementation', 'Observability & Metrics', 'Deployment & Live Verification'],
      practicalExercises: ['Deploy live application with public demo, interactive documentation, and automated tests.'],
      suggestedResources: [{ title: 'Engineering Project Blueprint', type: 'repo', url: 'https://github.com', isFree: true }],
      position: { x: 1140, y: 150 }
    },
    {
      id: 'cn-5',
      phaseId: 'cp5',
      title: `Career Launch & Technical Interview Mastery`,
      description: `Resume positioning, portfolio presentation, system design walkthroughs, and technical interview simulations.`,
      type: 'application',
      status: 'locked',
      priority: 'high',
      estimatedHours: 25,
      whyItMatters: `Ensures your skills translate into offers from top employers in ${industry}.`,
      prerequisites: ['cn-4'],
      isMandatoryPrereq: true,
      learningObjectives: ['Present technical project decisions clearly to senior interviewers', 'Formulate quantitative resume achievements'],
      subtopics: ['Technical Storytelling', 'System Design Discussions', 'Portfolio Documentation', 'Offer Negotiation'],
      practicalExercises: ['Record and critique a 5-minute technical project walkthrough.'],
      suggestedResources: [{ title: 'Technical Career Guide', type: 'docs', url: 'https://www.techinterviewhandbook.org', isFree: true }],
      position: { x: 1500, y: 150 }
    }
  ];

  const customEdges: RoadmapEdge[] = [
    { id: 'ce-1-2', source: 'cn-1', target: 'cn-2', isMandatory: true },
    { id: 'ce-2-3', source: 'cn-2', target: 'cn-3', isMandatory: true },
    { id: 'ce-2-4', source: 'cn-2', target: 'cn-4', isMandatory: true },
    { id: 'ce-3-4', source: 'cn-3', target: 'cn-4', isMandatory: true },
    { id: 'ce-4-5', source: 'cn-4', target: 'cn-5', isMandatory: true }
  ];

  return {
    id: 'custom-' + Date.now(),
    title: `${targetRole} Roadmap`,
    targetRole,
    specialization,
    industry,
    region,
    createdAt: new Date().toISOString().split('T')[0],
    updatedAt: new Date().toISOString().split('T')[0],
    timelineMonths: timeline,
    weeklyHours,
    totalEstimatedHours: totalHours,
    strategy: profile.learningStrategy || 'balanced',
    summary: `Personalized career roadmap tailored specifically for ${targetRole} with focus on ${specialization} in ${industry}.`,
    phases: customPhases,
    nodes: customNodes,
    edges: customEdges
  };
}
