import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Map,
  Target,
  BarChart3,
  Sliders,
  ShieldAlert,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  AlertTriangle,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { WhatIfModal } from '../components/modals/WhatIfModal';
import { AdaptiveRecoveryModal } from '../components/modals/AdaptiveRecoveryModal';

export const DashboardPage: React.FC = () => {
  const { activeRoadmap, careerGap, projects } = useApp();

  const [isWhatIfOpen, setIsWhatIfOpen] = useState(false);
  const [isRecoveryOpen, setIsRecoveryOpen] = useState(false);
  const [showFormulaInfo, setShowFormulaInfo] = useState(false);

  const completedCount = activeRoadmap.nodes.filter(n => n.status === 'completed').length;
  const inProgressCount = activeRoadmap.nodes.filter(n => n.status === 'in_progress').length;
  const totalCount = activeRoadmap.nodes.length;
  const completionPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div className="min-h-screen bg-[#0B0F19] text-gray-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* TOP GOAL HERO BANNER */}
        <div className="rounded-3xl bg-gradient-to-r from-gray-900 via-gray-900/90 to-gray-900 border border-gray-800 p-6 sm:p-8 shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-[var(--brand-primary)]/15 text-[var(--brand-primary)] border border-[var(--brand-primary)]/30 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5" />
                Active Career Destination
              </span>
              <span className="text-xs text-gray-400">
                Target: {activeRoadmap.timelineMonths} Months · {activeRoadmap.weeklyHours}h/week
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {activeRoadmap.targetRole}
            </h1>

            <p className="text-xs sm:text-sm text-gray-400 max-w-2xl leading-relaxed">
              {activeRoadmap.summary}
            </p>

            <div className="flex items-center gap-4 pt-1 flex-wrap text-xs text-gray-300">
              <span className="font-semibold text-gray-400">Specialization:</span>
              <span className="text-[var(--brand-primary)]">{activeRoadmap.specialization || 'Production Systems'}</span>
              <span className="text-gray-600">·</span>
              <span className="font-semibold text-gray-400">Industry:</span>
              <span>{activeRoadmap.industry || 'Technology'}</span>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5 shrink-0">
            <Link
              to={`/roadmap/${activeRoadmap.id}`}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl text-xs font-bold text-white bg-[var(--brand-gradient)] hover:opacity-95 shadow-md shadow-[var(--brand-glow)] transition-all text-center"
            >
              <Map className="w-4 h-4" />
              <span>Open Interactive Canvas</span>
            </Link>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsWhatIfOpen(true)}
                className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-gray-200 bg-gray-800 hover:bg-gray-750 border border-gray-700 transition-colors shadow-2xs"
              >
                <Sliders className="w-3.5 h-3.5 text-[var(--brand-primary)]" />
                <span>What-If</span>
              </button>

              <button
                onClick={() => setIsRecoveryOpen(true)}
                className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-amber-300 bg-amber-950/40 border border-amber-800/60 hover:bg-amber-900/40 transition-colors shadow-2xs"
              >
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                <span>Recovery</span>
              </button>
            </div>
          </div>
        </div>

        {/* OVERVIEW STATS GRID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Readiness Index */}
          <div className="p-5 rounded-3xl bg-gray-900 border border-gray-800 shadow-md space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                Readiness Index
              </span>
              <button
                onClick={() => setShowFormulaInfo(!showFormulaInfo)}
                className="text-gray-500 hover:text-[var(--brand-primary)]"
                title="View mathematical calculation formula"
              >
                <Info className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white">
                {careerGap.readinessScore}%
              </span>
              <span className="text-xs font-semibold text-emerald-400">
                Weighted
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-gray-800 overflow-hidden">
              <div
                className="h-full bg-[var(--brand-gradient)] transition-all"
                style={{ width: `${careerGap.readinessScore}%` }}
              />
            </div>
          </div>

          {/* Curriculum Completed */}
          <div className="p-5 rounded-3xl bg-gray-900 border border-gray-800 shadow-md space-y-2">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
              Roadmap Completed
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white">
                {completedCount} <span className="text-base font-normal text-gray-500">/ {totalCount}</span>
              </span>
              <span className="text-xs font-semibold text-[var(--brand-primary)]">
                {completionPercentage}%
              </span>
            </div>
            <p className="text-[11px] text-gray-400">
              {inProgressCount} active milestones currently in progress
            </p>
          </div>

          {/* Weekly Velocity */}
          <div className="p-5 rounded-3xl bg-gray-900 border border-gray-800 shadow-md space-y-2">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
              Weekly Capacity
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white">
                {activeRoadmap.weeklyHours}
              </span>
              <span className="text-xs font-semibold text-gray-400">
                hrs / week
              </span>
            </div>
            <p className="text-[11px] text-gray-400">
              Paced for {activeRoadmap.timelineMonths}-month target readiness
            </p>
          </div>

          {/* Portfolio Capstones */}
          <div className="p-5 rounded-3xl bg-gray-900 border border-gray-800 shadow-md space-y-2">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
              Portfolio Projects
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white">
                {projects.filter(p => p.status === 'completed').length} <span className="text-base font-normal text-gray-500">/ {projects.length}</span>
              </span>
              <span className="text-xs font-semibold text-purple-400">
                Artifacts
              </span>
            </div>
            <p className="text-[11px] text-gray-400">
              Industrial-grade proof of competence
            </p>
          </div>
        </div>

        {/* MATHEMATICAL FORMULA ACCORDION */}
        {showFormulaInfo && (
          <div className="p-4 rounded-2xl bg-gray-900 border border-gray-800 text-xs text-gray-200 space-y-2 animate-in fade-in duration-150">
            <div className="flex items-center justify-between font-bold text-[var(--brand-primary)]">
              <span>Readiness Calculation Formula:</span>
              <button onClick={() => setShowFormulaInfo(false)} className="text-gray-400 hover:text-white">
                Close
              </button>
            </div>
            <p className="font-mono text-[11px] bg-gray-950 p-2.5 rounded-xl border border-gray-800 text-gray-300">
              {careerGap.scoreBreakdown.calculationFormula}
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px]">
              <div>Foundations: <strong>{careerGap.scoreBreakdown.foundationsScore} / 40 pts</strong></div>
              <div>Core Engineering: <strong>{careerGap.scoreBreakdown.coreTechScore} / 30 pts</strong></div>
              <div>Projects: <strong>{careerGap.scoreBreakdown.projectsScore} / 20 pts</strong></div>
              <div>Career Launch: <strong>{careerGap.scoreBreakdown.careerLaunchScore} / 10 pts</strong></div>
            </div>
          </div>
        )}

        {/* MAIN SPLIT: CAREER GAP ANALYSIS & RECOMMENDED ACTIONS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* LEFT 7 COLS: REVERSE CAREER GAP ANALYSIS */}
          <div className="lg:col-span-7 space-y-6">
            <div className="p-6 sm:p-8 rounded-3xl bg-gray-900 border border-gray-800 shadow-md space-y-6">
              <div className="flex items-center justify-between border-b border-gray-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-gray-800 text-[var(--brand-primary)] flex items-center justify-center border border-gray-700">
                    <BarChart3 className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white">
                      Your Career Gap Analysis
                    </h2>
                    <p className="text-xs text-gray-400">
                      Comparing verified abilities against target role demands.
                    </p>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-800">
                  {careerGap.readinessScore}% Match
                </span>
              </div>

              {/* Demonstrated Skills */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Demonstrated Competencies ({careerGap.demonstratedSkills.length})</span>
                </h3>
                <div className="flex flex-wrap gap-2">
                  {careerGap.demonstratedSkills.map((s, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-950/40 border border-emerald-800/80 text-emerald-300 flex items-center gap-1.5"
                    >
                      <span>{s.name}</span>
                      <span className="text-[10px] text-emerald-400/80 font-normal">
                        ({s.proficiency})
                      </span>
                    </span>
                  ))}
                </div>
              </div>

              {/* In Progress Skills */}
              {careerGap.inProgressSkills.length > 0 && (
                <div className="space-y-3 pt-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-[var(--brand-primary)]" />
                    <span>Currently Being Developed ({careerGap.inProgressSkills.length})</span>
                  </h3>
                  <div className="space-y-2">
                    {careerGap.inProgressSkills.map((ips, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-gray-950 border border-gray-800 flex items-center justify-between text-xs">
                        <span className="font-semibold text-gray-200">{ips.name}</span>
                        <span className="text-[10px] font-bold text-[var(--brand-primary)]">Active Milestone</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Missing Foundations Gap */}
              <div className="space-y-3 pt-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Essential Foundation Gaps ({careerGap.missingFoundationalSkills.length})</span>
                </h3>
                <div className="space-y-2">
                  {careerGap.missingFoundationalSkills.length === 0 ? (
                    <p className="text-xs text-emerald-400 italic">
                      Zero foundational gaps! All Phase 1/2 prerequisites are fully mastered.
                    </p>
                  ) : (
                    careerGap.missingFoundationalSkills.map((mf, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-gray-950 border border-gray-800 flex items-center justify-between text-xs gap-3"
                      >
                        <div>
                          <span className="font-bold text-gray-200">{mf.name}</span>
                          <p className="text-[11px] text-gray-400 mt-0.5">{mf.reason}</p>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800 uppercase shrink-0">
                          {mf.priority}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT 5 COLS: RECOMMENDED NEXT ACTIONS & PROJECTS */}
          <div className="lg:col-span-5 space-y-6">
            {/* Recommended Next Actions */}
            <div className="p-6 rounded-3xl bg-gray-900 border border-gray-800 shadow-md space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-gray-800">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[var(--brand-primary)]" />
                  <span>Recommended Next Actions</span>
                </h3>
                <span className="text-[11px] text-gray-400">Priority Queue</span>
              </div>

              <div className="space-y-2.5">
                {careerGap.highPriorityNextActions.map((act) => (
                  <div
                    key={act.nodeId}
                    className="p-3.5 rounded-2xl bg-gray-950 border border-gray-800 hover:border-[var(--brand-primary)] transition-all space-y-1.5 group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-200 group-hover:text-white transition-colors">
                        {act.title}
                      </span>
                      <span className="text-[10px] font-semibold text-gray-400 bg-gray-900 px-2 py-0.5 rounded-full border border-gray-800">
                        {act.estimatedHours}h
                      </span>
                    </div>
                    <p className="text-[11px] text-gray-400 leading-relaxed">
                      {act.reason}
                    </p>
                    <div className="pt-1 flex justify-end">
                      <Link
                        to={`/roadmap/${activeRoadmap.id}?node=${act.nodeId}`}
                        className="text-[11px] font-bold text-[var(--brand-primary)] flex items-center gap-1 hover:underline"
                      >
                        Inspect on Canvas &rarr;
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Capstone Preview Shortcut */}
            <div className="p-6 rounded-3xl bg-gray-900 border border-gray-800 text-white space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold tracking-wider text-purple-300">
                  Featured Portfolio Project
                </span>
                <span className="text-xs font-bold text-emerald-400">
                  Capstone
                </span>
              </div>

              <h4 className="text-base font-bold leading-snug">
                {projects[0]?.title || 'Production Microservices Capstone'}
              </h4>

              <p className="text-xs text-gray-400 leading-relaxed">
                {projects[0]?.tagline}
              </p>

              <div className="pt-2 flex items-center justify-between">
                <Link
                  to="/projects"
                  className="text-xs font-bold text-white bg-[var(--brand-gradient)] hover:opacity-95 px-4 py-2 rounded-xl transition-all inline-flex items-center gap-1.5 shadow-sm"
                >
                  <span>View Project Specs</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Modals */}
        <WhatIfModal isOpen={isWhatIfOpen} onClose={() => setIsWhatIfOpen(false)} />
        <AdaptiveRecoveryModal isOpen={isRecoveryOpen} onClose={() => setIsRecoveryOpen(false)} />
      </div>
    </div>
  );
};
