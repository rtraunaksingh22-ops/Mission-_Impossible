@echo off
set "PATH=C:\Users\Raunak Pratap Singh\AppData\Local\Programs\MinGit\cmd;%LOCALAPPDATA%\Microsoft\WinGet\Packages\GitHub.cli_Microsoft.Winget.Source_8wekyb3d8bbwe;%PATH%"

echo ========================================================
echo   PathPilot AI - GitHub Repository Setup & Push
echo ========================================================
echo.

where gh >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo Checking GitHub CLI login...
    gh auth status >nul 2>&1
    if %ERRORLEVEL% neq 0 (
        echo Please authenticate with GitHub first:
        echo A browser window will open, or visit https://github.com/login/device
        echo.
        gh auth login --web -p https
    )
    echo.
    echo Creating GitHub repository and pushing code...
    gh repo create pathpilot-ai --public --source=. --remote=origin --push
    if %ERRORLEVEL% equ 0 (
        echo.
        echo [SUCCESS] Your PathPilot AI repository has been created and pushed to GitHub!
        echo.
        pause
        exit /b 0
    )
)

echo.
echo If you prefer manual push, please create a new repository on https://github.com/new
set /p REPO_URL="Enter your GitHub Repository URL (e.g. https://github.com/username/pathpilot-ai.git): "
if not "%REPO_URL%"=="" (
    git remote remove origin >nul 2>&1
    git remote add origin %REPO_URL%
    git push -u origin main
    echo.
    echo [SUCCESS] Code pushed to %REPO_URL%!
)
pause
