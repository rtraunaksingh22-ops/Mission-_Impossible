import React, { useState } from 'react';
import { X, ShieldAlert, CheckCircle2, Calendar, ArrowRight, Check, Clock } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { RecoveryPlan } from '../../types';

type AdaptiveRecoveryModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export const AdaptiveRecoveryModal: React.FC<AdaptiveRecoveryModalProps> = ({ isOpen, onClose }) => {
  const { activeRoadmap, runAdaptiveRecovery, applyAdaptiveRecovery } = useApp();

  const [availableHours, setAvailableHours] = useState(activeRoadmap.weeklyHours || 8);
  const [applied, setApplied] = useState(false);

  if (!isOpen) return null;

  const plan: RecoveryPlan = runAdaptiveRecovery(availableHours);

  const handleAccept = () => {
    applyAdaptiveRecovery(plan, availableHours);
    setApplied(true);
    setTimeout(() => {
      setApplied(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-gray-900 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-[#E6E9F1] dark:border-gray-800 flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-[#E6E9F1] dark:border-gray-800 flex items-center justify-between sticky top-0 bg-white/95 dark:bg-gray-900/95 backdrop-blur z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-500 flex items-center justify-center border border-amber-200 dark:border-amber-800">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#172033] dark:text-white">
                Get Back on Track: Adaptive Recovery
              </h3>
              <p className="text-xs text-[#68738A] dark:text-gray-400">
                Recalibrate your schedule realistically without losing completed progress.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-200 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Availability slider */}
          <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700">
            <div className="flex justify-between text-xs font-semibold text-[#172033] dark:text-gray-300 mb-2">
              <span>Realistic Weekly Study Hours Available:</span>
              <span className="text-[var(--brand-primary)] font-bold">{availableHours} hrs/week</span>
            </div>
            <input
              type="range"
              min={4}
              max={25}
              step={1}
              value={availableHours}
              onChange={(e) => setAvailableHours(Number(e.target.value))}
              className="w-full accent-[var(--brand-primary)]"
            />
            <p className="text-[11px] text-[#68738A] dark:text-gray-400 mt-1">
              Be honest with your weekly capacity. The recovery engine will rebalance milestones accordingly.
            </p>
          </div>

          {/* Timeline Comparison */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#68738A] dark:text-gray-400">
                Previous Target
              </span>
              <p className="text-lg font-bold text-[#172033] dark:text-white mt-1 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-gray-400" />
                {plan.previousTimelineMonths} Months
              </p>
            </div>

            <div className="p-4 rounded-2xl border border-emerald-400 dark:border-emerald-600 bg-emerald-50/30 dark:bg-emerald-950/20">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
                Proposed Feasible Window
              </span>
              <p className="text-lg font-bold text-emerald-700 dark:text-emerald-400 mt-1 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-emerald-500" />
                {plan.proposedTimelineMonths} Months
              </p>
            </div>
          </div>

          {/* Diff Breakdown: 3 Categories (Retained, Moved, Deferred) */}
          <div className="space-y-3">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#68738A] dark:text-gray-400">
              Adaptive Rebalancing Breakdown
            </span>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* 1. Retained Essential Tasks */}
              <div className="p-3.5 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-[#172033] dark:text-white flex items-center gap-1.5">
                      <Check className="w-4 h-4 text-emerald-500" />
                      <span>Retained Core</span>
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300">
                      {plan.tasksRetained.length} Core
                    </span>
                  </div>
                  <ul className="space-y-1.5">
                    {plan.tasksRetained.map((t, idx) => (
                      <li key={idx} className="text-xs text-[#172033] dark:text-gray-200 p-2 rounded-lg bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100/60 dark:border-emerald-900/30">
                        <div className="flex items-center justify-between mb-0.5">
                          <span className="font-semibold line-clamp-1">{t.title}</span>
                          <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 font-bold shrink-0 ml-1">
                            {t.priority}
                          </span>
                        </div>
                        <p className="text-[10px] text-emerald-700 dark:text-emerald-400/90 leading-tight">
                          {t.reason || 'Essential foundation for technical interview readiness.'}
                        </p>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* 2. Rescheduled / Moved Tasks */}
              <div className="p-3.5 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-[#172033] dark:text-white flex items-center gap-1.5">
                      <ArrowRight className="w-4 h-4 text-blue-500" />
                      <span>Rescheduled</span>
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300">
                      {plan.tasksMoved?.length || 0} Shifted
                    </span>
                  </div>
                  <ul className="space-y-1.5">
                    {(plan.tasksMoved || []).map((t, idx) => (
                      <li key={idx} className="text-xs text-[#172033] dark:text-gray-200 p-2 rounded-lg bg-blue-50/40 dark:bg-blue-950/20 border border-blue-100/60 dark:border-blue-900/30">
                        <span className="font-semibold line-clamp-1">{t.title}</span>
                        <div className="text-[10px] text-blue-600 dark:text-blue-400 font-medium my-0.5 flex items-center gap-1">
                          <span className="line-clamp-1">{t.fromPhase}</span>
                          <span>→</span>
                          <span className="line-clamp-1">{t.toPhase}</span>
                        </div>
                        <p className="text-[10px] text-gray-500 dark:text-gray-400 leading-tight">
                          {t.reason}
                        </p>
                      </li>
                    ))}
                    {(!plan.tasksMoved || plan.tasksMoved.length === 0) && (
                      <li className="text-[11px] text-gray-400 italic p-2 text-center">
                        No phase shifts required; pacing is stable.
                      </li>
                    )}
                  </ul>
                </div>
              </div>

              {/* 3. Deferred Optional Tasks */}
              <div className="p-3.5 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-[#172033] dark:text-white flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-amber-500" />
                      <span>Deferred Tasks</span>
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                      {plan.tasksDeferred.length} Deferred
                    </span>
                  </div>
                  <ul className="space-y-1.5">
                    {plan.tasksDeferred.map((t, idx) => (
                      <li key={idx} className="text-xs text-[#172033] dark:text-gray-200 p-2 rounded-lg bg-amber-50/40 dark:bg-amber-950/20 border border-amber-100/60 dark:border-amber-900/30">
                        <span className="font-semibold line-clamp-1">{t.title}</span>
                        <p className="text-[10px] text-amber-700 dark:text-amber-400 mt-0.5 leading-tight">
                          {t.reason}
                        </p>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Schedule Changes List */}
          <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#68738A] dark:text-gray-400 block mb-2">
              Actionable Schedule Adjustments
            </span>
            <ul className="space-y-1.5 text-xs text-[#172033] dark:text-gray-300">
              {plan.scheduleChanges.map((change, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[var(--brand-primary)] shrink-0 mt-1.5" />
                  <span>{change}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Explanation */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 text-xs text-[#172033] dark:text-gray-200 leading-relaxed">
            <span className="font-bold text-[var(--brand-primary)]">Recovery Rationale: </span>
            {plan.explanation}
          </div>

          {applied && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Recovery plan adopted! Preserved completed work and recalibrated roadmap.</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-[#E6E9F1] dark:border-gray-800 bg-gray-50 dark:bg-gray-850 flex items-center justify-end gap-3 sticky bottom-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-[#68738A] dark:text-gray-400 hover:text-[#172033] dark:hover:text-white hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
          >
            Reject / Keep Current
          </button>
          <button
            type="button"
            onClick={handleAccept}
            className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-secondary)] hover:opacity-95 shadow-sm shadow-[var(--brand-primary)]/25 transition-all"
          >
            <span>Accept Recovery Plan</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
