import React, { useState, useMemo, useCallback } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  Node,
  Edge,
  BackgroundVariant
} from '@xyflow/react';
import {
  Compass,
  Sliders,
  ShieldAlert,
  Search,
  Download,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { RoadmapNodeComponent } from '../components/roadmap/RoadmapNodeComponent';
import { NodeDetailDrawer } from '../components/roadmap/NodeDetailDrawer';
import { WhatIfModal } from '../components/modals/WhatIfModal';
import { AdaptiveRecoveryModal } from '../components/modals/AdaptiveRecoveryModal';
import { RoadmapNode } from '../types';

const nodeTypes = {
  customNode: RoadmapNodeComponent
};

export const RoadmapPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { roadmaps, activeRoadmap, setActiveRoadmapId } = useApp();

  const currentRoadmap = (id && roadmaps[id]) ? roadmaps[id] : activeRoadmap;

  // Sync active roadmap with route
  React.useEffect(() => {
    if (id && roadmaps[id] && id !== activeRoadmap.id) {
      setActiveRoadmapId(id);
    }
  }, [id, roadmaps, activeRoadmap.id, setActiveRoadmapId]);

  // Selected Node Drawer state
  const [selectedNode, setSelectedNode] = useState<RoadmapNode | null>(null);

  // Auto-select node from ?node query param
  const targetNodeId = searchParams.get('node');
  React.useEffect(() => {
    if (targetNodeId && currentRoadmap) {
      const match = currentRoadmap.nodes.find(n => n.id === targetNodeId);
      if (match) {
        setSelectedNode(match);
      }
    }
  }, [targetNodeId, currentRoadmap]);

  // Modals
  const [isWhatIfOpen, setIsWhatIfOpen] = useState(false);
  const [isRecoveryOpen, setIsRecoveryOpen] = useState(false);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [phaseFilter, setPhaseFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Convert roadmap data to XYFlow nodes & edges
  const initialNodes: Node[] = useMemo(() => {
    if (!currentRoadmap) return [];
    return currentRoadmap.nodes.map(n => ({
      id: n.id,
      type: 'customNode',
      position: n.position || { x: 100, y: 100 },
      data: { ...n }
    }));
  }, [currentRoadmap]);

  const initialEdges: Edge[] = useMemo(() => {
    if (!currentRoadmap) return [];
    return currentRoadmap.edges.map(e => ({
      id: e.id,
      source: e.source,
      target: e.target,
      animated: e.animated || false,
      style: {
        stroke: e.isMandatory ? 'var(--brand-primary, #6366F1)' : '#64748B',
        strokeWidth: 2,
        strokeDasharray: e.isMandatory ? undefined : '5,5'
      }
    }));
  }, [currentRoadmap]);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  // Synchronize when currentRoadmap updates in context
  React.useEffect(() => {
    setNodes(initialNodes);
    setEdges(initialEdges);
  }, [initialNodes, initialEdges, setNodes, setEdges]);

  // Node Click Handler
  const onNodeClick = useCallback((_: React.MouseEvent, node: Node) => {
    const rawNode = currentRoadmap.nodes.find(n => n.id === node.id);
    if (rawNode) {
      setSelectedNode(rawNode);
    }
  }, [currentRoadmap]);

  // Filtered nodes
  const filteredNodes = useMemo(() => {
    return nodes.map(n => {
      const data = n.data as unknown as RoadmapNode;
      const matchesSearch = !searchQuery || data.title.toLowerCase().includes(searchQuery.toLowerCase()) || data.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPhase = phaseFilter === 'all' || data.phaseId === phaseFilter;
      const matchesStatus = statusFilter === 'all' || data.status === statusFilter;

      const isHidden = !(matchesSearch && matchesPhase && matchesStatus);
      return {
        ...n,
        hidden: isHidden
      };
    });
  }, [nodes, searchQuery, phaseFilter, statusFilter]);

  // Progress Stats
  const totalNodes = currentRoadmap?.nodes?.length || 0;
  const completedNodes = currentRoadmap?.nodes?.filter(n => n.status === 'completed').length || 0;
  const progressPercent = totalNodes > 0 ? Math.round((completedNodes / totalNodes) * 100) : 0;

  // Export Roadmap as JSON
  const handleExport = () => {
    const json = JSON.stringify(currentRoadmap, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pathpilot-roadmap-${currentRoadmap.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!currentRoadmap) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-[#0B0F19] text-white">
        <div className="text-center p-8 bg-gray-900 rounded-3xl border border-gray-800 shadow-xl max-w-md">
          <Compass className="w-12 h-12 text-[var(--brand-primary)] mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white">No Roadmap Found</h2>
          <p className="text-xs text-gray-400 mt-2 mb-6">
            The requested roadmap does not exist in your local storage.
          </p>
          <button
            onClick={() => navigate('/onboarding')}
            className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-[var(--brand-primary)]"
          >
            Create New Roadmap
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col bg-[#0B0F19] text-gray-100 overflow-hidden">
      {/* TOP ROADMAP HEADER */}
      <header className="bg-gray-900/90 backdrop-blur border-b border-gray-800 px-4 sm:px-6 py-3.5 shrink-0 z-20">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Title & Metadata */}
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[var(--brand-primary)]/15 text-[var(--brand-primary)] border border-[var(--brand-primary)]/30">
                {currentRoadmap.specialization || 'Core Track'}
              </span>
              <span className="text-xs text-gray-400">
                {currentRoadmap.industry} · {currentRoadmap.region}
              </span>
              <span className="text-xs text-gray-500">·</span>
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <Clock className="w-3 h-3" /> {currentRoadmap.totalEstimatedHours || 380} Total Hours
              </span>
            </div>

            <div className="flex items-center gap-3">
              <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                {currentRoadmap.targetRole}
              </h1>
              {/* Progress pill */}
              <div className="flex items-center gap-2 bg-emerald-950/60 border border-emerald-800 px-3 py-0.5 rounded-full">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-xs font-bold text-emerald-300">
                  {progressPercent}% Complete ({completedNodes}/{totalNodes})
                </span>
              </div>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* What-If Simulator Button */}
            <button
              onClick={() => setIsWhatIfOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-gray-850 hover:bg-gray-800 border border-[var(--brand-primary)]/40 hover:border-[var(--brand-primary)] transition-all shadow-xs"
            >
              <Sliders className="w-3.5 h-3.5 text-[var(--brand-primary)]" />
              <span>What If?</span>
            </button>

            {/* Adaptive Recovery Button */}
            <button
              onClick={() => setIsRecoveryOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-amber-300 bg-amber-950/50 border border-amber-800/80 hover:bg-amber-900/50 transition-all shadow-xs"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              <span>Get Back on Track</span>
            </button>

            {/* Export JSON */}
            <button
              onClick={handleExport}
              className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-gray-800 border border-gray-850 transition-colors"
              title="Export Roadmap JSON"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filters and Search Bar */}
        <div className="max-w-7xl mx-auto mt-3 pt-3 border-t border-gray-800 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-[200px] max-w-sm">
            <div className="relative w-full">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search skills, topics, or projects..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl text-xs border border-gray-800 bg-gray-950 text-white placeholder-gray-500 focus:outline-none focus:border-[var(--brand-primary)]"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Phase Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-gray-400 hidden sm:inline">Phase:</span>
              <select
                value={phaseFilter}
                onChange={(e) => setPhaseFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl text-xs border border-gray-800 bg-gray-950 text-gray-200 focus:outline-none"
              >
                <option value="all">All Phases</option>
                {currentRoadmap.phases.map(p => (
                  <option key={p.id} value={p.id}>{p.title}</option>
                ))}
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-gray-400 hidden sm:inline">Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl text-xs border border-gray-800 bg-gray-950 text-gray-200 focus:outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="completed">Completed</option>
                <option value="in_progress">In Progress</option>
                <option value="not_started">Ready to Learn</option>
                <option value="locked">Locked</option>
              </select>
            </div>
          </div>
        </div>
      </header>

      {/* MAIN CANVAS AREA */}
      <div className="flex-1 relative w-full h-full bg-[#0B0F19]">
        {/* Phase swimlane headers above the canvas */}
        <div className="absolute top-2 left-6 z-10 hidden xl:flex gap-[280px] pointer-events-none opacity-90">
          {currentRoadmap.phases.map(phase => (
            <div key={phase.id} className="w-64 p-2.5 rounded-xl bg-gray-900/90 backdrop-blur border border-gray-800 shadow-md">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-[var(--brand-primary)]">
                {phase.title}
              </span>
              <p className="text-[11px] text-gray-400 line-clamp-1">
                {phase.description}
              </p>
            </div>
          ))}
        </div>

        <ReactFlow
          nodes={filteredNodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onNodeClick={onNodeClick}
          nodeTypes={nodeTypes}
          fitView
          fitViewOptions={{ padding: 0.2 }}
          minZoom={0.2}
          maxZoom={1.5}
          className="bg-[#0B0F19]"
        >
          <Background variant={BackgroundVariant.Dots} gap={24} size={1.2} color="#334155" />
          <Controls className="!bg-gray-900 !border !border-gray-800 !rounded-2xl !shadow-xl !text-white" />
          <MiniMap
            className="!rounded-2xl !border !border-gray-800 !bg-gray-900/90 !shadow-xl !overflow-hidden"
            nodeColor={(n) => {
              const d = n.data as unknown as RoadmapNode;
              if (d?.status === 'completed') return '#10B981';
              if (d?.status === 'in_progress') return '#6366F1';
              if (d?.status === 'locked') return '#334155';
              return '#64748B';
            }}
          />
        </ReactFlow>

        {/* Selected Node Drawer */}
        <NodeDetailDrawer
          node={selectedNode}
          roadmap={currentRoadmap}
          onClose={() => setSelectedNode(null)}
          onSelectNode={setSelectedNode}
        />

        {/* What-If Simulator Modal */}
        <WhatIfModal
          isOpen={isWhatIfOpen}
          onClose={() => setIsWhatIfOpen(false)}
        />

        {/* Adaptive Recovery Modal */}
        <AdaptiveRecoveryModal
          isOpen={isRecoveryOpen}
          onClose={() => setIsRecoveryOpen(false)}
        />
      </div>
    </div>
  );
};
