@echo off
title PathPilot AI Launcher
cd /d "C:\Users\Raunak Pratap Singh\.gemini\antigravity\scratch\pathpilot-ai"
set PATH=C:\Program Files\nodejs;%LOCALAPPDATA%\Programs\node-v20;%APPDATA%\npm;%PATH%

echo ========================================================
echo               Starting PathPilot AI...
echo ========================================================
echo Opening browser at http://localhost:5173
start "" "http://localhost:5173"

call npm run dev
pause
