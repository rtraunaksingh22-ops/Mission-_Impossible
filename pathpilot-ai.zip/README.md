# PathPilot AI

> **Reverse-engineer your dream career.**  
> *Your dream job is the destination. We build the map.*

PathPilot AI is a production-quality, AI-powered web application that reverse-engineers specific, ambitious career goals into personalized, interactive, and adaptive learning roadmaps with prerequisite-locked milestones, portfolio project blueprints, and real-time schedule simulations.

---

## 🧭 The Core Problem

Students often struggle to translate ambitious, highly specific career goals into realistic, actionable learning plans. They lack clarity about the skills employers expect, the sequence in which those skills should be developed, the projects needed to demonstrate competence, and the milestones necessary to approach their dream roles.

PathPilot AI solves this by combining generative AI with interactive graph visualization to:
1. **Show where you are now** vs **where you need to go**.
2. **Deconstruct senior hiring benchmarks** down to foundational CS primitives.
3. **Establish prerequisite-locked progression** where downstream milestones unlock only when fundamentals are mastered.
4. **Recommend industrial-grade capstone projects** with resume bullet points and architectural specs.
5. **Simulate "What-If" capacity scenarios** without altering your roadmap until committed.
6. **Adapt schedules dynamically** through "Get Back on Track" recovery algorithms when deadlines change.

---

## 🛠️ Technology Stack

- **Frontend Framework**: React 19 + TypeScript + Vite
- **Graph Visualization**: `@xyflow/react` (XYFlow / React Flow)
  - Custom nodes, smooth bezier directional edges, zoom, pan, minimap, status rings, prerequisite dependency propagation
- **Styling**: Tailwind CSS
  - **Dark Mode by Default** (`html.dark`) with smooth theme toggling
  - **6 Accent Colors**: Indigo, Emerald, Cyan, Amber, Rose, Violet
- **Icons**: Lucide React
- **Routing**: React Router v7 (`/`, `/onboarding`, `/dashboard`, `/roadmap/:id`, `/projects`, `/profile`, `/settings`, `/login`, `*` 404)
- **Animations & Celebrations**: `canvas-confetti` for milestone completion
- **State & Persistence**:
  - Dual persistence: Client-side `localStorage` with zero-loss state hydration + Server-side JSON database (`server/data/store.json`)
  - Auto-sync debouncing (800ms) with cloud sync indicators
- **Backend & Database**:
  - Node.js + Express backend (`server/index.js`)
  - JWT authentication (`/api/auth/register`, `/api/auth/login`, `/api/auth/me`)
  - User sync endpoint (`/api/sync`)
  - AI generation proxy (`/api/ai/generate-roadmap`)
- **Deterministic Engine**:
  - Offline, high-fidelity fallback for 4 core careers (Java Backend, AI Engineer, Full-Stack, Cybersecurity) and any custom job role

---

## 🌟 Key Features & Innovative Differentiators

### 1. Reverse Career Gap Analysis
- Transparent mathematical evaluation comparing user's current verified abilities against role benchmarks:
  $$\text{Readiness} = \text{Foundations (40\%)} + \text{Core Engineering (30\%)} + \text{Projects (20\%)} + \text{Career Launch (10\%)}$$
- Transparent calculation formula with explicit weighting breakdown.
- Categorized insight: Demonstrated Competencies, In-Progress Milestones, and Missing Foundational Gaps.

### 2. What-If Career Simulator
- Experiment with available study hours (4h–30h/week), timelines (3–24 months), and curriculum strategies (Foundation-First, Project-First, Balanced, Interview-Focused).
- Recalculates feasible completion windows in real-time on an isolated sandbox copy.
- Highlights key trade-offs and requires explicit confirmation before applying changes to the active roadmap.

### 3. Adaptive Roadmap Recovery ("Get Back on Track")
- Proactively helps students recover when life interrupts study schedules without losing completed progress.
- Presents a 3-category rebalancing breakdown with transparent reasons:
  - **Retained Core Tasks**: Critical milestones preserved in their active sequence.
  - **Rescheduled Tasks**: Intermediate modules shifted to buffer sprints with clear reasons.
  - **Deferred Tasks**: Non-essential topics postponed to post-placement learning.
- Recalibrates target timelines and weekly commitments mathematically upon acceptance.

### 4. Interactive Roadmap Canvas (React Flow)
- Phased swimlane headers and clean hierarchical graph layout.
- Filter by Phase (All Phases, Phase 1–5) and by Status (Completed, In Progress, Ready to Learn, Locked).
- Real-time search by skill, topic, or milestone title.
- Direct jump via URL parameter `?node=<nodeId>` from dashboard recommendations.
- Interactive Node Detail Drawer:
  - Prerequisite badges distinguishing **Mandatory** vs **Recommended** requirements.
  - Interactive clickable prerequisite buttons that jump directly between nodes.
  - **Downstream Reopen Impact Warning** alerting users before reopening completed milestones.

### 5. Multi-User Authentication & Cloud Sync
- Complete sign-up, login, and guest mode.
- User-isolated roadmap and profile state persisted in `server/data/store.json`.
- Status bar displaying live backend connectivity and last synced timestamp.

---

## 🚀 Getting Started

### Prerequisites
- Node.js (v18+)
- npm (v9+)

### Installation
```bash
# Clone or navigate to the directory
cd pathpilot-ai

# Install dependencies
npm install
```

### Running Locally
To run both the Vite frontend and Express backend concurrently:
```bash
npm run dev
```

- Frontend: `http://localhost:5173`
- Backend API: `http://localhost:3001`

Alternatively, run each service independently:
```bash
# Run frontend only
npm run dev:client

# Run backend only
npm run dev:server
```

### Production Build
```bash
npm run build
```

---

## ⚙️ AI Configuration & Demo Mode

PathPilot AI includes a secure server-side AI provider abstraction.

1. **Demo Mode (Default)**: If no API key is configured, the application functions in **Curated Deterministic Mode**, utilizing rich, reverse-engineered blueprints for Java Backend Developer (Fintech), AI Engineer (Generative AI), Full-Stack Developer (TS/React), and Cybersecurity Analyst, as well as dynamic deterministic roadmaps for any custom user input.
2. **Live AI Mode**: Add your Google Gemini API key or OpenAI API key to `.env` or in the web UI under `/settings`:
```env
PORT=3001
JWT_SECRET=pathpilot-super-secret-jwt-key
GEMINI_API_KEY=your_gemini_api_key_here
# or
OPENAI_API_KEY=your_openai_api_key_here
```

---

## 📄 License
MIT License. Built for students, self-taught developers, and career changers worldwide.
