import { UserProfile, Roadmap, WhatIfScenario, LearningStrategy, User, AuthResponse } from '../types';
import { generateDeterministicRoadmap } from '../data/mockRoadmaps';
import { simulateWhatIf } from './analysisEngine';

export async function registerApi(name: string, email: string, password: string): Promise<AuthResponse> {
  const res = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password })
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({ error: 'Registration failed.' }));
    throw new Error(error.error || 'Registration failed.');
  }

  return res.json();
}

export async function loginApi(email: string, password: string): Promise<AuthResponse & { userData?: any }> {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({ error: 'Invalid email or password.' }));
    throw new Error(error.error || 'Invalid email or password.');
  }

  return res.json();
}

export async function fetchMeApi(token: string): Promise<{ user: User; userData: any }> {
  const res = await fetch('/api/auth/me', {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });

  if (!res.ok) {
    throw new Error('Session expired or invalid.');
  }

  return res.json();
}

export async function saveUserDataApi(token: string, data: any): Promise<void> {
  const res = await fetch('/api/user/data', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(data)
  });

  if (!res.ok) {
    throw new Error('Failed to save data to server.');
  }
}

export async function fetchUserDataApi(token: string): Promise<any> {
  const res = await fetch('/api/user/data', {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });

  if (!res.ok) {
    throw new Error('Failed to fetch user data.');
  }

  const json = await res.json();
  return json.data;
}

export async function generateRoadmapApi(profile: UserProfile, isDemoMode: boolean): Promise<{ roadmap: Roadmap; source: 'ai' | 'demo' }> {
  if (isDemoMode) {
    await new Promise(resolve => setTimeout(resolve, 1200));
    return {
      roadmap: generateDeterministicRoadmap(profile),
      source: 'demo'
    };
  }

  try {
    const response = await fetch('/api/generate-roadmap', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile)
    });

    if (!response.ok) {
      throw new Error(`Server returned ${response.status}`);
    }

    const data = await response.json();
    return {
      roadmap: data.roadmap,
      source: data.source || 'ai'
    };
  } catch (err) {
    console.warn('API call failed or backend unavailable, using deterministic generator:', err);
    return {
      roadmap: generateDeterministicRoadmap(profile),
      source: 'demo'
    };
  }
}

export async function simulateWhatIfApi(
  roadmap: Roadmap,
  weeklyHours: number,
  timelineMonths: number,
  strategy: LearningStrategy,
  isDemoMode: boolean
): Promise<WhatIfScenario> {
  if (isDemoMode) {
    return simulateWhatIf(roadmap, weeklyHours, timelineMonths, strategy);
  }

  try {
    const response = await fetch('/api/simulate-what-if', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ roadmap, weeklyHours, timelineMonths, strategy })
    });
    if (response.ok) {
      const data = await response.json();
      return data.scenario;
    }
  } catch (e) {
    console.warn('Simulate API error, falling back locally:', e);
  }

  return simulateWhatIf(roadmap, weeklyHours, timelineMonths, strategy);
}

export async function checkServerStatus(): Promise<{ status: string; hasAiKey: boolean; provider: string }> {
  try {
    const res = await fetch('/api/status');
    if (res.ok) {
      return await res.json();
    }
  } catch {
    // Fallback if standalone client
  }
  return { status: 'offline', hasAiKey: false, provider: 'demo' };
}
