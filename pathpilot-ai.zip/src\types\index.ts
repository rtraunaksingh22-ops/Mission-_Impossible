export type SkillProficiency = 'Beginner' | 'Basic' | 'Intermediate' | 'Advanced';

export type UserSkill = {
  name: string;
  proficiency: SkillProficiency;
};

export type LearningStrategy = 'foundation_first' | 'project_first' | 'balanced' | 'interview_focused';

export type UserProfile = {
  dreamJob: string;
  specialization: string;
  industry: string;
  targetCompany: string;
  targetRegion: string;
  timelineMonths: number;
  isExploring: boolean;
  education: 'School' | 'Undergraduate' | 'Postgraduate' | 'Working Professional' | 'Career Changer' | 'Other';
  degree: string;
  yearOfStudy?: string;
  workExperience: string;
  skills: UserSkill[];
  certifications: string[];
  portfolioUrl?: string;
  confidenceLevel: number; // 1-10
  hoursPerDay: number;
  studyDaysPerWeek: number;
  weeklyStudyHours: number;
  budget: 'Free Only' | 'Budget Friendly' | 'Flexible';
  learningStyle: 'Hands-on Projects' | 'Structured Courses' | 'Documentation & Reading' | 'Coding Challenges' | 'Video-based' | 'Balanced Combination';
  learningStrategy: LearningStrategy;
  targetDate?: string;
};

export type NodeType = 'skill' | 'module' | 'exercise' | 'project' | 'assessment' | 'milestone' | 'application';
export type NodeStatus = 'locked' | 'not_started' | 'in_progress' | 'completed' | 'needs_review';
export type NodePriority = 'critical' | 'high' | 'medium' | 'optional';

export type SuggestedResource = {
  title: string;
  type: 'docs' | 'course' | 'tutorial' | 'repo';
  url: string;
  isFree: boolean;
};

export type RoadmapNode = {
  id: string;
  phaseId: string;
  title: string;
  description: string;
  type: NodeType;
  status: NodeStatus;
  priority: NodePriority;
  estimatedHours: number;
  whyItMatters: string;
  prerequisites: string[]; // List of mandatory or recommended prerequisite node IDs
  isMandatoryPrereq?: boolean;
  learningObjectives: string[];
  subtopics: string[];
  practicalExercises: string[];
  suggestedResources: SuggestedResource[];
  userNotes?: string;
  completedAt?: string;
  position: { x: number; y: number };
};

export type RoadmapPhase = {
  id: string;
  title: string;
  order: number;
  description: string;
  estimatedWeeks: number;
};

export type RoadmapEdge = {
  id: string;
  source: string;
  target: string;
  isMandatory?: boolean;
  animated?: boolean;
};

export type Roadmap = {
  id: string;
  title: string;
  targetRole: string;
  specialization: string;
  industry: string;
  region: string;
  createdAt: string;
  updatedAt: string;
  timelineMonths: number;
  weeklyHours: number;
  totalEstimatedHours: number;
  strategy: LearningStrategy;
  phases: RoadmapPhase[];
  nodes: RoadmapNode[];
  edges: RoadmapEdge[];
  summary: string;
};

export type CareerGapScoreBreakdown = {
  foundationsScore: number; // 0-40%
  coreTechScore: number;     // 0-30%
  projectsScore: number;     // 0-20%
  careerLaunchScore: number; // 0-10%
  calculationFormula: string;
};

export type CareerGapAnalysis = {
  readinessScore: number;
  demonstratedSkills: Array<{ name: string; proficiency: SkillProficiency; matchedNodes: string[] }>;
  inProgressSkills: Array<{ name: string; progressPercent: number }>;
  missingFoundationalSkills: Array<{ name: string; priority: NodePriority; reason: string }>;
  highPriorityNextActions: Array<{ nodeId: string; title: string; type: NodeType; estimatedHours: number; reason: string }>;
  scoreBreakdown: CareerGapScoreBreakdown;
};

export type WhatIfScenario = {
  baseline: { weeklyHours: number; timelineMonths: number; strategy: LearningStrategy };
  simulated: { weeklyHours: number; timelineMonths: number; strategy: LearningStrategy };
  predictedCompletionMonths: number;
  feasibility: 'feasible' | 'tight' | 'unrealistic';
  weeklyHoursDiff: number;
  timelineDiffMonths: number;
  tradeoffs: string[];
  recommendedAction: string;
  affectedNodesCount: number;
};

export type RecoveryPlan = {
  overdueCount: number;
  previousTimelineMonths: number;
  proposedTimelineMonths: number;
  tasksDeferred: Array<{ nodeId: string; title: string; reason: string }>;
  tasksMoved: Array<{ nodeId: string; title: string; fromPhase: string; toPhase: string; reason: string }>;
  tasksRetained: Array<{ nodeId: string; title: string; priority: NodePriority; reason?: string }>;
  scheduleChanges: string[];
  explanation: string;
};

export type ProjectRecommendation = {
  id: string;
  title: string;
  tagline: string;
  roleTarget: string;
  complexity: 'Beginner' | 'Intermediate' | 'Advanced' | 'Capstone';
  estimatedHours: number;
  techStack: string[];
  problemStatement: string;
  keyFeatures: string[];
  resumeBullets: string[];
  learningOutcomes: string[];
  githubTemplateUrl?: string;
  status: 'not_started' | 'in_progress' | 'completed';
  roadmapNodeId?: string;
};

export type ThemeMode = 'dark' | 'light';
export type AccentColor = 'indigo' | 'emerald' | 'cyan' | 'amber' | 'rose' | 'violet';

export type ThemeSettings = {
  mode: ThemeMode;
  accent: AccentColor;
};

export type User = {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  createdAt: string;
};

export type AuthResponse = {
  user: User;
  token: string;
  message?: string;
};

export type AppSettings = {
  aiProvider: 'gemini' | 'openai' | 'demo';
  geminiApiKey: string;
  openaiApiKey: string;
  model: string;
  isDemoMode: boolean;
  theme: ThemeSettings;
};

