import React from 'react';
import { X, AlertTriangle, RotateCcw } from 'lucide-react';
import { useApp } from '../../context/AppContext';

type ResetDemoModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export const ResetDemoModal: React.FC<ResetDemoModalProps> = ({ isOpen, onClose }) => {
  const { resetToDemoDefaults } = useApp();

  if (!isOpen) return null;

  const handleConfirm = () => {
    resetToDemoDefaults();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-gray-900 rounded-3xl max-w-md w-full shadow-2xl border border-[#E6E9F1] dark:border-gray-800 p-6 space-y-5">
        <div className="flex items-start justify-between">
          <div className="w-12 h-12 rounded-2xl bg-red-50 dark:bg-red-950/60 text-red-500 flex items-center justify-center border border-red-100 dark:border-red-900/50">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div>
          <h3 className="text-lg font-bold text-[#172033] dark:text-white">
            Reset to Demo Defaults?
          </h3>
          <p className="text-xs text-[#68738A] dark:text-gray-400 mt-1.5 leading-relaxed">
            This will reset all your career roadmaps, completed milestones, notes, portfolio project statuses, and profile answers back to the original sample demo configuration.
          </p>
        </div>

        <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-xs text-[#68738A] dark:text-gray-400">
          Your browser's local cache and roadmap state will be cleanly re-initialized with the curated Java Backend, AI Engineer, Full-Stack, and Cybersecurity tracks.
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-[#68738A] dark:text-gray-400 hover:text-[#172033] dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-700 shadow-sm shadow-red-600/25 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Demo Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
